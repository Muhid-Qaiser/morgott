"""Train the frozen-head, rank-8 LoRA, or bounded LP-FT mmBERT recipe."""

from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
import math
import os
import pickle
import re
import shutil
import tempfile
import time
from collections.abc import Iterator
from contextlib import nullcontext
from functools import lru_cache
from importlib.metadata import version
from itertools import chain
from pathlib import Path

import numpy as np

from ...normalization import strict_normalize
from .core import (
    ATTENTION_IMPLEMENTATION,
    INSTRUCTION_SUBVERSION_TAGS,
    LORA_ALPHA,
    LORA_DROPOUT,
    LORA_MODULES,
    LORA_PARAMETERS,
    LORA_RANK,
    LORA_TARGETS,
    MAX_TOKENS,
    MODEL_ID,
    MODEL_REVISION,
    add_lora,
    batch_logits,
    file_sha256,
    load_base_model,
    new_head,
    score_logits,
    source_provenance,
)
from .core import (
    pool as _pool_features,
)
from .data import (
    OverlapGuard,
    TrainingData,
    _strict_hash,
    additional_matched_pairs,
    batches,
    canonical_rows,
    external_rows,
    filter_small_training_sets,
    matched_pairs,
    partition_validation_records,
    profile_canonical,
    routing_views,
    shuffled,
    training_rows,
)
from .head_contract import new_multitask_head

DOMAIN_WEIGHT = 1.0 / 3.0
FULL_POPULATION = {
    "canonical_rows": 1_070_137,
    "promptshield_rows": 18_202,
    "matched_pairs": 11_041,
    "checkpoint_rows": 28_953,
    "calibration_rows": 116_138,
    "validation_components": 36_722,
    "promptshield_validation_rows": 984,
}
NEW_LPFT_PAIR_ARCHIVE_SHA256 = (
    "84a3b1e185755739afca5165ef9aaadb55ce248695bb4c426351f94126ebbbba"
)
NEW_LPFT_POPULATION = {**FULL_POPULATION, "matched_pairs": 33_757}
LPFT_TOP_LAYERS = 2
LPFT_INITIAL_HEAD_SHA256 = (
    "a3007323edb6da1d671b80ea1f7f46451384ddb2f45abeb2cae9d645404f5813"
)
CHECKPOINT_UPDATE_INTERVAL = 500
ADAMW_BETAS = (0.9, 0.999)
ADAMW_EPS = 1e-8
ADAMW_WEIGHT_DECAY = 0.01
GRADIENT_CLIP_NORM = 1.0
# Pinned FlashAttention-2 kernel. reports/attention-kernel-audit.md recorded
# this revision and the CUDA 13 x86-64 binary SHA-256 below; the loader still
# reaches the Hub even with a warm cache, so the digest is verified on load.
FA2_KERNEL = "kernels-community/flash-attn2@239bb21bd566f598d7e2228eab9788b0a9239b2d"
FA2_KERNEL_BINARY = (
    "build/torch-stable-abi210-cu130-x86_64-linux/_flash_attn2_cuda_2d6ecf3.abi3.so"
)
FA2_KERNEL_SHA256 = "1433d3fe1187211c5ce622a7373d8c0487227384a2b8c74064e5ed6dfc820727"

# The full-mixture contract is three separate things, and conflating them
# blocked every multi-seed and capacity comparison.
#
# PINNED_RECIPE changes what is optimised and stays fixed.
#
# Execution changes only how that optimisation is realised. Gradient
# accumulation is exact here -- `_classification_backward` normalises by the
# whole optimiser batch and `_pair_backward` scales each microbatch by its
# share of the pair list -- so `microbatch_size` cannot move the summed
# gradient. `GradientAccumulationTests` asserts that rather than assuming it.
# It is still not bitwise-neutral: dropout draw shapes and padded lengths
# depend on the partition, so runs at different microbatch sizes are
# statistically equivalent, not reproducible against each other.
#
# The arm is the capacity rung: what is trainable and how much of it.
PINNED_RECIPE = {
    "epochs": 3,
    "batch_size": 128,
    "shuffle_buffer": 8192,
    "pair_ranking_weight": 0.25,
    "gradient_checkpointing": False,
}
BASELINE_EXECUTION = {"seed": 42, "microbatch_size": 8}
BASELINE_SEED = BASELINE_EXECUTION["seed"]
SUPPORTED_MAX_TOKENS = (MAX_TOKENS, 1024)


def _runtime_max_tokens(args: argparse.Namespace) -> int:
    value = getattr(args, "max_tokens", MAX_TOKENS)
    if type(value) is not int or value not in SUPPORTED_MAX_TOKENS:
        raise ValueError(f"max tokens must be one of {SUPPORTED_MAX_TOKENS}")
    return value


# `partition_validation_records` is seeded with `seed + 1`, so these two keys
# move with the seed while the other five do not.
PINNED_POPULATION_KEYS = (
    "canonical_rows",
    "promptshield_rows",
    "matched_pairs",
    "validation_components",
    "promptshield_validation_rows",
)
VALIDATION_PARTITION_ROWS = (
    FULL_POPULATION["checkpoint_rows"] + FULL_POPULATION["calibration_rows"]
)
CHECKPOINT_FRACTION_BOUNDS = (0.19, 0.21)

# Learning rates for the arms that already have retained evidence. A new rung
# must declare its own, so no ladder entry silently inherits a rate that was
# selected for a different capacity.
BASELINE_ARM_RATES = {
    ("frozen", None, None, False): (3e-4, 3e-4),
    ("lora", LORA_RANK, None, False): (3e-4, 1e-4),
    ("lpft", None, LPFT_TOP_LAYERS, False): (3e-5, 1e-5),
}


def _arm(args: argparse.Namespace) -> dict:
    """The capacity rung of a run: what is trainable and how much."""
    lpft = args.mode == "lpft"
    return {
        "mode": args.mode,
        "lora_rank": args.lora_rank if args.mode == "lora" else None,
        "lpft_top_layers": args.lpft_top_layers if lpft else None,
        "lpft_include_embeddings": bool(args.lpft_include_embeddings)
        if lpft
        else False,
    }


def _arm_key(arm: dict) -> tuple:
    return (
        arm["mode"],
        arm["lora_rank"],
        arm["lpft_top_layers"],
        arm["lpft_include_embeddings"],
    )


def _arm_slug(arm: dict) -> str:
    """Empty for a baseline arm, so existing run names stay byte-identical."""
    if _arm_key(arm) in BASELINE_ARM_RATES:
        return ""
    if arm["mode"] == "lora":
        return f"-r{arm['lora_rank']}"
    if arm["mode"] == "lpft":
        embeddings = "e" if arm["lpft_include_embeddings"] else ""
        return f"-top{arm['lpft_top_layers']}{embeddings}"
    return ""


def _run_name(
    mode: str,
    seed: int,
    *,
    arm: dict | None = None,
    microbatch_size: int | None = None,
    max_tokens: int = MAX_TOKENS,
) -> str:
    """A different execution recipe needs a different run identity.

    Baseline arm at baseline microbatch reproduces the historical names
    exactly, so retained artifacts keep their paths.
    """
    stem = (
        f"mmbert-lora-full-s{seed}"
        if mode == "lora"
        else f"mmbert-base-full-{mode}-s{seed}"
    )
    suffix = _arm_slug(arm) if arm is not None else ""
    if (
        microbatch_size is not None
        and microbatch_size != BASELINE_EXECUTION["microbatch_size"]
    ):
        suffix += f"-mb{microbatch_size}"
    if max_tokens != MAX_TOKENS:
        suffix += f"-ctx{max_tokens}"
    return stem + suffix


_RUN_NAME_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")


def _resolved_run_name(args: argparse.Namespace) -> str:
    """Resolve one run identity for artifacts, checkpoints, and telemetry."""
    max_tokens = _runtime_max_tokens(args)
    name = getattr(args, "run_name", None) or _run_name(
        args.mode,
        args.seed,
        arm=_arm(args),
        microbatch_size=args.microbatch_size,
        max_tokens=max_tokens,
    )
    if not _RUN_NAME_PATTERN.fullmatch(name) or name in {".", ".."}:
        raise ValueError(
            "--run-name must be 1-128 ASCII letters, digits, dots, underscores, "
            "or hyphens; it must start with a letter or digit"
        )
    if max_tokens != MAX_TOKENS and f"ctx{max_tokens}" not in name:
        raise ValueError(f"non-default context --run-name must include ctx{max_tokens}")
    return name


def _preflight_execution(
    args: argparse.Namespace,
    run_name: str,
    *,
    check_cuda: bool = True,
) -> None:
    """Reject a doomed run before the prepared-corpus build starts."""
    output = args.output
    destination = output / run_name
    checkpoint = output / f".{run_name}.checkpoint.pt"
    snapshots = _snapshot_dir(output, run_name)
    if output.exists() and not output.is_dir():
        raise FileExistsError(f"training output is not a directory: {output}")
    if destination.exists():
        raise FileExistsError(f"refusing to replace existing output: {destination}")
    if args.resume:
        if not checkpoint.is_file():
            raise FileNotFoundError(f"resume checkpoint does not exist: {checkpoint}")
    else:
        if checkpoint.exists():
            raise FileExistsError(
                f"checkpoint already exists; pass --resume to use it: {checkpoint}"
            )
        if snapshots.exists():
            raise FileExistsError(
                f"snapshot directory already exists for this run: {snapshots}"
            )
    if not check_cuda:
        return
    import torch

    if not torch.cuda.is_available() or torch.cuda.device_count() < 1:
        raise RuntimeError("mmBERT training requires a visible CUDA device")
    # Availability can be true while driver initialisation or allocation still
    # fails. Force both now rather than after a multi-minute corpus preparation.
    try:
        torch.cuda.init()
        torch.empty(1, device="cuda")
    except Exception as error:
        raise RuntimeError("CUDA initialisation failed before training") from error
    if args.attention == "fa2":
        _verified_fa2_variant()
    if args.trackio:
        try:
            from trackio.gpu import gpu_available
        except (ImportError, ModuleNotFoundError) as error:
            raise RuntimeError(
                "--trackio requires the tracking extra: uv sync --extra tracking"
            ) from error
        if not gpu_available():
            raise RuntimeError(
                "--trackio requires working NVML GPU telemetry; install the "
                "tracking extra and verify the NVIDIA driver"
            )


def _configure_lpft(
    encoder,
    *,
    top_layers: int = LPFT_TOP_LAYERS,
    include_embeddings: bool = False,
) -> tuple[list[str], int]:
    """Unfreeze the top `top_layers` encoder layers plus the final norm.

    `top_layers` equal to the layer count is a full-body fine-tune with the
    multilingual embedding table still frozen; `include_embeddings` additionally
    releases that table and is the only true full fine-tune.
    """
    if (
        not hasattr(encoder, "layers")
        or len(encoder.layers) < top_layers
        or not hasattr(encoder, "final_norm")
    ):
        raise ValueError("LP-FT encoder contract failed")
    for parameter in encoder.parameters():
        parameter.requires_grad = False
    for module in (*encoder.layers[-top_layers:], encoder.final_norm):
        for parameter in module.parameters():
            parameter.requires_grad = True
    if include_embeddings:
        embeddings = getattr(encoder, "embeddings", None)
        if embeddings is None:
            raise ValueError("LP-FT embedding contract failed")
        for parameter in embeddings.parameters():
            parameter.requires_grad = True
    names = sorted(
        name for name, value in encoder.named_parameters() if value.requires_grad
    )
    return names, sum(
        value.numel() for value in encoder.parameters() if value.requires_grad
    )


def _add_lora(encoder, *, rank: int, alpha: int):
    """Rank-variable LoRA on the pinned attention targets.

    `core.py:add_lora` asserts the rank-8 constants exactly and is hash-pinned
    into every registered artifact, so the ladder builds its adapters here and
    leaves that module byte-identical. Parameter count is linear in rank, so
    the target contract is still checked -- just against the rank actually
    requested.
    """
    from peft import LoraConfig, get_peft_model

    model = get_peft_model(
        encoder,
        LoraConfig(
            r=rank,
            lora_alpha=alpha,
            lora_dropout=LORA_DROPOUT,
            bias="none",
            target_modules=LORA_TARGETS,
            task_type="FEATURE_EXTRACTION",
        ),
    )
    modules = [module for module in model.modules() if hasattr(module, "lora_A")]
    trainable = sum(
        parameter.numel() for parameter in model.parameters() if parameter.requires_grad
    )
    expected = LORA_PARAMETERS * rank // LORA_RANK
    if len(modules) != LORA_MODULES or trainable != expected:
        raise ValueError(
            f"LoRA target contract changed: {len(modules)} modules, "
            f"{trainable} parameters, expected {LORA_MODULES} and {expected}"
        )
    return model


HARMFUL_INTENT_TAG = "harmful_intent"
BENIGN_TAG = "benign"


def _new_multitask_head(hidden_size: int, seed: int, outputs: int):
    """Extend `core.new_head` with a separate auxiliary projection.

    The shared trunk and primary 384-to-1 projection remain exactly the legacy
    head, including its RNG stream and GEMM shape.  The second 384-to-1
    projection is auxiliary, so the registered score definition still refers
    to the unchanged primary output.
    """
    if outputs != 2:
        raise ValueError("only the two-output multitask contract is supported")
    return new_multitask_head(hidden_size, seed)


def _harmful_label(row: dict) -> int | None:
    """Masked harmful-intent target; None where the source establishes nothing.

    A subversion positive carrying no harm tag is unknown, not harmless: the
    corpus records harm as an independent attribute, and "not injection" is
    explicitly not evidence of benignity. Those rows are therefore masked out
    rather than supervised as negatives.
    """
    tags = row.get("security_tags") or ()
    if HARMFUL_INTENT_TAG in tags:
        return 1
    if BENIGN_TAG in tags:
        return 0
    return None


def _harmful_balance(rows: Iterator[dict]) -> tuple[dict[str, int], dict[int, float]]:
    """Population-balanced auxiliary weights after canonical overlap removal."""
    counts = {"negative": 0, "positive": 0, "unknown": 0}
    for row in rows:
        label = _harmful_label(row)
        counts["unknown" if label is None else "positive" if label else "negative"] += 1
    population = sum(counts.values())
    known = counts["negative"] + counts["positive"]
    if not population or not counts["negative"] or not counts["positive"]:
        raise ValueError(
            "harmful-intent objective requires positive and negative canonical rows"
        )
    # Unknown rows are masked. Balance within the known population, then keep
    # division by the full canonical optimizer batch in the loss. The effective
    # auxiliary coefficient is therefore DOMAIN_WEIGHT * p(known), rather than
    # silently inflating sparse harm evidence to one full domain coefficient.
    weights = {
        0: known / (2.0 * counts["negative"]),
        1: known / (2.0 * counts["positive"]),
    }
    return counts, weights


def _multitask_classification_backward(
    encoder,
    tokenizer,
    head,
    rows: list[dict],
    *,
    coefficient: float,
    harmful_class_weights: dict[int, float],
    microbatch_size: int,
    train_encoder: bool,
    cache: _EncodingCache | None = None,
    pad_to_multiple_of: int | None = None,
    max_tokens: int = MAX_TOKENS,
) -> dict[str, object]:
    """Primary and balanced masked auxiliary BCE from one encoder forward.

    Both terms are normalised by the whole optimiser batch, so changing the
    microbatch partition cannot change their summed gradient (apart from the
    documented floating-point/dropout caveat).
    """
    import torch

    totals: dict[str, object | None] = {
        "canonical_primary_loss": None,
        "harmful_aux_loss": None,
        "harmful_positive_loss": None,
        "harmful_negative_loss": None,
    }
    for batch in batches(rows, microbatch_size):
        logits = _cached_batch_logits(
            encoder,
            tokenizer,
            head,
            [row["text"] for row in batch],
            train_encoder=train_encoder,
            cache=cache,
            pad_to_multiple_of=pad_to_multiple_of,
            column=None,
            max_tokens=max_tokens,
        )
        if logits.ndim != 2 or logits.shape[1] != 2:
            raise ValueError("multitask head must return exactly two logits per row")
        primary_targets = torch.tensor(
            [row["label"] for row in batch],
            dtype=torch.float32,
            device="cuda",
        )
        primary_weights = torch.tensor(
            [row.get("weight", 1.0) for row in batch],
            dtype=torch.float32,
            device="cuda",
        )
        primary_losses = torch.nn.functional.binary_cross_entropy_with_logits(
            logits[:, 0].float(),
            primary_targets,
            reduction="none",
        )
        primary = coefficient * (primary_losses * primary_weights).sum() / len(rows)

        labels = [_harmful_label(row) for row in batch]
        harmful_targets = torch.tensor(
            [float(label or 0) for label in labels],
            dtype=torch.float32,
            device="cuda",
        )
        harmful_weights = torch.tensor(
            [
                0.0 if label is None else harmful_class_weights[int(label)]
                for label in labels
            ],
            dtype=torch.float32,
            device="cuda",
        )
        harmful_losses = torch.nn.functional.binary_cross_entropy_with_logits(
            logits[:, 1].float(),
            harmful_targets,
            reduction="none",
        )
        positive = (
            coefficient
            * (harmful_losses * harmful_weights * harmful_targets).sum()
            / len(rows)
        )
        negative = (
            coefficient
            * (harmful_losses * harmful_weights * (1.0 - harmful_targets)).sum()
            / len(rows)
        )
        harmful = positive + negative
        (primary + harmful).backward()
        values = {
            "canonical_primary_loss": primary,
            "harmful_aux_loss": harmful,
            "harmful_positive_loss": positive,
            "harmful_negative_loss": negative,
        }
        for key, value in values.items():
            detached = value.detach()
            totals[key] = detached if totals[key] is None else totals[key] + detached
    return {key: value for key, value in totals.items() if value is not None}


# Progress counters that a validation row carries for the on-disk curve but
# that are noise as dashboard charts. See `_RunTracker.log_validation`.
_VALIDATION_BOOKKEEPING = frozenset(
    {"epoch", "updates", "canonical_rows_seen", "training_loss"}
)

# High BCE means opposite failures on either side of the trust boundary, and a
# chart labelled only "banking77" hides that: 1.6 there is the model flagging
# ordinary banking traffic, while 1.6 on "gandalf" is a missed jailbreak. The
# namespace carries the direction so the dashboard's section header states it
# once, rather than the reader having to remember it seventeen times.
_MISSED_ATTACK_SOURCES = frozenset(
    {
        "bipia",
        "browsesafe",
        "gandalf",
        "hackaprompt",
        "llmail",
        "prompt_injections",
        "tensor_trust_raw",
        "wildjailbreak",
    }
)
_FALSE_FLAG_SOURCES = frozenset(
    {
        "banking77",
        "harper_valley_bank",
        "lmsys_arena",
        "massive_en",
        "mind2web",
        "schema_guided_dialogue",
        "taskmaster",
        "tatqa",
        # Harmful content without instruction subversion is a separate label, so
        # a flag here is a false positive for this head.
        "toxic_chat",
    }
)


def _source_metric_group(source: str) -> str:
    """Namespace a per-source BCE by what a high value there would mean."""
    if source in _MISSED_ATTACK_SOURCES:
        return "val_bce_missed_attacks"
    if source in _FALSE_FLAG_SOURCES:
        return "val_bce_false_flags"
    # A new source must show up somewhere visible rather than be silently
    # filed under the wrong failure direction.
    return "val_bce_unclassified_source"


# Selection is otherwise irreversible: `best` holds weights in a single slot, so
# the checkpoint a rule rejects is gone. On the constant-LR baseline the rules
# disagreed -- the registered blend kept update 9,000 while both source-macro
# and worst-source preferred 8,361, which was 1.8x better on worst source and
# lost only because its PromptShield term happened to be 13x lower. Keeping one
# candidate per rule costs ~27 MB each and makes that call reviewable once the
# real gates are computed.
_ALTERNATE_SELECTION_RULES = {
    "source_macro_only": lambda row: row["validation_morgott_source_macro_bce"],
    "worst_source": lambda row: row["validation_worst_source_bce"],
}

_METRIC_LEGEND = """\
## What these curves mean

All losses are binary cross-entropy: **lower is better**, and BCE is unbounded
above, so a source sitting at 5 is confidently wrong, not merely uncertain.

### Which checkpoint gets kept

`selection_rules/ACTIVE_registered_blend` is the only one that decides. It is
`0.5 * (mean per-source Morgott BCE + PromptShield BCE)`, and the run retains
the lowest-scoring checkpoint rather than the last one, so a rising tail costs
time rather than quality.

Treat that rule with suspicion. Its PromptShield half carries 50% of the
nominal weight but a median 1.4% of the value, because PromptShield is half of
every training batch and its validation BCE sits near zero. On the constant-LR
baseline that near-dead term still cast the deciding vote: it kept update 9,000
over update 8,361, which was better on source-macro and 1.8x better on worst
source.

So the alternates are logged beside it, and their weights retained on disk
under `alternate-selections/`, unregistered:

- `selection_rules/alt_source_macro_only` -- drops the PromptShield term.
- `selection_rules/alt_worst_source` -- minimises the worst single source, the
  closest proxy for the standing zero-finance-false-positive rule.

Where the three disagree is where the selection rule is doing real work, and
worth checking against the actual gates (AUROC, TPR at 1% FPR, recall, finance
false positives) -- none of which is the BCE these rules minimise.

### The component losses

- `validation/validation_morgott_bce` -- pooled over all Morgott rows, so large
  sources dominate it.
- `validation/validation_morgott_source_macro_bce` -- unweighted mean across
  sources, so a big source cannot mask regressions on small ones.
- `validation/validation_worst_source_bce` -- the single worst source.
- `validation/validation_promptshield_bce` -- read carefully: in-distribution
  fit, **not** transfer. The transfer claim needs the held-out 23,516-row test
  split, scored only at final evaluation.
- `validation/validation_macro_bce` -- equal-domain mean of the pooled Morgott
  and PromptShield terms.

### Per-source charts -- high means opposite things

The namespace states which. `val_bce_missed_attacks/*` high means **missed
attacks**; `val_bce_false_flags/*` high means **false positives on ordinary
traffic**. `banking77`, `harper_valley_bank` and `tatqa` are the finance
sources under the standing zero-false-positive rule.

A run that flips between the two blocks between validations is oscillating
between flag-nothing and flag-everything, not converging.

### Training

`train/loss` is the sum of three weighted terms (canonical + PromptShield +
pair ranking), preserving the historical graph. `train/total_loss` adds the
balanced harmful-intent auxiliary term; the four named component charts show
which objective moved. `train/clip_fraction` and the pre-clip gradient norm
make extreme canonical weights visible instead of silently flattening them.
`performance/examples_per_second` and optimizer updates/second are synchronized
25-update window rates, not asynchronous launch rates.
`train/head_lr` and `train/adapter_lr` show linear warmup then cosine decay.

Tip: the dashboard takes a regex in the sidebar, or `&metric_filter=` in the
URL — try `selection_loss|worst_source` for the headline view.
"""


class _RunTracker:
    """Optional Trackio logging.

    Trackio is local-first: runs land in a SQLite store under
    `~/.cache/huggingface/trackio` and are viewed with `trackio show`. Nothing
    leaves the box unless `--trackio-space` names a Hugging Face Space. Only
    scalars and the recorded configuration are logged; corpus text, prompts,
    row identities, and credentials never are.
    """

    def __init__(self, args: argparse.Namespace, *, run_name: str, config: dict):
        self._run = None
        if not args.trackio:
            return
        import trackio

        if not args.resume:
            # Without --resume, Trackio uses resume="never", which opens a NEW
            # run id under the SAME name and does not uniquify. The dashboard
            # keys on the name, so a restart-from-zero silently overlays a dead
            # partial curve on the live one -- three had to be deleted by hand
            # on 2026-08-07 before anyone noticed. Fail instead, and name both
            # of the intents the operator might have had.
            try:
                from trackio.sqlite_storage import SQLiteStorage

                clash = SQLiteStorage.get_latest_run_record_by_name(
                    args.trackio_project, run_name
                )
            except Exception:
                # Never block training on a tracking-internals change.
                clash = None
            if clash:
                raise ValueError(
                    f"Trackio run {run_name!r} already exists in project "
                    f"{args.trackio_project!r}. Pass --resume to continue it, "
                    f"choose a distinct --run-name, or delete the old run. "
                    f"Starting over would merge both curves under one name."
                )
        self._run = trackio.init(
            project=args.trackio_project,
            name=run_name,
            group=args.trackio_group or None,
            space_id=args.trackio_space or None,
            config=config,
            # A progress checkpoint is the authority to resume.  Never create
            # a fresh telemetry run merely because its matching Trackio row is
            # missing: that would make the training and dashboard histories
            # disagree about whether this is a continuation.
            resume="must" if args.resume else "never",
            # Trackio samples device utilisation itself, which is the cheapest
            # way to see whether the GPU is actually the bottleneck.
            auto_log_gpu=True,
            auto_log_cpu=False,
        )

    @staticmethod
    def _scalars(metrics: dict) -> dict:
        return {
            key: float(value)
            for key, value in metrics.items()
            if isinstance(value, (int, float)) and not isinstance(value, bool)
        }

    def log(self, metrics: dict, *, step: int | None = None) -> None:
        if self._run is None:
            return
        self._run.log(self._scalars(metrics), step=step)

    def describe_metrics(self) -> None:
        """Log a legend for the curves, since Trackio charts carry no prose.

        Trackio labels a chart with the metric name and nothing else, so
        `validation_source/tensor_trust_raw` arrives without any hint that a
        high value there means missed attacks while the same number on
        `validation_source/banking77` means the opposite -- flagging ordinary
        banking traffic, which is the failure this project cares most about.
        """
        if self._run is None:
            return
        import trackio

        self._run.log({"notes": trackio.Markdown(_METRIC_LEGEND)})

    def log_validation(self, row: dict, *, step: int) -> None:
        """Log a validation row without its bookkeeping fields.

        A validation row carries progress counters alongside the metrics.
        Logged as-is they become charts that restate what is already plotted:
        `epoch` and `canonical_rows_seen` duplicate the `train/` series, and
        `updates` is the step itself, so it draws a straight diagonal. Dropping
        them is safe for cross-arm overlay -- the metric names that remain are
        unchanged, so an arm logged before this filter existed still shares an
        axis with one logged after.
        """
        if self._run is None:
            return
        kept = {
            key: value
            for key, value in row.items()
            if key not in _VALIDATION_BOOKKEEPING
        }
        metrics = {
            f"validation/{key}": value for key, value in self._scalars(kept).items()
        }
        # Every rule's score, side by side, so the retention decision is visible
        # rather than implicit. The ACTIVE_ prefix names the one that actually
        # picks the saved weights; the alt_ rules only retain candidates.
        metrics["selection_rules/ACTIVE_registered_blend"] = float(
            row["selection_loss"]
        )
        for name, score in _ALTERNATE_SELECTION_RULES.items():
            metrics[f"selection_rules/alt_{name}"] = float(score(row))
        self._run.log(metrics, step=step)

    def log_by_source(self, values: dict, *, step: int) -> None:
        if self._run is None:
            return
        self._run.log(
            {
                f"{_source_metric_group(source)}/{source}": float(value)
                for source, value in values.items()
            },
            step=step,
        )

    def log_harmful_by_source(self, values: dict, *, step: int) -> None:
        if self._run is None:
            return
        metrics = {}
        for source, summary in values.items():
            for name, value in self._scalars(summary).items():
                metrics[f"validation_harmful_{name}/{source}"] = value
        self._run.log(metrics, step=step)

    def finish(self, summary: dict | None = None) -> None:
        if self._run is None:
            return
        if summary:
            self._run.log(
                self._scalars({f"selected/{k}": v for k, v in summary.items()})
            )
        self._run.finish()


def _usable_cpus() -> int:
    """CPUs this container may actually use.

    `os.cpu_count()` and `sched_getaffinity` both report the host's cores
    inside a quota-limited container -- 128 against a real budget of 13 here --
    so oversubscribing by 10x is the default outcome unless the cgroup quota is
    read directly.
    """
    quotas = []
    try:
        quota, period = Path("/sys/fs/cgroup/cpu.max").read_text().split()
        if quota != "max":
            quotas.append(int(quota) / int(period))
    except (OSError, ValueError):
        pass
    try:
        quota = int(Path("/sys/fs/cgroup/cpu/cpu.cfs_quota_us").read_text())
        period = int(Path("/sys/fs/cgroup/cpu/cpu.cfs_period_us").read_text())
        if quota > 0 and period > 0:
            quotas.append(quota / period)
    except (OSError, ValueError):
        pass
    available = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else 0
    available = available or os.cpu_count() or 1
    return max(1, int(min([available, *quotas]) if quotas else available))


@lru_cache(maxsize=1)
def _verified_fa2_variant() -> Path:
    """Resolve the pinned local FA2 variant and verify its executable digest.

    The kernel is executable code fetched through the Hugging Face kernel
    cache.  Pinning the repository revision is necessary but not sufficient:
    fail closed unless the binary selected for this Torch/CUDA platform is the
    exact artifact recorded by the attention-kernel audit.  Local-only
    resolution also prevents a training launch from silently fetching a new
    binary.
    """
    from huggingface_hub import constants
    from huggingface_hub.file_download import repo_folder_name

    repo_id, revision = FA2_KERNEL.rsplit("@", 1)
    snapshot = (
        Path(constants.HF_HUB_CACHE)
        / repo_folder_name(repo_id=repo_id, repo_type="kernel")
        / "snapshots"
        / revision
    )
    binary = snapshot / FA2_KERNEL_BINARY
    if not binary.is_file():
        raise FileNotFoundError(
            "pinned FA2 executable is not present in the Hugging Face kernel cache: "
            f"{binary}"
        )
    digest = file_sha256(binary)
    if digest != FA2_KERNEL_SHA256:
        raise RuntimeError(
            "pinned FA2 executable digest mismatch: "
            f"expected {FA2_KERNEL_SHA256}, got {digest}"
        )
    return binary.parent


def _load_base_model_with_attention(attention: str):
    """`core.load_base_model` with a selectable attention kernel.

    `core.py` is SHA-pinned inside every registered artifact and `inference.py`
    compares its `ATTENTION_IMPLEMENTATION` constant against each recorded run,
    so an alternative kernel is built here instead of edited in there. Only the
    training path is affected; maintained inference keeps the pinned loader.
    """
    import torch
    from transformers import AutoModel, AutoTokenizer

    if not torch.cuda.is_available():
        raise RuntimeError("mmBERT requires a CUDA device")
    if attention == FA2_KERNEL:
        _verified_fa2_variant()
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REVISION)
    if tokenizer.pad_token_id is None:
        raise ValueError("pinned tokenizer has no pad token")
    encoder = AutoModel.from_pretrained(
        MODEL_ID,
        revision=MODEL_REVISION,
        attn_implementation=attention,
        dtype=torch.bfloat16,
    ).to("cuda")
    return encoder, tokenizer


class _EncodingCache:
    """Memoise `strict_normalize` plus tokenisation, keyed on the raw text.

    Both are pure functions of the text and the pinned tokenizer revision, so
    memoising them cannot change what the encoder sees. It removes the dominant
    CPU cost: `strict_normalize` runs twice per canonical row per epoch and
    re-normalises the whole PromptShield and pair pools on every draw, roughly
    9.6M calls per run over far fewer distinct strings.

    Keyed on text rather than row id so it needs no uniqueness assumption
    across the canonical, PromptShield, and pair populations.
    """

    def __init__(self, tokenizer, *, max_tokens: int = MAX_TOKENS) -> None:
        if type(max_tokens) is not int or max_tokens not in SUPPORTED_MAX_TOKENS:
            raise ValueError(f"max tokens must be one of {SUPPORTED_MAX_TOKENS}")
        self._tokenizer = tokenizer
        self.max_tokens = max_tokens
        self._encoded: dict[str, np.ndarray] = {}

    def __len__(self) -> int:
        return len(self._encoded)

    def encode(self, texts: list[str]) -> list[list[int]]:
        missing = []
        for text in texts:
            if text not in self._encoded:
                missing.append(text)
        if missing:
            # Deduplicate within the request too; a batch can repeat a text.
            unique = list(dict.fromkeys(missing))
            encoded = self._tokenizer(
                [strict_normalize(text) for text in unique],
                add_special_tokens=True,
                max_length=self.max_tokens,
                truncation=True,
            )["input_ids"]
            for text, ids in zip(unique, encoded, strict=True):
                self._encoded[text] = np.asarray(ids, dtype=np.int32)
        return [self._encoded[text].tolist() for text in texts]

    def warm(self, texts, *, workers: int = 0) -> None:
        """Populate the cache up front, off the training critical path.

        `strict_normalize` is ~205 ns/char of pure Python and is the single
        largest CPU cost in a run. It is a pure function, so it fans out across
        processes safely; `imap` with a chunk size preserves order, and the
        tokenizer is a Rust extension that already threads internally.
        """
        pending = list(
            dict.fromkeys(text for text in texts if text not in self._encoded)
        )
        if not pending:
            return
        if workers and workers > 1 and len(pending) > 4096:
            os.environ.setdefault("TOKENIZERS_PARALLELISM", "true")
            os.environ.setdefault("RAYON_NUM_THREADS", str(workers))
            from multiprocessing import get_context

            # The model, CUDA runtime, and Trackio may already own background
            # threads. Forking that process can inherit poisoned locks or a
            # CUDA context; spawn imports a clean worker containing only the
            # top-level pure normalizer.
            with get_context("spawn").Pool(workers) as workforce:
                normalized = list(
                    workforce.imap(strict_normalize, pending, chunksize=512)
                )
            for start in range(0, len(pending), 1024):
                window = slice(start, start + 1024)
                encoded = self._tokenizer(
                    normalized[window],
                    add_special_tokens=True,
                    max_length=self.max_tokens,
                    truncation=True,
                )["input_ids"]
                for text, ids in zip(pending[window], encoded, strict=True):
                    self._encoded[text] = np.asarray(ids, dtype=np.int32)
            return
        for start in range(0, len(pending), 1024):
            self.encode(pending[start : start + 1024])


def _cached_batch_logits(
    encoder,
    tokenizer,
    head,
    texts: list[str],
    *,
    train_encoder: bool,
    cache: _EncodingCache | None,
    pad_to_multiple_of: int | None = None,
    column: int | None = 0,
    max_tokens: int | None = None,
):
    """`core.batch_logits` with normalisation and tokenisation memoised.

    Mirrors `core.batch_logits` exactly; `tokenizer.pad` is the same code path
    `tokenizer(..., padding=True)` uses internally, so the encoder input is
    bitwise identical. `tests.test_mmbert_training` asserts that.

    Falls back to the pinned implementation when no cache is supplied, so the
    hash-locked module stays the single definition of the forward pass.
    """
    import torch

    if max_tokens is None:
        max_tokens = getattr(cache, "max_tokens", MAX_TOKENS)
    if type(max_tokens) is not int or max_tokens not in SUPPORTED_MAX_TOKENS:
        raise ValueError(f"max tokens must be one of {SUPPORTED_MAX_TOKENS}")
    cache_max_tokens = getattr(cache, "max_tokens", max_tokens)
    if cache_max_tokens != max_tokens:
        raise ValueError("encoding cache context cap differs from the scoring cap")
    if (
        max_tokens == MAX_TOKENS
        and cache is None
        and pad_to_multiple_of is None
        and column == 0
    ):
        return batch_logits(
            encoder, tokenizer, head, texts, train_encoder=train_encoder
        )
    if cache is None:
        cache = _EncodingCache(tokenizer, max_tokens=max_tokens)
    encoded = tokenizer.pad(
        {"input_ids": cache.encode(texts)},
        padding=True,
        pad_to_multiple_of=pad_to_multiple_of,
        return_tensors="pt",
    ).to("cuda")
    context = nullcontext() if train_encoder else torch.no_grad()
    with context, torch.autocast("cuda", dtype=torch.bfloat16):
        hidden = encoder(**encoded).last_hidden_state
        features = _pool_features(hidden, encoded["attention_mask"])
    with torch.autocast("cuda", dtype=torch.bfloat16):
        logits = head(features)
    return logits if column is None else logits[:, column]


class _EpochStream:
    """Replay the identical canonical epoch stream without re-reading the view.

    `training_rows` yields rows in file order with weights derived from fixed
    counts, so every epoch produces the same sequence and only `shuffled`
    re-seeds. Re-reading costs a full JSON parse, a SHA-256 over the whole view,
    and ~1.07M leakage-hash normalisations per epoch.

    The cache is published only after a complete pass, so an aborted first epoch
    cannot serve a truncated stream.
    """

    def __init__(self, factory, *, expected_rows: int) -> None:
        self._factory = factory
        self._expected = expected_rows
        self._rows: list[dict] | None = None

    @property
    def cached(self) -> bool:
        return self._rows is not None

    def __iter__(self) -> Iterator[dict]:
        if self._rows is not None:
            yield from self._rows
            return
        collected: list[dict] = []
        for row in self._factory():
            collected.append(row)
            yield row
        if len(collected) != self._expected:
            raise ValueError(
                f"cached canonical epoch stream changed: {len(collected)} rows, "
                f"expected {self._expected}"
            )
        self._rows = collected


class _MetricWindow:
    """Accumulate detached CUDA scalars and synchronize once per log window."""

    def __init__(self) -> None:
        self._totals: dict[str, object] = {}
        self._latest: dict[str, object] = {}
        self.updates = 0
        self.examples = 0

    def add(self, metrics: dict[str, object], *, examples: int) -> None:
        if set(metrics) != set(self._totals) and self._totals:
            raise ValueError("training metric keys changed within a log window")
        for key, value in metrics.items():
            detached = value.detach()
            if detached.ndim:
                raise ValueError("training metrics must be scalar tensors")
            self._totals[key] = (
                detached if key not in self._totals else self._totals[key] + detached
            )
            self._latest[key] = detached
        self.updates += 1
        self.examples += examples

    def drain(self) -> tuple[dict[str, float], dict[str, float], int, int]:
        if not self.updates:
            raise ValueError("cannot drain an empty training metric window")
        import torch

        keys = sorted(self._totals)
        # One packed device-to-host transfer is one synchronization point. The
        # old loop called float(loss) on every optimizer update and serialized
        # every scalar again at each checkpoint.
        values = (
            torch.stack(
                [
                    *[self._totals[key] for key in keys],
                    *[self._latest[key] for key in keys],
                ]
            )
            .float()
            .cpu()
            .tolist()
        )
        width = len(keys)
        totals = dict(zip(keys, values[:width], strict=True))
        latest = dict(zip(keys, values[width:], strict=True))
        updates, examples = self.updates, self.examples
        self.__init__()
        return totals, latest, updates, examples


def _configure_compiled_backward_autocast() -> None:
    """Make compiled backward match eager FP32 loss/backward semantics."""
    from torch._functorch import config as functorch_config

    # The default (`same_as_forward`) captures backward under the BF16 forward
    # autocast state. PyTorch documents `off` as the eager-equivalent policy.
    functorch_config.backward_pass_autocast = "off"


def _save_checkpoint(path: Path, *, identity: dict, state: dict) -> None:
    import torch

    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            torch.save(
                {
                    "schema_version": 1,
                    "identity": identity,
                    "state": state,
                },
                handle,
            )
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _load_checkpoint(path: Path, *, identity: dict) -> dict:
    import torch

    payload = torch.load(path, map_location="cpu", weights_only=True)
    if (
        not isinstance(payload, dict)
        or payload.get("schema_version") != 1
        or payload.get("identity") != identity
        or not isinstance(payload.get("state"), dict)
    ):
        raise ValueError("checkpoint identity or schema mismatch")
    return payload["state"]


def _skip_resumed_batches(
    batch_iterator: Iterator[list[dict]],
    *,
    batches_consumed: int,
    canonical_seen: int,
) -> int:
    skipped = 0
    for _ in range(batches_consumed):
        batch = next(batch_iterator, None)
        if batch is None:
            raise ValueError("resume position exceeds the epoch stream")
        skipped += len(batch)
    if skipped != canonical_seen:
        raise ValueError(
            f"resumed epoch replay saw {skipped} canonical rows, "
            f"expected {canonical_seen}"
        )
    return skipped


def _candidate_weights(
    row: dict, *, mode: str, head, encoder, epoch: int, updates: int, loss: float
) -> dict:
    return {
        "loss": float(loss),
        "epoch": epoch,
        "updates": updates,
        "head": _cpu_state(head),
        "adapter": _adapter_state(encoder) if mode == "lora" else None,
        "encoder": _lpft_state(encoder) if mode == "lpft" else None,
    }


def _save_alternates(
    output: Path, run_name: str, alternates: dict, *, mode: str
) -> None:
    """Write the runner-up checkpoints beside the run, with a readable index.

    These are deliberately not registered models and not loadable by maintained
    inference. They exist so the selection rule can be revisited against the
    real gates -- AUROC, TPR at 1% FPR, recall, finance false positives -- none
    of which is the BCE the rule actually minimises.
    """
    import torch

    if not alternates:
        return
    directory = output / run_name / "alternate-selections"
    directory.mkdir(parents=True, exist_ok=True)
    for name, candidate in alternates.items():
        torch.save(candidate, directory / f"{name}.pt")
    (directory / "index.json").write_text(
        json.dumps(
            {
                "purpose": "runner-up checkpoints under alternate selection rules",
                "registered": False,
                "mode": mode,
                "rules": {
                    name: {
                        "loss": candidate["loss"],
                        "epoch": candidate["epoch"],
                        "updates": candidate.get("updates", 0),
                    }
                    for name, candidate in alternates.items()
                },
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def _snapshot_dir(output: Path, run_name: str) -> Path:
    """Dot-prefixed sibling of the run, never the run directory itself.

    `experiments/capacity_ladder/run_ladder.sh` treats `RUNS/<name>` as the
    "arm already trained" marker, so writing snapshots inside it mid-run would
    make the next relaunch skip the arm it is still training.
    """
    return output / f".{run_name}.snapshots"


def _should_snapshot(args: argparse.Namespace, updates: int) -> bool:
    """Periodic retention plus one pre-registered comparison checkpoint."""
    comparison_update = getattr(args, "comparison_update", 0)
    return bool(
        (args.snapshot_every and updates % args.snapshot_every == 0)
        or (comparison_update and updates == comparison_update)
    )


def _save_snapshot(
    directory: Path,
    row: dict,
    *,
    training_identity: dict,
    mode: str,
    head,
    encoder,
    epoch: int,
    updates: int,
) -> None:
    """Retain a validation point's weights regardless of any selection rule.

    `best` and each entry of `alternates` hold a single slot, so the weights of
    every checkpoint those rules reject are destroyed as training continues.
    That is only safe when the selection signal is stable, and on the 2026-08-06
    ladder it is not: adjacent `source_macro` validations 500 updates apart
    ranged from 0.27 to 0.96, so a running minimum latches onto whichever early
    point was luckiest and the weights needed to revisit that call are gone.

    Snapshots make selection reviewable against the real gates -- AUROC, TPR at
    1% FPR, recall, finance false positives -- rather than irreversible. Like
    `alternate-selections` they are research artifacts, deliberately outside
    `model-artifacts.json` and not loadable by maintained inference.
    """
    import torch

    directory.mkdir(parents=True, exist_ok=True)
    payload = _candidate_weights(
        row,
        mode=mode,
        head=head,
        encoder=encoder,
        epoch=epoch,
        updates=updates,
        loss=row["selection_loss"],
    )
    payload["training_identity"] = copy.deepcopy(training_identity)
    payload["metrics"] = dict(row)
    path = directory / f"update-{updates:06d}.pt"
    # The same atomic write as the progress checkpoint: a snapshot truncated by
    # a kill is worse than a missing one, because it still reads as available.
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            dir=directory,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            torch.save(payload, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _write_snapshot_index(directory: Path, curve: list) -> None:
    """Let reselection read the whole curve without loading a single tensor."""
    if not directory.is_dir():
        return
    kept = {
        int(path.stem.removeprefix("update-")) for path in directory.glob("update-*.pt")
    }
    (directory / "index.json").write_text(
        json.dumps(
            {
                "purpose": "unconditional per-validation weight snapshots",
                "registered": False,
                "points": [
                    {
                        "updates": row["updates"],
                        "epoch": row["epoch"],
                        "file": f"update-{row['updates']:06d}.pt",
                        "selection_loss": row["selection_loss"],
                        "source_macro_only": row["validation_morgott_source_macro_bce"],
                        "worst_source": row["validation_worst_source"],
                        "worst_source_bce": row["validation_worst_source_bce"],
                        "interim": bool(row.get("interim")),
                        "pre_registered_comparison": bool(
                            row.get("pre_registered_comparison")
                        ),
                    }
                    for row in curve
                    if row["updates"] in kept
                ],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def _update_alternates(
    alternates: dict, row: dict, *, mode: str, head, encoder, epoch: int, updates: int
) -> None:
    """Retain the best checkpoint under each alternate selection rule.

    See `_ALTERNATE_SELECTION_RULES` for why: the registered rule is one opinion
    and it discards the weights of every checkpoint it rejects.
    """
    for name, score in _ALTERNATE_SELECTION_RULES.items():
        value = score(row)
        current = alternates.get(name)
        if current is None or value < current["loss"]:
            alternates[name] = _candidate_weights(
                row,
                mode=mode,
                head=head,
                encoder=encoder,
                epoch=epoch,
                updates=updates,
                loss=value,
            )


def _lr_multiplier(step: int, *, total_updates: int, warmup_updates: int) -> float:
    """Linear warmup then cosine decay, as a multiplier on each group's base LR.

    Warmup is here for the LP-FT arms above all: they unfreeze real encoder
    layers, and the opening updates at full rate are exactly when a pretrained
    body loses the features LP-FT exists to preserve. Decay covers the other
    end -- the constant-rate baseline run peaked at update 9,000 of 25,083 and
    was still degrading when it was stopped.
    """
    if warmup_updates > 0 and step < warmup_updates:
        return (step + 1) / warmup_updates
    span = max(total_updates - warmup_updates, 1)
    progress = min(max(step - warmup_updates, 0) / span, 1.0)
    return 0.5 * (1.0 + math.cos(math.pi * progress))


def _shuffled_chunks(items: list, size: int, rng) -> list[list]:
    chunks = [items[start : start + size] for start in range(0, len(items), size)]
    return [chunks[index] for index in rng.permutation(len(chunks))]


def length_grouped_batches(rows, batch_size: int, *, key, factor: int, rng):
    """Yield length-homogeneous batches, in shuffled order.

    Padding is charged per microbatch at its longest row, so batches drawn at
    random from this corpus -- median 75 characters against a mean of 661 --
    spend 1.37 padded tokens per real one. Sorting a megabatch and cutting it
    into batches takes that to ~1.00, measured at 27% fewer tokens processed
    per update across the three populations.

    The shuffle afterwards is what keeps it honest. Without it every epoch
    would walk short batches to long ones, correlating batch content with
    training time -- and in this corpus length tracks source, which is exactly
    what `source_macro` selection grades on.
    """
    for megabatch in batches(rows, batch_size * factor):
        megabatch.sort(key=key)
        yield from _shuffled_chunks(megabatch, batch_size, rng)


class _LengthGroupedCycle:
    """Length-grouped batching layered over an index cycle.

    The wrapped cycle keeps its own sampling contract -- class balance for
    PromptShield, pair integrity for the ranking loss -- because this only
    changes which of its draws share a batch, never which indices it yields
    over a megabatch. It is a drop-in for the cycle: `take`, `state_dict` and
    `load_state_dict` all match, so checkpointing is unchanged.
    """

    def __init__(self, cycle, rows: list, *, key, factor: int, seed: int):
        self._cycle = cycle
        self._rows = rows
        self._key = key
        self._factor = factor
        self._rng = np.random.default_rng(seed)
        self._queue: list[list[int]] = []

    def take(self, count: int) -> list[int]:
        if not self._queue:
            drawn = [int(index) for index in self._cycle.take(count * self._factor)]
            drawn.sort(key=lambda index: self._key(self._rows[index]))
            self._queue = _shuffled_chunks(drawn, count, self._rng)
        return self._queue.pop()

    def state_dict(self) -> dict:
        return {
            "schema_version": 1,
            "cycle": self._cycle.state_dict(),
            "queue": [list(batch) for batch in self._queue],
            "rng": copy.deepcopy(self._rng.bit_generator.state),
        }

    def load_state_dict(self, state: dict) -> None:
        if state.get("schema_version") != 1 or "queue" not in state:
            raise ValueError("length-grouped cycle state contract failed")
        self._cycle.load_state_dict(state["cycle"])
        self._queue = [list(batch) for batch in state["queue"]]
        self._rng.bit_generator.state = copy.deepcopy(state["rng"])


def _progress_state(
    *,
    mode: str,
    completed_epochs: int,
    epoch_updates: int,
    epoch_loss_sum: float,
    epoch_loss_count: int,
    epoch_canonical_seen: int,
    updates: int,
    promptshield_draws: int,
    pair_draws: int,
    runtime_seconds: float,
    curve: list,
    best: dict | None,
    alternates: dict,
    head,
    encoder,
    optimizer,
    scheduler,
    promptshield_cycle,
    pair_cycle,
) -> dict:
    import torch

    return {
        "next_epoch": completed_epochs,
        "epoch_updates": epoch_updates,
        "epoch_loss_sum": float(epoch_loss_sum),
        "epoch_loss_count": epoch_loss_count,
        "epoch_canonical_seen": epoch_canonical_seen,
        "updates": updates,
        "promptshield_draws": promptshield_draws,
        "pair_draws": pair_draws,
        "runtime_seconds": runtime_seconds,
        "curve": curve,
        "best": best,
        "alternates": alternates,
        "head": _cpu_state(head),
        "adapter": _adapter_state(encoder) if mode == "lora" else None,
        "encoder": _lpft_state(encoder) if mode == "lpft" else None,
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict(),
        "promptshield_cycle": promptshield_cycle.state_dict(),
        "pair_cycle": pair_cycle.state_dict(),
        "torch_rng_state": torch.get_rng_state(),
        "cuda_rng_states": torch.cuda.get_rng_state_all(),
    }


def _head_contract(harmful_head: bool) -> dict:
    columns = {"0": "instruction_subversion"}
    if harmful_head:
        columns["1"] = "harmful_intent"
    return {
        "outputs": len(columns),
        "columns": columns,
        "primary_column": 0,
        "architecture": (
            "shared_trunk_separate_binary_projections_v1"
            if harmful_head
            else "legacy_sequential_binary_v1"
        ),
    }


def _harmful_objective_contract(
    counts: dict[str, int] | None,
    weights: dict[int, float] | None,
) -> dict | None:
    if counts is None and weights is None:
        return None
    if counts is None or weights is None or set(weights) != {0, 1}:
        raise ValueError("incomplete harmful-intent objective contract")
    population = sum(counts.values())
    known = counts["negative"] + counts["positive"]
    return {
        "target": "harmful_intent",
        "source": "canonical_train_security_tags_after_overlap_removal",
        "mask": "unknown_security_tags",
        "normalization": "known_class_balanced_masked_over_canonical_batch",
        "coefficient": DOMAIN_WEIGHT,
        "known_fraction": known / population,
        "effective_coefficient": DOMAIN_WEIGHT * known / population,
        "counts": dict(counts),
        "class_weights": {
            "negative": float(weights[0]),
            "positive": float(weights[1]),
        },
    }


def _training_identity(
    args: argparse.Namespace,
    data: TrainingData,
    *,
    run_name: str | None = None,
    harmful_counts: dict[str, int] | None = None,
    harmful_class_weights: dict[int, float] | None = None,
    optimizer_fused: bool | None = None,
) -> dict:
    harmful_head = bool(getattr(args, "harmful_head", False))
    harmful_objective = _harmful_objective_contract(
        harmful_counts, harmful_class_weights
    )
    if harmful_head != (harmful_objective is not None):
        raise ValueError("harmful-head identity requires its population contract")
    max_tokens = _runtime_max_tokens(args)
    return {
        "schema_version": 5,
        "run_name": run_name or _resolved_run_name(args),
        "mode": args.mode,
        "arm": _arm(args),
        "head_contract": _head_contract(harmful_head),
        "harmful_objective": harmful_objective,
        "attention": args.attention,
        "selection_rule": args.selection_rule,
        "validation_interval": args.validation_interval,
        "comparison_update": getattr(args, "comparison_update", 0),
        "snapshot_every": args.snapshot_every,
        "checkpoint_interval": args.checkpoint_interval,
        "pad_to_multiple_of": args.pad_to_multiple_of,
        "compiled": bool(args.compile_encoder),
        "compiled_backward_autocast": ("off" if args.compile_encoder else None),
        "encoding_cache": not args.no_encoding_cache,
        "seed": args.seed,
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "microbatch_size": args.microbatch_size,
        "max_tokens": max_tokens,
        "token_budget": args.microbatch_size * max_tokens,
        "shuffle_buffer": args.shuffle_buffer,
        "length_grouped": bool(args.length_grouped),
        "length_group_factor": args.length_group_factor,
        "warmup_fraction": args.warmup_fraction,
        "head_learning_rate": args.head_learning_rate,
        "adapter_learning_rate": args.adapter_learning_rate,
        "pair_ranking_weight": args.pair_ranking_weight,
        "optimizer": {
            "name": "AdamW",
            "betas": list(ADAMW_BETAS),
            "eps": ADAMW_EPS,
            "weight_decay": ADAMW_WEIGHT_DECAY,
            "fused": optimizer_fused,
            "gradient_clip_norm": GRADIENT_CLIP_NORM,
        },
        "gradient_checkpointing": (
            args.mode in {"lora", "lpft"} and not args.no_gradient_checkpointing
        ),
        "initial_head_sha256": (
            file_sha256(args.initial_head)
            if getattr(args, "initial_head", None) is not None
            else None
        ),
        "data": {
            "manifest_sha256": data.data_manifest_sha256,
            "external_manifest_sha256": data.external_manifest_sha256,
            "pair_archive_sha256": file_sha256(args.pairs),
            "additional_pair_archive_sha256": (
                file_sha256(args.additional_pairs)
                if args.additional_pairs is not None
                else None
            ),
            "routing_views": {
                split: spec["sha256"] for split, (_, spec) in data.views.items()
            },
            "populations": _report(data),
        },
        "sources": source_provenance(
            Path(__file__),
            Path(__file__).with_name("core.py"),
            Path(__file__).with_name("data.py"),
            Path(__file__).with_name("head_contract.py"),
        ),
    }


def _references(views: dict, external: dict):
    for split in ("validation", "dev_test"):
        path, spec = views[split]
        yield from canonical_rows(path, spec, split=split, eligible_only=False)
    for row in external["promptshield_validation"]:
        yield {**row, "_candidate_dataset": "promptshield_validation"}
    yield from external["promptshield_test"]
    yield from external["sep"]


# The only functions in this module that prepare the corpus. Everything else
# here -- the training loop, the save path, the CLI, the Trackio wiring -- can
# change without altering a single prepared row.
_PREP_SOURCE_FUNCTIONS = ("_prepare_training_data", "_references")


def _prep_source_digest() -> str:
    """Hash just the corpus-preparing sources in this module.

    Hashing the whole file meant any unrelated fix threw away a 502 MB cache and
    18 minutes of single-threaded work over 2.1M rows; that happened four times
    on 2026-08-07. Read from the file with `ast` rather than
    `inspect.getsource` on the live objects, so patching `_prepare_training_data`
    -- which the cache tests legitimately do -- still yields a stable key.
    """
    source = Path(__file__).read_text(encoding="utf-8")
    segments = sorted(
        ast.get_source_segment(source, node)
        for node in ast.parse(source).body
        if isinstance(node, ast.FunctionDef) and node.name in _PREP_SOURCE_FUNCTIONS
    )
    if len(segments) != len(_PREP_SOURCE_FUNCTIONS):
        raise ValueError("prep cache key cannot locate its source functions")
    return hashlib.sha256("\n".join(segments).encode("utf-8")).hexdigest()


def _prep_cache_key(
    data_dir: Path,
    external_dir: Path,
    pair_archive: Path,
    seed: int,
    additional_pair_archive: Path | None,
) -> str:
    """Digest of everything the prepared corpus depends on.

    Every input is hashed, not stat'd: the data contract fails closed on a
    changed digest, and a cache keyed on mtime would quietly hand back a corpus
    that no longer matches the manifest. The source files that do the preparing
    are hashed too, so editing the guard or the normaliser invalidates the
    cache without anyone remembering to bump a version.
    """
    parts = [
        "prep-cache-v1",
        str(seed),
        file_sha256(data_dir / "manifest.json"),
        file_sha256(external_dir / "manifest.json"),
        file_sha256(pair_archive),
        file_sha256(additional_pair_archive) if additional_pair_archive else "none",
    ]
    from ... import normalization
    from . import data as data_module

    parts.append(_prep_source_digest())
    for module in (data_module, normalization):
        parts.append(file_sha256(Path(module.__file__)))
    return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


def prepare_training_data(
    data_dir: Path,
    external_dir: Path,
    pair_archive: Path,
    *,
    seed: int = 42,
    additional_pair_archive: Path | None = None,
    cache_dir: Path | None = None,
) -> TrainingData:
    """Prepare the corpus, reusing a digest-keyed cache when one matches.

    The preparation itself costs ~17 minutes, almost all of it per-row overlap
    work: `_overlap_values` measures 299 us/row, so one pass over the 1,073,230
    canonical training rows is 5.4 minutes and the build makes several. Nothing
    about it varies between runs on the same corpus, so every restart paid it
    again -- four times in one afternoon on 2026-08-06.
    """
    if cache_dir is None:
        return _prepare_training_data(
            data_dir,
            external_dir,
            pair_archive,
            seed=seed,
            additional_pair_archive=additional_pair_archive,
        )
    key = _prep_cache_key(
        data_dir, external_dir, pair_archive, seed, additional_pair_archive
    )
    payload = cache_dir / f"{key}.pickle"
    digest = cache_dir / f"{key}.sha256"
    if payload.is_file() and digest.is_file():
        recorded = digest.read_text(encoding="utf-8").strip()
        if file_sha256(payload) == recorded:
            with payload.open("rb") as handle:
                data = pickle.load(handle)
            if isinstance(data, TrainingData):
                print(f"prepared corpus cache hit: {payload.name}", flush=True)
                return data
        # A corrupt or truncated cache is discarded rather than trusted.
        print("prepared corpus cache failed verification; rebuilding", flush=True)
        payload.unlink(missing_ok=True)
        digest.unlink(missing_ok=True)
    data = _prepare_training_data(
        data_dir,
        external_dir,
        pair_archive,
        seed=seed,
        additional_pair_archive=additional_pair_archive,
    )
    cache_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        dir=cache_dir, suffix=".partial", delete=False
    ) as handle:
        pickle.dump(data, handle, protocol=pickle.HIGHEST_PROTOCOL)
        temporary = Path(handle.name)
    # Publish the digest only after the payload is in place, so an interrupted
    # write can never be read back as valid.
    temporary.replace(payload)
    digest.write_text(file_sha256(payload) + "\n", encoding="utf-8")
    print(f"prepared corpus cached: {payload.name}", flush=True)
    return data


def _prepare_training_data(
    data_dir: Path,
    external_dir: Path,
    pair_archive: Path,
    *,
    seed: int = 42,
    additional_pair_archive: Path | None = None,
) -> TrainingData:
    views = routing_views(data_dir)
    external, _ = external_rows(external_dir)
    original_pairs = matched_pairs(pair_archive)
    if additional_pair_archive is not None:
        original_pairs += additional_matched_pairs(additional_pair_archive)
    candidates = {
        "promptshield": external["promptshield_train"],
        "promptshield_validation": external["promptshield_validation"],
        "pairs": [row for pair in original_pairs for row in pair],
    }
    guard = OverlapGuard(())
    kept, small_removed = filter_small_training_sets(
        candidates,
        _references(views, external),
        reference_guard=guard,
    )
    guard.add(chain(kept["promptshield"], kept["promptshield_validation"]))
    train_path, train_spec = views["train"]
    (
        counts,
        group_counts,
        canonical_removed,
        owners,
        pair_rows,
        pair_train_removed,
    ) = profile_canonical(
        canonical_rows(train_path, train_spec, split="train"),
        guard,
        {"pairs": kept["pairs"]},
    )
    kept_pair_ids = {row["id"] for row in pair_rows["pairs"]}
    pairs = [
        pair
        for pair in original_pairs
        if pair[0]["id"] in kept_pair_ids and pair[1]["id"] in kept_pair_ids
    ]
    dev_path, dev_spec = views["dev_test"]
    validation_guard = OverlapGuard(
        chain(
            canonical_rows(
                dev_path,
                dev_spec,
                split="dev_test",
                eligible_only=False,
            ),
            kept["promptshield_validation"],
            external["promptshield_test"],
            external["sep"],
        )
    )
    validation_path, validation_spec = views["validation"]
    validation_candidates = list(
        canonical_rows(validation_path, validation_spec, split="validation")
    )
    (
        _,
        _,
        validation_removed,
        validation_owners,
        _,
        _,
    ) = profile_canonical(validation_candidates, validation_guard, {})
    validation_rows = [
        row
        for row in validation_candidates
        if (
            (owner := validation_owners.get(_strict_hash(row["text"]))) is not None
            and owner[0] == row["id"]
        )
    ]
    validation_roles, validation_partition = partition_validation_records(
        validation_rows,
        seed=seed + 1,
    )
    checkpoint = validation_roles["checkpoint_selection"]
    calibration = validation_roles["calibration"]
    if not kept["promptshield"] or not pairs:
        raise ValueError("external training populations became empty")

    return TrainingData(
        views=views,
        data_manifest_sha256=file_sha256(data_dir / "manifest.json"),
        external_manifest_sha256=file_sha256(external_dir / "manifest.json"),
        promptshield=kept["promptshield"],
        promptshield_validation=kept["promptshield_validation"],
        pairs=pairs,
        checkpoint=checkpoint,
        calibration=calibration,
        validation_partition=validation_partition,
        canonical_counts=dict(counts),
        canonical_group_counts=dict(group_counts),
        canonical_owners=owners,
        removed={
            "canonical": canonical_removed,
            "validation": validation_removed,
            **small_removed,
            "pairs_against_canonical_train": pair_train_removed["pairs"],
            "pair_atoms": len(original_pairs) - len(pairs),
        },
    )


def _report(data: TrainingData) -> dict:
    return {
        "canonical_rows": sum(data.canonical_counts.values()),
        "canonical_strata": {
            f"{source}:{label}": count
            for (source, label), count in sorted(data.canonical_counts.items())
        },
        "promptshield_rows": len(data.promptshield),
        "matched_pairs": len(data.pairs),
        "checkpoint_rows": len(data.checkpoint),
        "calibration_rows": len(data.calibration),
        "validation_components": data.validation_partition["components"],
        "leakage_fingerprint": data.validation_partition["leakage_fingerprint"],
        "promptshield_validation_rows": len(data.promptshield_validation),
        "removed_for_overlap": data.removed,
    }


def _validate_population(args: argparse.Namespace, report: dict) -> None:
    """Pin the seed-invariant counts; bound the seed-dependent partition.

    `partition_validation_records` is seeded with `seed + 1`, so only
    `checkpoint_rows` and `calibration_rows` move across seeds. Their sum is
    invariant, and at the baseline seed both keep their exact historical values.
    """
    additional_pairs = getattr(args, "additional_pairs", None)
    expected = NEW_LPFT_POPULATION if additional_pairs is not None else FULL_POPULATION
    pinned = {key: report.get(key) for key in PINNED_POPULATION_KEYS}
    if pinned != {key: expected[key] for key in PINNED_POPULATION_KEYS}:
        raise ValueError(f"full-mixture population contract failed: {pinned!r}")

    checkpoint_rows = report.get("checkpoint_rows")
    calibration_rows = report.get("calibration_rows")
    partition = {
        "checkpoint_rows": checkpoint_rows,
        "calibration_rows": calibration_rows,
    }
    if (checkpoint_rows or 0) + (calibration_rows or 0) != VALIDATION_PARTITION_ROWS:
        raise ValueError(f"validation partition contract failed: {partition!r}")
    if args.seed == BASELINE_SEED:
        if partition != {key: expected[key] for key in partition}:
            raise ValueError(f"validation partition contract failed: {partition!r}")
        return
    fraction = checkpoint_rows / VALIDATION_PARTITION_ROWS
    low, high = CHECKPOINT_FRACTION_BOUNDS
    if not low <= fraction <= high:
        raise ValueError(f"validation partition contract failed: {partition!r}")


def _validate_arm(args: argparse.Namespace) -> dict:
    """Reject undeclared capacity rungs and unpinned learning rates."""
    arm = _arm(args)
    if arm["mode"] == "lora" and args.lora_rank < 1:
        raise ValueError("LoRA rank must be positive")
    if arm["mode"] == "lpft" and args.lpft_top_layers < 1:
        raise ValueError("LP-FT top layers must be positive")
    rates = BASELINE_ARM_RATES.get(_arm_key(arm))
    if rates is not None:
        expected_head, expected_adapter = rates
        if (args.head_learning_rate, args.adapter_learning_rate) != (
            expected_head,
            expected_adapter,
        ):
            raise ValueError(
                f"pinned learning rates for arm {_arm_key(arm)!r} are "
                f"{expected_head} and {expected_adapter}"
            )
    return arm


def _validate_full_recipe(args: argparse.Namespace, report: dict) -> None:
    _runtime_max_tokens(args)
    additional_pairs = getattr(args, "additional_pairs", None)
    additional_pairs_valid = (
        # `frozen` never takes them; `lpft` requires them; `lora` may opt in.
        (args.mode != "frozen" if additional_pairs is not None else True)
        and (args.mode != "lpft" or additional_pairs is not None)
        and (
            additional_pairs is None
            or (
                additional_pairs.is_file()
                and file_sha256(additional_pairs) == NEW_LPFT_PAIR_ARCHIVE_SHA256
            )
        )
    )
    if not additional_pairs_valid:
        raise ValueError("full-mixture additional-pair contract failed")
    _validate_population(args, report)
    _validate_arm(args)
    expected_updates = (
        math.ceil(report["canonical_rows"] / args.batch_size) * args.epochs
    )
    comparison_update = getattr(args, "comparison_update", 0)
    if comparison_update > expected_updates:
        raise ValueError(
            f"comparison update {comparison_update} exceeds "
            f"the {expected_updates}-update training run"
        )

    recipe = {
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "shuffle_buffer": args.shuffle_buffer,
        "pair_ranking_weight": args.pair_ranking_weight,
        "gradient_checkpointing": (
            args.mode in {"lora", "lpft"} and not args.no_gradient_checkpointing
        ),
    }
    initial_head = getattr(args, "initial_head", None)
    initial_head_valid = (
        initial_head is not None
        and initial_head.is_file()
        and file_sha256(initial_head) == LPFT_INITIAL_HEAD_SHA256
    )
    if (
        recipe != PINNED_RECIPE
        or (args.mode == "frozen" and args.no_gradient_checkpointing)
        or (args.mode == "lpft" and not initial_head_valid)
        or (args.mode != "lpft" and initial_head is not None)
        or (args.resume and args.preflight_only)
    ):
        raise ValueError(f"full-mixture configuration contract failed: {recipe!r}")

    execution = {"seed": args.seed, "microbatch_size": args.microbatch_size}
    if args.seed < 0:
        raise ValueError("seed must be non-negative")
    if (
        args.microbatch_size < 2
        or args.microbatch_size % 2
        or args.microbatch_size > args.batch_size
    ):
        raise ValueError(f"execution contract failed: {execution!r}")


class BalancedIndexCycle:
    """Deterministic class-balanced cycling for PromptShield batches."""

    def __init__(self, labels: np.ndarray, *, seed: int) -> None:
        self._rng = np.random.default_rng(seed)
        self._pools = {
            label: np.flatnonzero(labels == label).astype(np.int64) for label in (0, 1)
        }
        if any(len(pool) == 0 for pool in self._pools.values()):
            raise ValueError("balanced cycle requires both labels")
        self._orders = {
            label: self._rng.permutation(pool) for label, pool in self._pools.items()
        }
        self._positions = {0: 0, 1: 0}

    def _take(self, label: int, count: int) -> list[int]:
        selected = []
        while len(selected) < count:
            order = self._orders[label]
            position = self._positions[label]
            available = min(count - len(selected), len(order) - position)
            selected.extend(order[position : position + available].tolist())
            position += available
            if position == len(order):
                order = self._rng.permutation(self._pools[label])
                position = 0
            self._orders[label] = order
            self._positions[label] = position
        return selected

    def take(self, count: int) -> np.ndarray:
        if count < 2 or count % 2:
            raise ValueError("class-balanced batch size must be positive and even")
        half = count // 2
        selected = self._take(0, half) + self._take(1, half)
        self._rng.shuffle(selected)
        return np.asarray(selected, dtype=np.int64)

    def state_dict(self) -> dict:
        return {
            "schema_version": 1,
            "pool_sizes": {label: len(pool) for label, pool in self._pools.items()},
            "orders": {label: order.tolist() for label, order in self._orders.items()},
            "positions": dict(self._positions),
            "rng": copy.deepcopy(self._rng.bit_generator.state),
        }

    def load_state_dict(self, state: dict) -> None:
        if state.get("schema_version") != 1 or state.get("pool_sizes") != {
            label: len(pool) for label, pool in self._pools.items()
        }:
            raise ValueError("balanced cycle state contract failed")
        for label, pool in self._pools.items():
            order = np.asarray(state.get("orders", {}).get(label), dtype=np.int64)
            position = state.get("positions", {}).get(label)
            if (
                order.shape != pool.shape
                or set(order.tolist()) != set(pool.tolist())
                or type(position) is not int
                or not 0 <= position < len(order)
            ):
                raise ValueError("balanced cycle state contract failed")
            self._orders[label] = order
            self._positions[label] = position
        self._rng.bit_generator.state = copy.deepcopy(state["rng"])


class PairIndexCycle:
    """Deterministic cycling over complete matched-pair atoms."""

    def __init__(self, pairs: int, *, seed: int) -> None:
        if pairs < 1:
            raise ValueError("pair cycle requires at least one pair")
        self._rng = np.random.default_rng(seed)
        self._pool = np.arange(pairs, dtype=np.int64)
        self._order = self._rng.permutation(self._pool)
        self._position = 0

    def take(self, count: int) -> np.ndarray:
        if count < 1:
            raise ValueError("pair batch must be positive")
        selected = []
        while len(selected) < count:
            available = min(count - len(selected), len(self._order) - self._position)
            selected.extend(
                self._order[self._position : self._position + available].tolist()
            )
            self._position += available
            if self._position == len(self._order):
                self._order = self._rng.permutation(self._pool)
                self._position = 0
        return np.asarray(selected, dtype=np.int64)

    def state_dict(self) -> dict:
        return {
            "schema_version": 1,
            "pairs": len(self._pool),
            "order": self._order.tolist(),
            "position": self._position,
            "rng": copy.deepcopy(self._rng.bit_generator.state),
        }

    def load_state_dict(self, state: dict) -> None:
        order = np.asarray(state.get("order"), dtype=np.int64)
        position = state.get("position")
        if (
            state.get("schema_version") != 1
            or state.get("pairs") != len(self._pool)
            or order.shape != self._pool.shape
            or set(order.tolist()) != set(self._pool.tolist())
            or type(position) is not int
            or not 0 <= position < len(order)
        ):
            raise ValueError("pair cycle state contract failed")
        self._order = order
        self._position = position
        self._rng.bit_generator.state = copy.deepcopy(state["rng"])


def _classification_backward(
    encoder,
    tokenizer,
    head,
    rows: list[dict],
    *,
    coefficient: float,
    microbatch_size: int,
    train_encoder: bool,
    cache: _EncodingCache | None = None,
    pad_to_multiple_of: int | None = None,
    max_tokens: int = MAX_TOKENS,
) -> object:
    import torch

    total = None
    for batch in batches(rows, microbatch_size):
        logits = _cached_batch_logits(
            encoder,
            tokenizer,
            head,
            [row["text"] for row in batch],
            train_encoder=train_encoder,
            cache=cache,
            pad_to_multiple_of=pad_to_multiple_of,
            max_tokens=max_tokens,
        )
        targets = torch.tensor(
            [row["label"] for row in batch],
            dtype=torch.float32,
            device="cuda",
        )
        weights = torch.tensor(
            [row.get("weight", 1.0) for row in batch],
            dtype=torch.float32,
            device="cuda",
        )
        losses = torch.nn.functional.binary_cross_entropy_with_logits(
            logits.float(),
            targets,
            reduction="none",
        )
        loss = coefficient * (losses * weights).sum() / len(rows)
        loss.backward()
        total = loss.detach() if total is None else total + loss.detach()
    return total


def _pair_backward(
    encoder,
    tokenizer,
    head,
    pairs: list[tuple[dict, dict]],
    *,
    ranking_weight: float,
    microbatch_size: int,
    train_encoder: bool,
    cache: _EncodingCache | None = None,
    pad_to_multiple_of: int | None = None,
    max_tokens: int = MAX_TOKENS,
) -> object:
    import torch

    total = None
    pair_microbatch = max(1, microbatch_size // 2)
    for batch in batches(pairs, pair_microbatch):
        benign = [pair[0] for pair in batch]
        attack = [pair[1] for pair in batch]
        logits = _cached_batch_logits(
            encoder,
            tokenizer,
            head,
            [row["text"] for row in [*benign, *attack]],
            train_encoder=train_encoder,
            cache=cache,
            pad_to_multiple_of=pad_to_multiple_of,
            max_tokens=max_tokens,
        ).float()
        benign_logits, attack_logits = logits.split(len(batch))
        pair_bce = 0.5 * (
            torch.nn.functional.softplus(benign_logits).mean()
            + torch.nn.functional.softplus(-attack_logits).mean()
        )
        ranking = torch.nn.functional.softplus(-(attack_logits - benign_logits)).mean()
        scale = len(batch) / len(pairs)
        loss = scale * (DOMAIN_WEIGHT * pair_bce + ranking_weight * ranking)
        loss.backward()
        total = loss.detach() if total is None else total + loss.detach()
    return total


def _bce_from_logits(labels: np.ndarray, logits: np.ndarray) -> float:
    labels = np.asarray(labels, dtype=np.float64)
    logits = np.asarray(logits, dtype=np.float64)
    if (
        labels.ndim != 1
        or logits.ndim != 1
        or labels.shape != logits.shape
        or not len(labels)
        or not np.isin(labels, (0, 1)).all()
        or not np.isfinite(logits).all()
    ):
        raise ValueError("validation BCE requires finite aligned binary rows")
    return float(np.mean(np.logaddexp(0.0, logits) - labels * logits))


def _validation_logits(
    encoder,
    tokenizer,
    head,
    texts: list[str],
    *,
    batch_size: int,
    max_tokens: int = MAX_TOKENS,
) -> np.ndarray:
    """Cap-aware validation logits with an exact historical 512 path."""
    import torch

    if max_tokens == MAX_TOKENS:
        return score_logits(
            encoder,
            tokenizer,
            head,
            texts,
            batch_size=batch_size,
        )
    encoder.eval()
    head.eval()
    outputs = []
    with torch.no_grad():
        for batch in batches(texts, batch_size):
            values = _cached_batch_logits(
                encoder,
                tokenizer,
                head,
                batch,
                train_encoder=False,
                cache=None,
                max_tokens=max_tokens,
            )
            outputs.append(values.float().cpu().numpy())
    if not outputs:
        return np.empty(0, dtype=np.float64)
    return np.concatenate(outputs).astype(np.float64)


def _validation_bce(
    encoder,
    tokenizer,
    head,
    rows: list[dict],
    *,
    batch_size: int,
    max_tokens: int = MAX_TOKENS,
) -> float:
    logits = _validation_logits(
        encoder,
        tokenizer,
        head,
        [row["text"] for row in rows],
        batch_size=batch_size,
        max_tokens=max_tokens,
    )
    labels = np.asarray([row["label"] for row in rows])
    return _bce_from_logits(labels, logits)


def _validation_bce_by_source(
    encoder,
    tokenizer,
    head,
    rows: list[dict],
    *,
    batch_size: int,
    max_tokens: int = MAX_TOKENS,
) -> tuple[float, dict[str, float]]:
    """Row-weighted BCE alongside the per-source breakdown.

    Aggregate validation loss is dominated by whichever sources are largest,
    which is the first durable warning in the model ledger and the reason a
    run can look better while transferring worse. Returning both lets
    selection use the source-macro mean instead.
    """
    logits = _validation_logits(
        encoder,
        tokenizer,
        head,
        [row["text"] for row in rows],
        batch_size=batch_size,
        max_tokens=max_tokens,
    )
    labels = np.asarray([row["label"] for row in rows])
    grouped: dict[str, list[int]] = {}
    for index, row in enumerate(rows):
        grouped.setdefault(row.get("source", "unknown"), []).append(index)
    by_source = {
        source: _bce_from_logits(labels[indices], logits[indices])
        for source, indices in sorted(grouped.items())
    }
    return _bce_from_logits(labels, logits), by_source


def _multitask_validation_by_source(
    encoder,
    tokenizer,
    head,
    rows: list[dict],
    *,
    batch_size: int,
    max_tokens: int = MAX_TOKENS,
) -> tuple[float, dict[str, float], dict]:
    """Score both head columns once and summarize the masked auxiliary target."""
    import torch
    from sklearn.metrics import average_precision_score, roc_auc_score

    outputs = []
    with torch.no_grad():
        for batch in batches(rows, batch_size):
            values = _cached_batch_logits(
                encoder,
                tokenizer,
                head,
                [row["text"] for row in batch],
                train_encoder=False,
                cache=None,
                column=None,
                max_tokens=max_tokens,
            )
            if values.ndim != 2 or values.shape[1] != 2:
                raise ValueError("multitask validation requires two head columns")
            outputs.append(values.float().cpu().numpy())
    logits = np.concatenate(outputs) if outputs else np.empty((0, 2))
    labels = np.asarray([row["label"] for row in rows])
    grouped: dict[str, list[int]] = {}
    for index, row in enumerate(rows):
        grouped.setdefault(row.get("source", "unknown"), []).append(index)
    primary_by_source = {
        source: _bce_from_logits(labels[indices], logits[indices, 0])
        for source, indices in sorted(grouped.items())
    }

    def summarize(indices: list[int]) -> dict:
        known = [index for index in indices if _harmful_label(rows[index]) is not None]
        known_labels = np.asarray(
            [_harmful_label(rows[index]) for index in known], dtype=np.int64
        )
        known_logits = logits[known, 1]
        negative = known_labels == 0
        positive = known_labels == 1
        scores = 1.0 / (1.0 + np.exp(-np.clip(known_logits, -80.0, 80.0)))
        both = bool(negative.any() and positive.any())
        return {
            "rows": len(indices),
            "known_rows": len(known),
            "negative_rows": int(negative.sum()),
            "positive_rows": int(positive.sum()),
            "bce": (
                _bce_from_logits(known_labels, known_logits) if len(known) else None
            ),
            "auroc": (
                float(roc_auc_score(known_labels, known_logits)) if both else None
            ),
            "average_precision": (
                float(average_precision_score(known_labels, known_logits))
                if both
                else None
            ),
            "negative_mean_score": (
                float(scores[negative].mean()) if negative.any() else None
            ),
            "positive_mean_score": (
                float(scores[positive].mean()) if positive.any() else None
            ),
        }

    all_indices = list(range(len(rows)))
    harmful = summarize(all_indices)
    harmful["by_source"] = {
        source: summarize(indices) for source, indices in sorted(grouped.items())
    }
    return _bce_from_logits(labels, logits[:, 0]), primary_by_source, harmful


def _selection_loss(bces: dict[str, float], by_source: dict[str, dict], rule: str):
    """Equal-domain mean of Morgott and PromptShield validation BCE.

    `micro` reproduces the registered rule exactly. `source_macro` replaces the
    Morgott term with the unweighted mean across its sources, so a large source
    can no longer mask a regression on every small one.
    """
    if rule == "micro":
        return 0.5 * sum(bces.values())
    sources = by_source.get("morgott") or {}
    morgott = sum(sources.values()) / len(sources) if sources else bces["morgott"]
    return 0.5 * (morgott + bces["promptshield"])


def _validation_row(
    encoder,
    tokenizer,
    head,
    data: TrainingData,
    args: argparse.Namespace,
    *,
    epoch: int,
    updates: int,
    training_loss: float,
    canonical_seen: int,
) -> dict:
    """One point on the validation curve, at an epoch or mid-epoch boundary."""
    was_training = encoder.training
    encoder.eval()
    head.eval()
    try:
        harmful = None
        max_tokens = _runtime_max_tokens(args)
        if getattr(args, "harmful_head", False):
            morgott, morgott_sources, harmful = _multitask_validation_by_source(
                encoder,
                tokenizer,
                head,
                data.checkpoint,
                batch_size=args.microbatch_size,
                max_tokens=max_tokens,
            )
        else:
            morgott, morgott_sources = _validation_bce_by_source(
                encoder,
                tokenizer,
                head,
                data.checkpoint,
                batch_size=args.microbatch_size,
                max_tokens=max_tokens,
            )
        promptshield, _ = _validation_bce_by_source(
            encoder,
            tokenizer,
            head,
            data.promptshield_validation,
            batch_size=args.microbatch_size,
            max_tokens=max_tokens,
        )
    finally:
        encoder.train(was_training)
        head.train()
    bces = {"morgott": morgott, "promptshield": promptshield}
    by_source = {"morgott": morgott_sources}
    worst = max(morgott_sources.items(), key=lambda item: item[1], default=(None, None))
    return {
        "epoch": epoch,
        "updates": updates,
        "training_loss": training_loss,
        "canonical_rows_seen": canonical_seen,
        **{f"validation_{name}_bce": value for name, value in bces.items()},
        "validation_macro_bce": 0.5 * sum(bces.values()),
        "validation_morgott_source_macro_bce": (
            sum(morgott_sources.values()) / len(morgott_sources)
            if morgott_sources
            else morgott
        ),
        "validation_worst_source": worst[0],
        "validation_worst_source_bce": worst[1],
        "validation_morgott_by_source": morgott_sources,
        **(
            {
                **{
                    f"validation_harmful_{name}": value
                    for name, value in harmful.items()
                    if name != "by_source"
                },
                "validation_harmful_by_source": harmful["by_source"],
            }
            if harmful is not None
            else {}
        ),
        "selection_rule": args.selection_rule,
        "selection_loss": _selection_loss(bces, by_source, args.selection_rule),
        "pre_registered_comparison": bool(
            getattr(args, "comparison_update", 0) and updates == args.comparison_update
        ),
    }


def _cpu_state(module) -> dict:
    return {
        name: value.detach().contiguous().cpu().clone()
        for name, value in module.state_dict().items()
    }


def _adapter_state(encoder) -> dict:
    from peft import get_peft_model_state_dict

    return {
        name: value.detach().contiguous().cpu().clone()
        for name, value in get_peft_model_state_dict(encoder).items()
    }


def _lpft_state(encoder) -> dict:
    return {
        name: value.detach().contiguous().cpu().clone()
        for name, value in encoder.named_parameters()
        if value.requires_grad
    }


def _restore_lpft_state(encoder, state: dict) -> None:
    current = dict(encoder.named_parameters())
    expected = {name for name, value in current.items() if value.requires_grad}
    if set(state) != expected:
        raise ValueError("LP-FT state contract failed")
    for name, value in state.items():
        current[name].data.copy_(value)


def _selected_checkpoint_provenance(
    curve: list[dict],
    *,
    selected_epoch: int,
    selected_updates: int,
    selection_rule: str,
) -> dict:
    """Bind packaged weights to one exact validation point.

    Epoch alone is not an identity once interim validation is enabled: Arm 6
    has dozens of epoch-3 checkpoints, including the selected update 17,000
    and the source-macro alternate at update 23,000.  Publication therefore
    fails closed unless the selected state maps to one unique curve row.  The
    selection role and the pre-registered-comparison role are intentionally
    separate because one checkpoint may have both (as Arm 6 did by chance).
    """
    if (
        type(selected_epoch) is not int
        or selected_epoch < 1
        or type(selected_updates) is not int
        or selected_updates < 1
    ):
        raise ValueError("selected checkpoint epoch and updates must be positive")
    matches = [
        row
        for row in curve
        if row.get("epoch") == selected_epoch and row.get("updates") == selected_updates
    ]
    if len(matches) != 1:
        raise ValueError("selected checkpoint must identify one validation point")
    row = matches[0]
    loss = row.get("selection_loss")
    if (
        row.get("selection_rule") != selection_rule
        or not isinstance(loss, (int, float))
        or isinstance(loss, bool)
        or not math.isfinite(loss)
        or type(row.get("pre_registered_comparison")) is not bool
        or ("interim" in row and type(row["interim"]) is not bool)
    ):
        raise ValueError("selected checkpoint validation contract failed")
    return {
        "epoch": selected_epoch,
        "updates": selected_updates,
        "selection_role": "secondary",
        "selection_rule": selection_rule,
        "selection_loss": float(loss),
        "validation_point_role": (
            "periodic_validation" if row.get("interim", False) else "epoch_final"
        ),
        "pre_registered_comparison": row["pre_registered_comparison"],
    }


def _save_run(
    output: Path,
    *,
    mode: str,
    seed: int,
    head,
    encoder,
    report: dict,
    curve: list[dict],
    selected_epoch: int,
    selected_updates: int,
    args: argparse.Namespace,
    data: TrainingData,
    seconds: float,
    run_name: str | None = None,
    harmful_counts: dict[str, int] | None = None,
    harmful_class_weights: dict[int, float] | None = None,
    training_identity: dict | None = None,
    optimizer_fused: bool | None = None,
) -> Path:
    import torch
    from safetensors.torch import save_file

    name = run_name or _resolved_run_name(args)
    comparison_update = getattr(args, "comparison_update", 0)
    harmful_objective = _harmful_objective_contract(
        harmful_counts, harmful_class_weights
    )
    if bool(args.harmful_head) != (harmful_objective is not None):
        raise ValueError("harmful-head result requires its population contract")
    max_tokens = _runtime_max_tokens(args)
    current_identity = _training_identity(
        args,
        data,
        run_name=name,
        harmful_counts=harmful_counts,
        harmful_class_weights=harmful_class_weights,
        optimizer_fused=optimizer_fused,
    )
    if training_identity is not None and training_identity != current_identity:
        raise ValueError("training source or identity changed before publication")
    training_identity = current_identity
    selected_checkpoint = _selected_checkpoint_provenance(
        curve,
        selected_epoch=selected_epoch,
        selected_updates=selected_updates,
        selection_rule=args.selection_rule,
    )
    destination = output / name
    if destination.exists():
        raise FileExistsError(f"refusing to replace existing output: {destination}")
    output.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(dir=output, prefix=f".{name}-"))
    try:
        head_path = temporary / "head.safetensors"
        save_file(_cpu_state(head), str(head_path))
        adapter_files = None
        if mode == "lora":
            adapter = temporary / "adapter"
            encoder.save_pretrained(adapter, safe_serialization=True)
            adapter_files = {
                path.name: file_sha256(path)
                for path in sorted(adapter.iterdir())
                if path.is_file()
            }
        lpft_path = None
        if mode == "lpft":
            lpft_path = temporary / "encoder.safetensors"
            save_file(_lpft_state(encoder), str(lpft_path))
        targeted_modules = (
            sorted(
                name
                for name, module in encoder.named_modules()
                if hasattr(module, "lora_A")
            )
            if mode == "lora"
            else None
        )
        result = {
            "schema_version": 1,
            "purpose": "maintained full-data advisory mmBERT training",
            "adaptation": mode,
            "run_name": name,
            "training_identity": training_identity,
            "generic_target": "instruction_subversion",
            "head_contract": _head_contract(bool(args.harmful_head)),
            "positive_classes": list(INSTRUCTION_SUBVERSION_TAGS),
            "model_id": MODEL_ID,
            "model_revision": MODEL_REVISION,
            "attention_implementation": ATTENTION_IMPLEMENTATION,
            "normalization": "strict",
            "max_tokens": max_tokens,
            "token_budget": args.microbatch_size * max_tokens,
            "seed": seed,
            "lora": (
                {
                    "rank": args.lora_rank,
                    "alpha": args.lora_rank * (LORA_ALPHA // LORA_RANK),
                    "dropout": LORA_DROPOUT,
                    "bias": "none",
                    "task_type": "FEATURE_EXTRACTION",
                    "target_modules_regex": LORA_TARGETS,
                    "targeted_modules": targeted_modules,
                    "adapter_parameters": sum(
                        parameter.numel()
                        for parameter in encoder.parameters()
                        if parameter.requires_grad
                    ),
                }
                if mode == "lora"
                else None
            ),
            "lpft": (
                {
                    "top_layers": args.lpft_top_layers,
                    "include_embeddings": bool(args.lpft_include_embeddings),
                    "trainable_parameters": sum(
                        parameter.numel()
                        for parameter in encoder.parameters()
                        if parameter.requires_grad
                    ),
                    "trainable_names": sorted(
                        name
                        for name, parameter in encoder.named_parameters()
                        if parameter.requires_grad
                    ),
                    "initial_head_sha256": file_sha256(args.initial_head),
                }
                if mode == "lpft"
                else None
            ),
            "objective": {
                "domains": {
                    "morgott": DOMAIN_WEIGHT,
                    "promptshield": DOMAIN_WEIGHT,
                    "matched_pairs": DOMAIN_WEIGHT,
                },
                "canonical_weighting": "label_source_group_balanced",
                "promptshield_sampling": "class_balanced_cycle",
                "matched_pair_sampling": "complete_pair_cycle",
                "pair_ranking_weight": args.pair_ranking_weight,
                "harmful_intent": harmful_objective,
            },
            "training": {
                "epochs": args.epochs,
                "batch_size": args.batch_size,
                "promptshield_batch_size": args.batch_size // 2,
                "pair_batch_pairs": args.batch_size // 4,
                "microbatch_size": args.microbatch_size,
                "max_tokens": max_tokens,
                "token_budget": args.microbatch_size * max_tokens,
                "mixed_precision": "bfloat16",
                "gradient_checkpointing": (
                    mode in {"lora", "lpft"} and not args.no_gradient_checkpointing
                ),
                "head_learning_rate": args.head_learning_rate,
                "adapter_learning_rate": (
                    args.adapter_learning_rate if mode == "lora" else None
                ),
                "encoder_learning_rate": (
                    args.adapter_learning_rate if mode == "lpft" else None
                ),
                "optimizer": {
                    "name": "AdamW",
                    "betas": list(ADAMW_BETAS),
                    "eps": ADAMW_EPS,
                    "weight_decay": ADAMW_WEIGHT_DECAY,
                    "fused": optimizer_fused,
                    "gradient_clip_norm": GRADIENT_CLIP_NORM,
                },
                "shuffle_buffer": args.shuffle_buffer,
                "warmup_fraction": args.warmup_fraction,
                "warmup_updates": (
                    max(
                        int(
                            math.ceil(report["canonical_rows"] / args.batch_size)
                            * args.epochs
                            * args.warmup_fraction
                        ),
                        1,
                    )
                    if args.warmup_fraction > 0
                    else 0
                ),
                "length_grouped": bool(args.length_grouped),
                "length_group_factor": args.length_group_factor,
                "within_batch_order": "raw_character_length_ascending",
                "updates": math.ceil(report["canonical_rows"] / args.batch_size)
                * args.epochs,
                "selected_epoch": selected_epoch,
                "selected_updates": selected_updates,
                "selected_checkpoint": selected_checkpoint,
                "comparison_protocol": {
                    "pre_registered_update": comparison_update or None,
                    "pre_registered_snapshot": bool(comparison_update),
                    "complete_all_updates": True,
                    "early_stopping": False,
                    "selection_rule_role": "secondary",
                    "epoch_final_role": "descriptive",
                },
                "checkpoint_selection": (
                    "minimum equal-domain mean of Morgott and PromptShield "
                    "validation BCE"
                ),
                "curve": curve,
            },
            "arm": _arm(args),
            "execution": {
                "run_name": name,
                "baseline": BASELINE_EXECUTION,
                "seed": seed,
                "microbatch_size": args.microbatch_size,
                "max_tokens": max_tokens,
                "token_budget": args.microbatch_size * max_tokens,
                "attention_implementation": args.attention,
                "pad_to_multiple_of": args.pad_to_multiple_of,
                "compiled": bool(args.compile_encoder),
                "compiled_backward_autocast": ("off" if args.compile_encoder else None),
                "encoding_cache": not args.no_encoding_cache,
                "checkpoint_interval": args.checkpoint_interval,
                "comparison_update": comparison_update,
                "snapshot_every": args.snapshot_every,
                "validation_partition_seed": seed + 1,
                "deviations": {
                    key: value
                    for key, value in (
                        ("seed", seed),
                        ("microbatch_size", args.microbatch_size),
                        ("max_tokens", max_tokens),
                    )
                    if (MAX_TOKENS if key == "max_tokens" else BASELINE_EXECUTION[key])
                    != value
                },
                "gradient_accumulation": (
                    "exact: the classification loss is normalised by the whole "
                    "optimiser batch and the pair loss by len(batch)/len(pairs), "
                    "so the summed gradient does not depend on the microbatch "
                    "partition"
                ),
                "microbatch_caveat": (
                    "not bitwise-neutral: dropout draw shapes, per-microbatch "
                    "padding, and accumulation order all depend on the "
                    "partition, so runs at different microbatch sizes are "
                    "statistically equivalent but not reproducible against "
                    "each other"
                ),
            },
            "populations": report,
            "runtime_seconds": seconds,
            "runtime": {
                "seconds": seconds,
                "device": torch.cuda.get_device_name(),
                "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            },
            "packages": {
                package: version(package)
                for package in (
                    "numpy",
                    "peft",
                    "safetensors",
                    "torch",
                    "transformers",
                )
            },
            "artifact": {
                "weights_provenance": {
                    "source": "training.selected_checkpoint",
                    "epoch": selected_epoch,
                    "updates": selected_updates,
                },
                "head": "head.safetensors",
                "head_sha256": file_sha256(head_path),
                "adapter": "adapter" if adapter_files else None,
                "adapter_files": adapter_files,
                "encoder": lpft_path.name if lpft_path else None,
                "encoder_sha256": file_sha256(lpft_path) if lpft_path else None,
            },
            "provenance": {
                "routing_views": {
                    split: {
                        "path": spec["path"],
                        "sha256": spec["sha256"],
                        "rows": spec["rows"],
                    }
                    for split, (_, spec) in data.views.items()
                },
                "data_manifest_sha256": data.data_manifest_sha256,
                "external_manifest_sha256": data.external_manifest_sha256,
                "pair_archive_sha256": file_sha256(args.pairs),
                "additional_pair_archive_sha256": (
                    file_sha256(args.additional_pairs)
                    if args.additional_pairs is not None
                    else None
                ),
                **source_provenance(
                    Path(__file__),
                    Path(__file__).with_name("core.py"),
                    Path(__file__).with_name("data.py"),
                    Path(__file__).with_name("head_contract.py"),
                    Path(__file__).with_name("external_data.py"),
                    Path(__file__).resolve().parents[2] / "data.py",
                    Path(__file__).resolve().parents[2] / "normalization.py",
                    Path(__file__).resolve().parents[2] / "overlap.py",
                ),
            },
            "limitations": [
                "This is development evidence, not a production calibration.",
                "PromptShield and SEP are already-open development benchmarks.",
                f"Inputs are truncated to the first {max_tokens} normalized tokens.",
                *(
                    [
                        "The harmful-intent auxiliary objective uses class-only "
                        "population balancing, not source balancing; scarce "
                        "harmful non-subversion evidence limits its claim."
                    ]
                    if args.harmful_head
                    else []
                ),
                "The score is advisory and is not approved for blocking.",
            ],
        }
        (temporary / "result.json").write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, destination)
        return destination
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)


def train(args: argparse.Namespace, data: TrainingData) -> Path:
    import torch
    from safetensors.torch import load_file

    run_name = _resolved_run_name(args)
    max_tokens = _runtime_max_tokens(args)
    train_path, train_spec = data.views["train"]
    canonical_stream = _EpochStream(
        lambda: training_rows(
            canonical_rows(train_path, train_spec, split="train"),
            data.canonical_counts,
            data.canonical_group_counts,
            data.canonical_owners,
        ),
        expected_rows=sum(data.canonical_counts.values()),
    )
    harmful_counts = None
    harmful_class_weights = None
    if args.harmful_head:
        # The weights must describe the exact post-overlap canonical population.
        # This pass also fills `_EpochStream`, so it replaces rather than adds to
        # the first epoch's JSON/hash/weighting traversal.
        harmful_counts, harmful_class_weights = _harmful_balance(canonical_stream)

    torch.manual_seed(args.seed)
    encoder, tokenizer = (
        load_base_model()
        if args.attention == ATTENTION_IMPLEMENTATION
        else _load_base_model_with_attention(
            FA2_KERNEL if args.attention == "fa2" else args.attention
        )
    )
    encoding_cache = (
        None
        if args.no_encoding_cache
        else _EncodingCache(tokenizer, max_tokens=max_tokens)
    )
    train_encoder = args.mode in {"lora", "lpft"}
    if train_encoder:
        if not args.no_gradient_checkpointing:
            encoder.gradient_checkpointing_enable(
                gradient_checkpointing_kwargs={"use_reentrant": False}
            )
            encoder.enable_input_require_grads()
        if args.mode == "lora":
            encoder = (
                add_lora(encoder)
                if args.lora_rank == LORA_RANK
                else _add_lora(
                    encoder,
                    rank=args.lora_rank,
                    alpha=args.lora_rank * (LORA_ALPHA // LORA_RANK),
                )
            )
        else:
            _configure_lpft(
                encoder,
                top_layers=args.lpft_top_layers,
                include_embeddings=bool(args.lpft_include_embeddings),
            )
    else:
        encoder.gradient_checkpointing_disable()
        for parameter in encoder.parameters():
            parameter.requires_grad = False
    head = (
        _new_multitask_head(encoder.config.hidden_size, args.seed, 2)
        if args.harmful_head
        else new_head(encoder.config.hidden_size, args.seed)
    ).to("cuda")
    if args.mode == "lpft":
        head.load_state_dict(load_file(str(args.initial_head)), strict=True)
    head_parameters = list(head.parameters())
    parameters = [{"params": head_parameters, "lr": args.head_learning_rate}]
    if train_encoder:
        adapter_parameters = [
            parameter for parameter in encoder.parameters() if parameter.requires_grad
        ]
        parameters.append(
            {
                "params": adapter_parameters,
                "lr": args.adapter_learning_rate,
            }
        )
    # Ada has TF32 tensor cores; the head and adapters are the only fp32
    # tensors, and their matmuls do not need full fp32 mantissa.
    torch.set_float32_matmul_precision("high")
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    # Fused AdamW folds the per-parameter elementwise work into one kernel.
    try:
        optimizer = torch.optim.AdamW(
            parameters,
            betas=ADAMW_BETAS,
            eps=ADAMW_EPS,
            weight_decay=ADAMW_WEIGHT_DECAY,
            fused=True,
        )
    except (RuntimeError, ValueError):
        optimizer = torch.optim.AdamW(
            parameters,
            betas=ADAMW_BETAS,
            eps=ADAMW_EPS,
            weight_decay=ADAMW_WEIGHT_DECAY,
        )
    optimizer_fused = bool(optimizer.defaults.get("fused", False))
    tracker = _RunTracker(
        args,
        run_name=run_name,
        config={
            "run_name": run_name,
            "arm": _arm(args),
            "recipe": PINNED_RECIPE,
            "head_contract": _head_contract(bool(args.harmful_head)),
            "harmful_objective": _harmful_objective_contract(
                harmful_counts, harmful_class_weights
            ),
            "seed": args.seed,
            "microbatch_size": args.microbatch_size,
            "max_tokens": max_tokens,
            "token_budget": args.microbatch_size * max_tokens,
            "attention": args.attention,
            "compiled": bool(args.compile_encoder),
            "compiled_backward_autocast": ("off" if args.compile_encoder else None),
            "pad_to_multiple_of": args.pad_to_multiple_of,
            "selection_rule": args.selection_rule,
            "validation_interval": args.validation_interval,
            "snapshot_every": args.snapshot_every,
            "comparison_update": args.comparison_update,
            "harmful_head": bool(args.harmful_head),
            "warmup_fraction": args.warmup_fraction,
            "length_grouped": bool(args.length_grouped),
            "length_group_factor": args.length_group_factor,
            "data_manifest_sha256": data.data_manifest_sha256,
            "pair_archive_sha256": file_sha256(args.pairs),
            "additional_pair_archive_sha256": (
                file_sha256(args.additional_pairs)
                if args.additional_pairs is not None
                else None
            ),
            "optimizer": {
                "name": "AdamW",
                "betas": list(ADAMW_BETAS),
                "eps": ADAMW_EPS,
                "weight_decay": ADAMW_WEIGHT_DECAY,
                "fused": optimizer_fused,
                "gradient_clip_norm": GRADIENT_CLIP_NORM,
            },
        },
    )
    tracker.describe_metrics()
    if args.compile_encoder:
        # Measured +49.7% at microbatch 24. Left on torch's automatic dynamic
        # detection rather than forcing `dynamic=True`: length-sorted padding
        # produces many distinct shapes, and letting inductor specialise first
        # is what the throughput sweep actually measured.
        # In-place `.compile()`, not `torch.compile(m)`: the wrapper form
        # prefixes every state_dict key with `_orig_mod.`, which would corrupt
        # the saved head and adapter and break peft state extraction.
        _configure_compiled_backward_autocast()
        encoder.compile()
        head.compile()
    if encoding_cache is not None:
        encoding_cache.warm(
            chain(
                (row["text"] for row in data.promptshield),
                (row["text"] for pair in data.pairs for row in pair),
                (row["text"] for row in data.checkpoint),
                (row["text"] for row in data.promptshield_validation),
            ),
            workers=args.prewarm_workers,
        )
        print(f"encoding cache warmed: {len(encoding_cache)} texts", flush=True)
    promptshield_cycle = BalancedIndexCycle(
        np.asarray([row["label"] for row in data.promptshield], dtype=np.int64),
        seed=args.seed + 10_001,
    )
    pair_cycle = PairIndexCycle(len(data.pairs), seed=args.seed + 20_003)
    if args.length_grouped:
        promptshield_cycle = _LengthGroupedCycle(
            promptshield_cycle,
            data.promptshield,
            key=lambda row: len(row["text"]),
            factor=args.length_group_factor,
            seed=args.seed + 30_011,
        )
        pair_cycle = _LengthGroupedCycle(
            pair_cycle,
            data.pairs,
            # A pair is padded to its longer side, so that is what it costs.
            key=lambda pair: max(len(pair[0]["text"]), len(pair[1]["text"])),
            factor=args.length_group_factor,
            seed=args.seed + 40_013,
        )
    best = None
    alternates: dict[str, dict] = {}
    curve = []
    updates = 0
    promptshield_draws = 0
    pair_draws = 0
    next_epoch = 0
    prior_seconds = 0.0
    started = time.perf_counter()
    updates_per_epoch = math.ceil(sum(data.canonical_counts.values()) / args.batch_size)
    expected_updates = updates_per_epoch * args.epochs
    warmup_updates = (
        max(int(expected_updates * args.warmup_fraction), 1)
        if args.warmup_fraction > 0
        else 0
    )
    scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer,
        lambda step: (
            _lr_multiplier(
                step,
                total_updates=expected_updates,
                warmup_updates=warmup_updates,
            )
            if args.warmup_fraction > 0
            else 1.0
        ),
    )
    checkpoint_name = run_name
    checkpoint = args.output / f".{checkpoint_name}.checkpoint.pt"
    identity = _training_identity(
        args,
        data,
        run_name=run_name,
        harmful_counts=harmful_counts,
        harmful_class_weights=harmful_class_weights,
        optimizer_fused=optimizer_fused,
    )

    resume_epoch_updates = 0
    resume_epoch_loss_sum = 0.0
    resume_epoch_loss_count = 0
    resume_epoch_canonical_seen = 0
    if args.resume:
        if not checkpoint.is_file():
            raise FileNotFoundError(f"resume checkpoint does not exist: {checkpoint}")
        state = _load_checkpoint(checkpoint, identity=identity)
        next_epoch = state["next_epoch"]
        resume_epoch_updates = state["epoch_updates"]
        resume_epoch_loss_sum = state["epoch_loss_sum"]
        resume_epoch_loss_count = state["epoch_loss_count"]
        resume_epoch_canonical_seen = state["epoch_canonical_seen"]
        updates = state["updates"]
        promptshield_draws = state["promptshield_draws"]
        pair_draws = state["pair_draws"]
        prior_seconds = state["runtime_seconds"]
        curve = state["curve"]
        best = state["best"]
        alternates = state.get("alternates") or {}
        head.load_state_dict(state["head"], strict=True)
        if train_encoder:
            if args.mode == "lora":
                from peft import set_peft_model_state_dict

                set_peft_model_state_dict(encoder, state["adapter"])
            else:
                _restore_lpft_state(encoder, state["encoder"])
        optimizer.load_state_dict(state["optimizer"])
        scheduler.load_state_dict(state["scheduler"])
        promptshield_cycle.load_state_dict(state["promptshield_cycle"])
        pair_cycle.load_state_dict(state["pair_cycle"])
        torch.set_rng_state(state["torch_rng_state"])
        torch.cuda.set_rng_state_all(state["cuda_rng_states"])
        if (
            type(next_epoch) is not int
            or type(resume_epoch_updates) is not int
            or type(resume_epoch_canonical_seen) is not int
            or type(resume_epoch_loss_count) is not int
            or not isinstance(resume_epoch_loss_sum, (int, float))
            or not math.isfinite(resume_epoch_loss_sum)
            or resume_epoch_loss_sum < 0
            or not 0 <= next_epoch <= args.epochs
            or not 0 <= resume_epoch_updates < updates_per_epoch
            or (next_epoch == args.epochs and resume_epoch_updates != 0)
            or updates != next_epoch * updates_per_epoch + resume_epoch_updates
            or updates == 0
            # Epoch-boundary rows only. `--validation-interval` appends interim
            # rows to the same curve, so a plain `len(curve)` counts those too
            # and every mid-epoch resume failed the contract -- which is every
            # resume the supervisor exists to perform. Arm 4 hit this at update
            # 1,500 on 2026-08-07 with three interim rows and next_epoch 0.
            or sum(not row.get("interim") for row in curve) != next_epoch
            or resume_epoch_loss_count != resume_epoch_updates
            or (best is None and next_epoch > 0)
        ):
            raise ValueError("resume checkpoint progress contract failed")
        print(
            f"resuming at epoch {next_epoch + 1}/{args.epochs}, "
            f"update {updates}/{expected_updates}, "
            f"epoch batch {resume_epoch_updates}/{updates_per_epoch}",
            flush=True,
        )
    elif checkpoint.exists():
        raise FileExistsError(
            f"checkpoint already exists; pass --resume to use it: {checkpoint}"
        )

    snapshots = (
        _snapshot_dir(args.output, checkpoint_name)
        if args.snapshot_every or args.comparison_update
        else None
    )

    for epoch_index in range(next_epoch, args.epochs):
        epoch = epoch_index + 1
        encoder.train(train_encoder)
        head.train()
        epoch_loss_sum = 0.0
        epoch_loss_count = 0
        metric_window = _MetricWindow()
        canonical_seen = 0
        if canonical_stream.cached and file_sha256(train_path) != train_spec["sha256"]:
            # The cache replaces the per-epoch reread, so re-assert the digest
            # that reread used to verify.
            raise ValueError("canonical train view changed during training")
        stream = shuffled(
            canonical_stream,
            seed=args.seed + epoch_index,
            buffer_size=args.shuffle_buffer,
        )
        batch_iterator = (
            length_grouped_batches(
                stream,
                args.batch_size,
                key=lambda row: len(row["text"]),
                factor=args.length_group_factor,
                # Per epoch, so a resumed epoch replays the same batch order
                # that `_skip_resumed_batches` is about to walk past.
                rng=np.random.default_rng(args.seed + 50_021 + epoch_index),
            )
            if args.length_grouped
            else batches(stream, args.batch_size)
        )
        if epoch_index == next_epoch and resume_epoch_updates:
            canonical_seen = _skip_resumed_batches(
                batch_iterator,
                batches_consumed=resume_epoch_updates,
                canonical_seen=resume_epoch_canonical_seen,
            )
            epoch_loss_sum = float(resume_epoch_loss_sum)
            epoch_loss_count = resume_epoch_loss_count
        # Exclude stream construction and resume replay from optimizer
        # throughput.  The timer is reset again after each validation and
        # checkpoint so those I/O-heavy pauses do not depress the next window.
        metric_window_started = time.perf_counter()
        for morgott in batch_iterator:
            morgott.sort(key=lambda row: len(row["text"]))
            canonical_seen += len(morgott)
            optimizer.zero_grad(set_to_none=True)
            if args.harmful_head:
                canonical_metrics = _multitask_classification_backward(
                    encoder,
                    tokenizer,
                    head,
                    morgott,
                    coefficient=DOMAIN_WEIGHT,
                    harmful_class_weights=harmful_class_weights,
                    microbatch_size=args.microbatch_size,
                    train_encoder=train_encoder,
                    cache=encoding_cache,
                    pad_to_multiple_of=args.pad_to_multiple_of,
                    max_tokens=max_tokens,
                )
            else:
                canonical_primary = _classification_backward(
                    encoder,
                    tokenizer,
                    head,
                    morgott,
                    coefficient=DOMAIN_WEIGHT,
                    microbatch_size=args.microbatch_size,
                    train_encoder=train_encoder,
                    cache=encoding_cache,
                    pad_to_multiple_of=args.pad_to_multiple_of,
                    max_tokens=max_tokens,
                )
                zero = canonical_primary.new_zeros(())
                canonical_metrics = {
                    "canonical_primary_loss": canonical_primary,
                    "harmful_aux_loss": zero,
                    "harmful_positive_loss": zero,
                    "harmful_negative_loss": zero,
                }
            promptshield_indices = promptshield_cycle.take(args.batch_size // 2)
            promptshield_draws += len(promptshield_indices)
            promptshield_batch = sorted(
                [data.promptshield[int(index)] for index in promptshield_indices],
                key=lambda row: len(row["text"]),
            )
            promptshield_loss = _classification_backward(
                encoder,
                tokenizer,
                head,
                promptshield_batch,
                coefficient=DOMAIN_WEIGHT,
                microbatch_size=args.microbatch_size,
                train_encoder=train_encoder,
                cache=encoding_cache,
                pad_to_multiple_of=args.pad_to_multiple_of,
                max_tokens=max_tokens,
            )
            pair_indices = pair_cycle.take(args.batch_size // 4)
            pair_draws += len(pair_indices)
            pair_batch = sorted(
                [data.pairs[int(index)] for index in pair_indices],
                key=lambda pair: max(
                    len(pair[0]["text"]),
                    len(pair[1]["text"]),
                ),
            )
            pair_loss = _pair_backward(
                encoder,
                tokenizer,
                head,
                pair_batch,
                ranking_weight=args.pair_ranking_weight,
                microbatch_size=args.microbatch_size,
                train_encoder=train_encoder,
                cache=encoding_cache,
                pad_to_multiple_of=args.pad_to_multiple_of,
                max_tokens=max_tokens,
            )
            primary_loss = (
                canonical_metrics["canonical_primary_loss"]
                + promptshield_loss
                + pair_loss
            )
            loss = primary_loss + canonical_metrics["harmful_aux_loss"]
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                [parameter for group in parameters for parameter in group["params"]],
                GRADIENT_CLIP_NORM,
                error_if_nonfinite=True,
            )
            gradient_clipped = (gradient_norm > GRADIENT_CLIP_NORM).to(
                dtype=torch.float32
            )
            optimizer.step()
            scheduler.step()
            updates += 1
            metric_window.add(
                {
                    "total_loss": loss,
                    "primary_loss": primary_loss,
                    **canonical_metrics,
                    "promptshield_loss": promptshield_loss,
                    "pair_loss": pair_loss,
                    "pre_clip_gradient_norm": gradient_norm,
                    "gradient_clipped": gradient_clipped,
                },
                examples=(len(morgott) + len(promptshield_batch) + 2 * len(pair_batch)),
            )
            epoch_boundary = updates % updates_per_epoch == 0
            validation_due = bool(
                args.validation_interval
                and updates % args.validation_interval == 0
                and not epoch_boundary
            )
            checkpoint_due = bool(
                updates % args.checkpoint_interval == 0 and not epoch_boundary
            )
            log_due = bool(
                updates % 25 == 0 or epoch_boundary or updates == expected_updates
            )
            window_metrics = None
            if log_due or validation_due or checkpoint_due:
                totals, latest, window_updates, window_examples = metric_window.drain()
                window_seconds = max(
                    time.perf_counter() - metric_window_started,
                    np.finfo(np.float64).eps,
                )
                # Preserve the historical training-loss curve: it is the
                # three-part primary objective and intentionally excludes the
                # new auxiliary term.
                epoch_loss_sum += totals["primary_loss"]
                epoch_loss_count += window_updates
                window_metrics = {
                    key: value / window_updates for key, value in totals.items()
                }
                if log_due:
                    tracker.log(
                        {
                            # Keep the historical chart name and last-update
                            # semantics, while the named components are stable
                            # window averages.
                            "train/loss": latest["primary_loss"],
                            "train/primary_loss": window_metrics["primary_loss"],
                            "train/total_loss": window_metrics["total_loss"],
                            "train/canonical_primary_loss": window_metrics[
                                "canonical_primary_loss"
                            ],
                            "train/harmful_aux_loss": window_metrics[
                                "harmful_aux_loss"
                            ],
                            "train/harmful_positive_loss": window_metrics[
                                "harmful_positive_loss"
                            ],
                            "train/harmful_negative_loss": window_metrics[
                                "harmful_negative_loss"
                            ],
                            "train/promptshield_loss": window_metrics[
                                "promptshield_loss"
                            ],
                            "train/pair_loss": window_metrics["pair_loss"],
                            "train/pre_clip_gradient_norm": window_metrics[
                                "pre_clip_gradient_norm"
                            ],
                            "train/clip_fraction": window_metrics["gradient_clipped"],
                            "train/clipped_updates_in_window": totals[
                                "gradient_clipped"
                            ],
                            "train/epoch": epoch,
                            "train/canonical_seen": canonical_seen,
                            "train/peak_vram_gib": torch.cuda.max_memory_reserved()
                            / (1 << 30),
                            "train/head_lr": optimizer.param_groups[0]["lr"],
                            "performance/optimizer_updates_per_second": (
                                window_updates / window_seconds
                            ),
                            "performance/examples_per_second": (
                                window_examples / window_seconds
                            ),
                            "performance/window_updates": window_updates,
                            **(
                                {"train/adapter_lr": optimizer.param_groups[1]["lr"]}
                                if len(optimizer.param_groups) > 1
                                else {}
                            ),
                        },
                        step=updates,
                    )
            if updates % 100 == 0 or updates == expected_updates:
                elapsed = prior_seconds + time.perf_counter() - started
                eta = elapsed / updates * (expected_updates - updates)
                print(
                    f"epoch {epoch}/{args.epochs} update "
                    f"{updates}/{expected_updates} "
                    f"loss={window_metrics['primary_loss']:.5f} "
                    f"elapsed={elapsed / 3600:.2f}h "
                    f"eta={eta / 3600:.2f}h "
                    f"peak_vram={torch.cuda.max_memory_reserved() / (1 << 30):.2f}GiB",
                    flush=True,
                )
            if validation_due:
                interim = _validation_row(
                    encoder,
                    tokenizer,
                    head,
                    data,
                    args,
                    epoch=epoch,
                    updates=updates,
                    training_loss=epoch_loss_sum / epoch_loss_count,
                    canonical_seen=canonical_seen,
                )
                interim["interim"] = True
                curve.append(interim)
                tracker.log_validation(interim, step=updates)
                tracker.log_by_source(
                    interim["validation_morgott_by_source"],
                    step=updates,
                )
                if args.harmful_head:
                    tracker.log_harmful_by_source(
                        interim["validation_harmful_by_source"],
                        step=updates,
                    )
                print(
                    f"epoch {epoch} update {updates}/{expected_updates} "
                    f"selection_loss={interim['selection_loss']:.6f} "
                    f"worst_source={interim['validation_worst_source']}",
                    flush=True,
                )
                _update_alternates(
                    alternates,
                    interim,
                    mode=args.mode,
                    head=head,
                    encoder=encoder,
                    epoch=epoch,
                    updates=updates,
                )
                if snapshots is not None and _should_snapshot(args, updates):
                    _save_snapshot(
                        snapshots,
                        interim,
                        training_identity=identity,
                        mode=args.mode,
                        head=head,
                        encoder=encoder,
                        epoch=epoch,
                        updates=updates,
                    )
                    _write_snapshot_index(snapshots, curve)
                if best is None or interim["selection_loss"] < best["loss"]:
                    best = {
                        "loss": interim["selection_loss"],
                        "epoch": epoch,
                        "updates": updates,
                        "head": _cpu_state(head),
                        "adapter": (
                            _adapter_state(encoder) if args.mode == "lora" else None
                        ),
                        "encoder": (
                            _lpft_state(encoder) if args.mode == "lpft" else None
                        ),
                    }
            if checkpoint_due:
                _save_checkpoint(
                    checkpoint,
                    identity=identity,
                    state=_progress_state(
                        mode=args.mode,
                        completed_epochs=epoch_index,
                        epoch_updates=updates - epoch_index * updates_per_epoch,
                        epoch_loss_sum=epoch_loss_sum,
                        epoch_loss_count=epoch_loss_count,
                        epoch_canonical_seen=canonical_seen,
                        updates=updates,
                        promptshield_draws=promptshield_draws,
                        pair_draws=pair_draws,
                        runtime_seconds=(prior_seconds + time.perf_counter() - started),
                        curve=curve,
                        best=best,
                        alternates=alternates,
                        head=head,
                        encoder=encoder,
                        optimizer=optimizer,
                        scheduler=scheduler,
                        promptshield_cycle=promptshield_cycle,
                        pair_cycle=pair_cycle,
                    ),
                )
                print(
                    f"saved progress checkpoint at update "
                    f"{updates}/{expected_updates}: {checkpoint}",
                    flush=True,
                )
            if window_metrics is not None:
                metric_window_started = time.perf_counter()

        if canonical_seen != sum(data.canonical_counts.values()):
            raise ValueError(
                f"epoch {epoch} saw {canonical_seen} canonical rows, "
                f"expected {sum(data.canonical_counts.values())}"
            )
        if metric_window.updates or epoch_loss_count != updates_per_epoch:
            raise ValueError("training loss accumulation contract failed")

        row = _validation_row(
            encoder,
            tokenizer,
            head,
            data,
            args,
            epoch=epoch,
            updates=updates,
            training_loss=epoch_loss_sum / epoch_loss_count,
            canonical_seen=canonical_seen,
        )
        curve.append(row)
        tracker.log_validation(row, step=updates)
        tracker.log_by_source(row["validation_morgott_by_source"], step=updates)
        if args.harmful_head:
            tracker.log_harmful_by_source(
                row["validation_harmful_by_source"], step=updates
            )
        _update_alternates(
            alternates,
            row,
            mode=args.mode,
            head=head,
            encoder=encoder,
            epoch=epoch,
            updates=updates,
        )
        # Epoch boundaries snapshot unconditionally: they are the points the
        # constant-LR baseline actually peaked at, and there are only three.
        if snapshots is not None:
            _save_snapshot(
                snapshots,
                row,
                training_identity=identity,
                mode=args.mode,
                head=head,
                encoder=encoder,
                epoch=epoch,
                updates=updates,
            )
            _write_snapshot_index(snapshots, curve)
        if best is None or row["selection_loss"] < best["loss"]:
            best = {
                "loss": row["selection_loss"],
                "epoch": epoch,
                "updates": updates,
                "head": _cpu_state(head),
                "adapter": _adapter_state(encoder) if args.mode == "lora" else None,
                "encoder": _lpft_state(encoder) if args.mode == "lpft" else None,
            }
        elapsed = prior_seconds + time.perf_counter() - started
        _save_checkpoint(
            checkpoint,
            identity=identity,
            state=_progress_state(
                mode=args.mode,
                completed_epochs=epoch,
                epoch_updates=0,
                epoch_loss_sum=0.0,
                epoch_loss_count=0,
                epoch_canonical_seen=0,
                updates=updates,
                promptshield_draws=promptshield_draws,
                pair_draws=pair_draws,
                runtime_seconds=elapsed,
                curve=curve,
                best=best,
                alternates=alternates,
                head=head,
                encoder=encoder,
                optimizer=optimizer,
                scheduler=scheduler,
                promptshield_cycle=promptshield_cycle,
                pair_cycle=pair_cycle,
            ),
        )
        print(
            f"saved epoch {epoch}/{args.epochs} checkpoint: {checkpoint}",
            flush=True,
        )

    if (
        updates != expected_updates
        or promptshield_draws != expected_updates * (args.batch_size // 2)
        or pair_draws != expected_updates * (args.batch_size // 4)
    ):
        raise ValueError("training update or auxiliary draw contract failed")
    tracker.finish(
        {
            "selected_epoch": best["epoch"],
            "selected_updates": best.get("updates", 0),
            "selection_loss": best["loss"],
            "selection_rule": args.selection_rule,
            **{
                f"alternate_{name}_updates": candidate.get("updates", 0)
                for name, candidate in alternates.items()
            },
            **{
                f"alternate_{name}_loss": candidate["loss"]
                for name, candidate in alternates.items()
            },
        }
    )
    head.load_state_dict(best["head"], strict=True)
    if train_encoder:
        if args.mode == "lora":
            from peft import (
                get_peft_model_state_dict,
                set_peft_model_state_dict,
            )

            set_peft_model_state_dict(encoder, best["adapter"])
            restored = get_peft_model_state_dict(encoder)
            selected = best["adapter"]
        else:
            _restore_lpft_state(encoder, best["encoder"])
            restored = _lpft_state(encoder)
            selected = best["encoder"]
        if restored.keys() != selected.keys() or any(
            not torch.equal(restored[name].cpu(), selected[name]) for name in restored
        ):
            raise ValueError("restored encoder differs from the selected epoch")
    destination = _save_run(
        args.output,
        mode=args.mode,
        seed=args.seed,
        head=head,
        encoder=encoder,
        report=_report(data),
        curve=curve,
        selected_epoch=best["epoch"],
        selected_updates=best["updates"],
        args=args,
        data=data,
        seconds=prior_seconds + time.perf_counter() - started,
        run_name=run_name,
        harmful_counts=harmful_counts,
        harmful_class_weights=harmful_class_weights,
        training_identity=identity,
        optimizer_fused=optimizer_fused,
    )
    # After `_save_run`, never before. `_save_run` builds the run in a temp
    # directory and `os.replace`s it into place, which requires the destination
    # not to exist -- and `_save_alternates` writes *inside* that destination.
    # Ordered the other way it created the directory that `_save_run` then
    # refused, so every run that reached finalisation died with FileExistsError
    # after its training had already completed. Arm 1 lost its packaged output
    # that way on 2026-08-07 after 7.8 hours; the weights survived only because
    # the progress checkpoint and these alternates are written separately.
    _save_alternates(args.output, checkpoint_name, alternates, mode=args.mode)
    return destination


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("frozen", "lora", "lpft"), default="lora")
    parser.add_argument("--lora-rank", type=int, default=LORA_RANK)
    parser.add_argument("--lpft-top-layers", type=int, default=LPFT_TOP_LAYERS)
    parser.add_argument(
        "--lpft-include-embeddings",
        action="store_true",
        help="release the multilingual embedding table; only a true full fine-tune",
    )
    parser.add_argument(
        "--harmful-head",
        action="store_true",
        help=(
            "train an auxiliary masked harmful-intent logit beside the generic "
            "subversion logit; scoring and gating still use the generic logit"
        ),
    )
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument(
        "--external-dir",
        type=Path,
        default=Path("artifacts/mmbert/data"),
    )
    parser.add_argument(
        "--pairs",
        type=Path,
        default=Path("data-archive/matched_pairs_20260726.jsonl.gz"),
    )
    parser.add_argument("--additional-pairs", type=Path)
    parser.add_argument("--output", type=Path, default=Path("artifacts/mmbert/runs"))
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--microbatch-size", type=int, default=8)
    parser.add_argument(
        "--max-tokens",
        type=int,
        choices=SUPPORTED_MAX_TOKENS,
        default=MAX_TOKENS,
        help="normalized-token context cap; 512 preserves the registered recipe",
    )
    parser.add_argument("--shuffle-buffer", type=int, default=8192)
    parser.add_argument(
        "--prep-cache",
        type=Path,
        default=Path("artifacts/mmbert/prep-cache"),
        help="reuse a digest-keyed prepared corpus instead of rebuilding it; "
        "the key covers every input digest and the preparing source files, so a "
        "changed corpus or a changed guard misses rather than serves stale data",
    )
    parser.add_argument(
        "--no-prep-cache",
        dest="prep_cache",
        action="store_const",
        const=None,
        help="always rebuild the prepared corpus",
    )
    parser.add_argument(
        "--warmup-fraction",
        type=float,
        default=0.05,
        help="share of total updates spent in linear LR warmup; 0 disables both "
        "warmup and cosine decay and restores a constant rate",
    )
    parser.add_argument(
        "--no-length-grouped",
        dest="length_grouped",
        action="store_false",
        help="draw batches at random instead of grouping similar lengths; "
        "costs ~27%% more processed tokens per update",
    )
    parser.add_argument(
        "--length-group-factor",
        type=int,
        default=32,
        help="megabatch size as a multiple of the batch size; larger groups "
        "pad less but correlate batch content more strongly with length",
    )
    parser.add_argument("--head-learning-rate", type=float, default=3e-4)
    parser.add_argument("--adapter-learning-rate", type=float, default=1e-4)
    parser.add_argument("--initial-head", type=Path)
    parser.add_argument("--pair-ranking-weight", type=float, default=0.25)
    parser.add_argument("--no-gradient-checkpointing", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument(
        "--attention",
        choices=("sdpa", "fa2", "eager"),
        default=ATTENTION_IMPLEMENTATION,
        help="training-only attention kernel; maintained inference stays pinned",
    )
    parser.add_argument(
        "--pad-to-multiple-of",
        type=int,
        help=(
            "bucket padded length to a multiple; collapses the distinct-shape "
            "space for torch.compile at the cost of some masked positions"
        ),
    )
    parser.add_argument(
        "--compile",
        action="store_true",
        dest="compile_encoder",
        help="torch.compile the encoder; pair with --pad-to-multiple-of",
    )
    parser.add_argument(
        "--trackio",
        action="store_true",
        help="log scalars and config to a local Trackio store; never logs corpus text",
    )
    parser.add_argument("--trackio-project", default="morgott")
    parser.add_argument(
        "--run-name",
        "--trackio-name",
        dest="run_name",
        default=None,
        help=(
            "single identity used for the output directory, progress checkpoint, "
            "snapshots, result metadata, and Trackio label; defaults to a derived "
            "arm name. --trackio-name is a deprecated compatibility alias"
        ),
    )
    parser.add_argument(
        "--trackio-group",
        default="",
        help="group related arms, e.g. the capacity ladder",
    )
    parser.add_argument(
        "--trackio-space",
        default="",
        help="optional Hugging Face Space to mirror to; local-only when unset",
    )
    parser.add_argument(
        "--prewarm-workers",
        type=int,
        default=max(1, _usable_cpus() - 1),
        help="processes used to normalise the encoding cache before training",
    )
    parser.add_argument(
        "--selection-rule",
        choices=("micro", "source_macro"),
        default="micro",
        help=(
            "checkpoint selection metric; 'micro' reproduces the registered "
            "rule, 'source_macro' stops a large source masking small-source "
            "regressions"
        ),
    )
    parser.add_argument(
        "--validation-interval",
        type=int,
        default=0,
        help=(
            "validate every N updates as well as at epoch boundaries; 0 keeps "
            "the registered epoch-only cadence"
        ),
    )
    parser.add_argument(
        "--snapshot-every",
        type=int,
        default=0,
        help=(
            "also retain every validation point's weights every N updates, "
            "beside the run as .<name>.snapshots/; 0 keeps only the three "
            "rule-selected candidates"
        ),
    )
    parser.add_argument(
        "--comparison-update",
        type=int,
        default=0,
        help=(
            "pre-registered validation update whose weights are retained "
            "unconditionally; 0 disables the fixed comparison point"
        ),
    )
    parser.add_argument(
        "--checkpoint-interval",
        type=int,
        default=CHECKPOINT_UPDATE_INTERVAL,
        help="updates between atomic progress checkpoints for --resume",
    )
    parser.add_argument(
        "--no-encoding-cache",
        action="store_true",
        help="disable the normalisation/tokenisation cache (slower; for A/B)",
    )
    return parser


def main() -> int:
    args = _parser().parse_args()
    run_name = _resolved_run_name(args)
    numeric = (
        args.epochs,
        args.batch_size,
        args.microbatch_size,
        args.shuffle_buffer,
        args.head_learning_rate,
        args.adapter_learning_rate,
    )
    if args.seed < 0 or any(
        not math.isfinite(value) or value <= 0 for value in numeric
    ):
        raise ValueError("training parameters must be finite and positive")
    if not math.isfinite(args.pair_ranking_weight) or args.pair_ranking_weight < 0:
        raise ValueError("pair ranking weight must be finite and non-negative")
    if args.batch_size < 4 or args.batch_size % 4 or args.microbatch_size % 2:
        raise ValueError("batch size must be divisible by four and microbatch by two")
    if not math.isfinite(args.warmup_fraction) or not 0 <= args.warmup_fraction < 1:
        raise ValueError("warmup fraction must be finite and in [0, 1)")
    if (
        args.lora_rank < 1
        or args.lpft_top_layers < 1
        or args.length_group_factor < 1
        or args.checkpoint_interval < 1
        or args.prewarm_workers < 0
        or args.validation_interval < 0
        or args.comparison_update < 0
        or (args.pad_to_multiple_of is not None and args.pad_to_multiple_of < 1)
    ):
        raise ValueError("training intervals, ranks, and grouping sizes are invalid")
    if args.snapshot_every < 0:
        raise ValueError("snapshot interval must be non-negative")
    # A snapshot only exists where a validation row does, so an interval that
    # is not a multiple of the validation cadence would silently never fire.
    if args.snapshot_every and (
        not args.validation_interval or args.snapshot_every % args.validation_interval
    ):
        raise ValueError(
            "--snapshot-every must be a positive multiple of --validation-interval"
        )
    if args.comparison_update and (
        not args.validation_interval
        or args.comparison_update % args.validation_interval
    ):
        raise ValueError(
            "--comparison-update must be a positive multiple of --validation-interval"
        )
    if not args.preflight_only:
        _preflight_execution(args, run_name)
    data = prepare_training_data(
        args.data_dir,
        args.external_dir,
        args.pairs,
        seed=args.seed,
        additional_pair_archive=args.additional_pairs,
        cache_dir=args.prep_cache,
    )
    report = _report(data)
    _validate_full_recipe(args, report)
    print(json.dumps(report, indent=2, sort_keys=True))
    if args.preflight_only:
        return 0
    destination = train(args, data)
    print(destination)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
