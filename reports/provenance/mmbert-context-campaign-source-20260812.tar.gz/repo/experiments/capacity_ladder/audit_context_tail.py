"""Aggregate-only full-population audit for the 512-to-1024 context ablation.

The default is a no-write plan. ``--run`` tokenizes every exact post-overlap
training, validation, and standard evaluation input used by the current
no-harm recipe, then publishes only aggregate counts. Prompt text, row IDs,
pair IDs, token sequences, and hashes of individual rows are never persisted.
"""

from __future__ import annotations

import argparse
import json
import os
import tempfile
import time
from collections import Counter
from itertools import chain
from pathlib import Path

from morgott.models.mmbert.core import (
    MAX_TOKENS,
    MODEL_ID,
    MODEL_REVISION,
    file_sha256,
    source_provenance,
)
from morgott.models.mmbert.data import (
    batches,
    canonical_rows,
    external_rows,
    training_rows,
)
from morgott.models.mmbert.train import (
    NEW_LPFT_PAIR_ARCHIVE_SHA256,
    NEW_LPFT_POPULATION,
    _report,
    prepare_training_data,
)
from morgott.normalization import strict_normalize

BASELINE_CAP = 512
CANDIDATE_CAP = 1024
OBSERVATION_CAP = CANDIDATE_CAP + 1
SEED = 42
MINIMUM_AFFECTED_PER_LABEL = 300
DEFAULT_OUTPUT = Path("artifacts/mmbert/context-tail-audit-cap512-vs1024-s42.json")
DEFAULT_ADDITIONAL_PAIRS = Path(
    "artifacts/mmbert_lpft_new_data_rebuilt/train/pairs.jsonl.gz"
)
_FORBIDDEN_PERSISTED_KEYS = frozenset(
    {"id", "row_id", "pair_id", "text", "prompt", "prompts", "input_ids"}
)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--run",
        action="store_true",
        help="execute the CPU/tokenizer audit and write the aggregate artifact",
    )
    mode.add_argument(
        "--verify",
        type=Path,
        help="verify an existing aggregate artifact against current inputs/sources",
    )
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument(
        "--external-dir", type=Path, default=Path("artifacts/mmbert/data")
    )
    parser.add_argument(
        "--pairs",
        type=Path,
        default=Path("data-archive/matched_pairs_20260726.jsonl.gz"),
    )
    parser.add_argument(
        "--additional-pairs", type=Path, default=DEFAULT_ADDITIONAL_PAIRS
    )
    parser.add_argument(
        "--prep-cache", type=Path, default=Path("artifacts/mmbert/prep-cache")
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--tokenizer-batch-size", type=int, default=1024)
    return parser


def _provenance() -> dict:
    root = Path(__file__).resolve().parents[2]
    return source_provenance(
        Path(__file__),
        root / "src/morgott/models/mmbert/train.py",
        root / "src/morgott/models/mmbert/data.py",
        root / "src/morgott/models/mmbert/core.py",
        root / "src/morgott/normalization.py",
    )


def _input_identity(args: argparse.Namespace) -> dict:
    return {
        "data_manifest_sha256": file_sha256(args.data_dir / "manifest.json"),
        "external_manifest_sha256": file_sha256(args.external_dir / "manifest.json"),
        "pair_archive_sha256": file_sha256(args.pairs),
        "additional_pair_archive_sha256": file_sha256(args.additional_pairs),
        "seed": SEED,
    }


def _length_bucket(length: int) -> str:
    if length <= BASELINE_CAP:
        return "1-512"
    if length <= CANDIDATE_CAP:
        return "513-1024"
    return ">1024"


def _token_ids(tokenizer, texts: list[str]) -> list[list[int]]:
    encoded = tokenizer(
        [strict_normalize(text) for text in texts],
        add_special_tokens=True,
        max_length=OBSERVATION_CAP,
        truncation=True,
    )["input_ids"]
    return [list(values) for values in encoded]


def _audit_populations(populations, tokenizer, *, batch_size: int) -> tuple[list, dict]:
    grouped: Counter = Counter()
    affected_by_label: Counter = Counter()
    population_totals: Counter = Counter()
    for population, rows in populations:
        for batch in batches(rows, batch_size):
            token_ids = _token_ids(tokenizer, [row["text"] for row in batch])
            for row, ids in zip(batch, token_ids, strict=True):
                label = row.get("label")
                source = row.get("source")
                channel = row.get("input_channel")
                if (
                    type(label) is not int
                    or label not in (0, 1)
                    or not isinstance(source, str)
                    or not source
                    or channel not in {"direct_user", "untrusted_content"}
                ):
                    raise ValueError("invalid row in context-tail population")
                bucket = _length_bucket(len(ids))
                grouped[(population, source, label, channel, bucket)] += 1
                population_totals[(population, label, bucket)] += 1
                if len(ids) > BASELINE_CAP:
                    affected_by_label[label] += 1

    records = []
    dimensions = sorted({key[:4] for key in grouped})
    for population, source, label, channel in dimensions:
        bucket_counts = {
            bucket: grouped[(population, source, label, channel, bucket)]
            for bucket in ("1-512", "513-1024", ">1024")
        }
        records.append(
            {
                "population": population,
                "source": source,
                "label": label,
                "channel": channel,
                "rows": sum(bucket_counts.values()),
                "affected_by_512_truncation": (
                    bucket_counts["513-1024"] + bucket_counts[">1024"]
                ),
                "visible_within_1024": bucket_counts["513-1024"],
                "still_truncated_at_1024": bucket_counts[">1024"],
                "observed_token_length_buckets": bucket_counts,
            }
        )
    totals = [
        {
            "population": population,
            "label": label,
            "rows": sum(
                population_totals[(population, label, bucket)]
                for bucket in ("1-512", "513-1024", ">1024")
            ),
            "affected_by_512_truncation": (
                population_totals[(population, label, "513-1024")]
                + population_totals[(population, label, ">1024")]
            ),
        }
        for population, label in sorted({key[:2] for key in population_totals})
    ]
    return records, {
        "population_label_totals": totals,
        "affected_by_label": {
            "clean": affected_by_label[0],
            "attack": affected_by_label[1],
        },
    }


def _first_difference(left: list[int], right: list[int]) -> int | None:
    for index, (left_id, right_id) in enumerate(
        zip(left, right, strict=False), start=1
    ):
        if left_id != right_id:
            return index
    if len(left) != len(right):
        return min(len(left), len(right)) + 1
    return None


def _difference_bucket(position: int | None) -> str:
    if position is None:
        return "no_difference_through_1025"
    if position <= BASELINE_CAP:
        return "1-512"
    if position <= CANDIDATE_CAP:
        return "513-1024"
    return ">1024"


def _audit_pairs(pairs, tokenizer, *, batch_size: int) -> list[dict]:
    grouped: Counter = Counter()
    for pair_batch in batches(pairs, max(1, batch_size // 2)):
        flattened = list(chain.from_iterable(pair_batch))
        encoded = _token_ids(tokenizer, [row["text"] for row in flattened])
        for index, (benign, attack) in enumerate(pair_batch):
            left, right = encoded[2 * index : 2 * index + 2]
            if benign.get("label") != 0 or attack.get("label") != 1:
                raise ValueError("matched-pair label order changed")
            source = (
                benign["source"]
                if benign.get("source") == attack.get("source")
                else f"{benign.get('source')}->{attack.get('source')}"
            )
            channel = f"{benign.get('input_channel')}->{attack.get('input_channel')}"
            grouped[
                (
                    source,
                    channel,
                    _difference_bucket(_first_difference(left, right)),
                    len(left) > BASELINE_CAP,
                    len(right) > BASELINE_CAP,
                )
            ] += 1

    summaries: dict[tuple[str, str], Counter] = {}
    for (
        source,
        channel,
        difference,
        benign_affected,
        attack_affected,
    ), count in grouped.items():
        summary = summaries.setdefault((source, channel), Counter())
        summary["pairs"] += count
        summary[f"difference:{difference}"] += count
        summary["benign_affected"] += count * benign_affected
        summary["attack_affected"] += count * attack_affected
        summary["both_affected"] += count * (benign_affected and attack_affected)
    return [
        {
            "population": "training/matched_pairs",
            "source": source,
            "channel": channel,
            "benign_label": 0,
            "attack_label": 1,
            "pairs": summary["pairs"],
            "benign_affected_by_512_truncation": summary["benign_affected"],
            "attack_affected_by_512_truncation": summary["attack_affected"],
            "both_sides_affected_by_512_truncation": summary["both_affected"],
            "first_differing_token_position_buckets": {
                bucket: summary[f"difference:{bucket}"]
                for bucket in (
                    "1-512",
                    "513-1024",
                    ">1024",
                    "no_difference_through_1025",
                )
            },
        }
        for (source, channel), summary in sorted(summaries.items())
    ]


def _validate_aggregate_only(value) -> None:
    if isinstance(value, dict):
        forbidden = _FORBIDDEN_PERSISTED_KEYS & set(value)
        if forbidden:
            raise ValueError(f"aggregate artifact contains forbidden keys: {forbidden}")
        for nested in value.values():
            _validate_aggregate_only(nested)
    elif isinstance(value, list):
        for nested in value:
            _validate_aggregate_only(nested)


def _write_once_json(path: Path, value: dict) -> None:
    _validate_aggregate_only(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"refusing to replace context-tail audit: {path}")
    payload = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        handle.write(payload)
        temporary = Path(handle.name)
    try:
        os.link(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _population_contract(report: dict) -> None:
    observed = {
        key: report.get(key)
        for key in (
            "canonical_rows",
            "promptshield_rows",
            "matched_pairs",
            "checkpoint_rows",
            "calibration_rows",
            "validation_components",
            "promptshield_validation_rows",
        )
    }
    expected = {key: NEW_LPFT_POPULATION[key] for key in observed}
    if observed != expected:
        raise ValueError(f"no-harm full-population contract failed: {observed!r}")


def _run(args: argparse.Namespace) -> dict:
    if MAX_TOKENS != BASELINE_CAP:
        raise ValueError("tail audit baseline no longer matches core.MAX_TOKENS")
    if file_sha256(args.additional_pairs) != NEW_LPFT_PAIR_ARCHIVE_SHA256:
        raise ValueError("additional matched-pair archive digest changed")
    from transformers import AutoTokenizer

    started = time.perf_counter()
    prepared = prepare_training_data(
        args.data_dir,
        args.external_dir,
        args.pairs,
        seed=SEED,
        additional_pair_archive=args.additional_pairs,
        cache_dir=args.prep_cache,
    )
    prepared_report = _report(prepared)
    _population_contract(prepared_report)
    external, _ = external_rows(args.external_dir)
    train_path, train_spec = prepared.views["train"]
    dev_path, dev_spec = prepared.views["dev_test"]
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REVISION)
    populations = (
        (
            "training/canonical",
            training_rows(
                canonical_rows(train_path, train_spec, split="train"),
                prepared.canonical_counts,
                prepared.canonical_group_counts,
                prepared.canonical_owners,
            ),
        ),
        ("training/promptshield", iter(prepared.promptshield)),
        (
            "training/matched_pair_sides",
            chain.from_iterable(prepared.pairs),
        ),
        ("validation/checkpoint_selection", iter(prepared.checkpoint)),
        ("validation/calibration", iter(prepared.calibration)),
        ("validation/promptshield", iter(prepared.promptshield_validation)),
        (
            "evaluation/canonical_dev_test",
            canonical_rows(dev_path, dev_spec, split="dev_test"),
        ),
        ("evaluation/promptshield_test", iter(external["promptshield_test"])),
        ("evaluation/sep", iter(external["sep"])),
    )
    population_records, totals = _audit_populations(
        populations,
        tokenizer,
        batch_size=args.tokenizer_batch_size,
    )
    pair_records = _audit_pairs(
        prepared.pairs,
        tokenizer,
        batch_size=args.tokenizer_batch_size,
    )
    affected = totals["affected_by_label"]
    gate_passed = all(
        affected[label] >= MINIMUM_AFFECTED_PER_LABEL for label in ("clean", "attack")
    )
    result = {
        "schema_version": 1,
        "purpose": "aggregate context-tail eligibility audit",
        "experiment": "no-harm context-length ablation",
        "caps": {
            "baseline": BASELINE_CAP,
            "candidate": CANDIDATE_CAP,
            "observation_cap": OBSERVATION_CAP,
        },
        "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "inputs": _input_identity(args),
        "prepared_population_contract": prepared_report,
        "measurement": {
            "normalization": "strict_normalize",
            "tokenizer_special_tokens": True,
            "token_lengths": (
                "observed through 1025 tokens; >1024 includes every sequence "
                "that reaches the 1025-token observation cap"
            ),
            "pair_difference_position": (
                "one-based first differing tokenizer position after strict "
                "normalization and special-token insertion"
            ),
        },
        "population_source_label_channel_counts": population_records,
        "population_label_totals": totals["population_label_totals"],
        "pair_first_differing_token_positions": pair_records,
        "gate": {
            "criterion": (
                "at least 300 clean and 300 attack row instances exceed the "
                "512-token baseline across the exact audited populations"
            ),
            "minimum_affected_per_label": MINIMUM_AFFECTED_PER_LABEL,
            "affected_by_512_truncation": affected,
            "passed": gate_passed,
        },
        "privacy": {
            "aggregate_counts_only": True,
            "raw_prompt_material_persisted": False,
            "row_identifiers_persisted": False,
            "token_sequences_persisted": False,
        },
        "runtime": {
            "seconds": time.perf_counter() - started,
            "tokenizer_batch_size": args.tokenizer_batch_size,
        },
        "provenance": _provenance(),
    }
    _validate_aggregate_only(result)
    return result


def _verify(path: Path, args: argparse.Namespace) -> dict:
    report = json.loads(path.read_text(encoding="utf-8"))
    _validate_aggregate_only(report)
    gate = report.get("gate") if isinstance(report, dict) else None
    affected = (
        gate.get("affected_by_512_truncation") if isinstance(gate, dict) else None
    )
    gate_valid = bool(
        isinstance(affected, dict)
        and gate.get("minimum_affected_per_label") == MINIMUM_AFFECTED_PER_LABEL
        and type(affected.get("clean")) is int
        and type(affected.get("attack")) is int
        and affected["clean"] >= MINIMUM_AFFECTED_PER_LABEL
        and affected["attack"] >= MINIMUM_AFFECTED_PER_LABEL
        and gate.get("passed") is True
    )
    if (
        report.get("schema_version") != 1
        or report.get("purpose") != "aggregate context-tail eligibility audit"
        or report.get("caps")
        != {
            "baseline": BASELINE_CAP,
            "candidate": CANDIDATE_CAP,
            "observation_cap": OBSERVATION_CAP,
        }
        or report.get("inputs") != _input_identity(args)
        or report.get("provenance") != _provenance()
        or report.get("privacy", {}).get("aggregate_counts_only") is not True
        or not gate_valid
    ):
        raise ValueError("context-tail audit is stale, malformed, or did not pass")
    return {
        "verified": True,
        "path": str(path),
        "gate": report["gate"],
    }


def main() -> int:
    args = _parser().parse_args()
    if args.tokenizer_batch_size < 1:
        raise ValueError("tokenizer batch size must be positive")
    if args.verify is not None:
        print(json.dumps(_verify(args.verify, args), indent=2, sort_keys=True))
        return 0
    if not args.run:
        print(
            json.dumps(
                {
                    "mode": "dry-run",
                    "caps": [BASELINE_CAP, CANDIDATE_CAP],
                    "minimum_affected_per_label": MINIMUM_AFFECTED_PER_LABEL,
                    "output": str(args.output),
                    "writes": False,
                    "gpu_work": False,
                    "next_step": "pass --run to execute the aggregate-only audit",
                },
                indent=2,
                sort_keys=True,
            )
        )
        return 0
    result = _run(args)
    _write_once_json(args.output, result)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
