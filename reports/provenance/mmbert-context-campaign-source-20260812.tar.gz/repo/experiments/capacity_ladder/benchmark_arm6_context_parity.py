"""Dry-by-default Arm 6 cap-1024 same-backend correctness diagnostic.

This experiment isolates the one unresolved result from the 512-to-1024
context canary: the cap-1024 Inductor gradient cosine.  It executes only the
forced longest-width correctness update, never an optimizer step, and forces
PyTorch's memory-efficient SDPA backend for every comparison cell.

Three fresh seed-42 replicas are measured for uncompiled execution and for
``torch.compile`` with the eager, AOT-eager, and Inductor backends.  Gradient
vectors remain in memory only.  The write-once report contains scalar losses,
aggregate numerical diagnostics, parameter names/shapes, and SHA-256 hashes;
it never contains prompt text, row identities, predictions, or gradient
arrays.

Running without ``--run`` only prints the resolved plan and does not import
Torch, load data, touch CUDA, or write an artifact::

    HF_HOME=/workspace/hf_cache \
      LD_LIBRARY_PATH=/usr/local/cuda-13.0/compat${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH} \
      CUDA_VISIBLE_DEVICES=0 \
      uv run --locked --extra encoder \
      python experiments/capacity_ladder/benchmark_arm6_context_parity.py --run
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import os
import tempfile
import time
from collections import Counter
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from importlib.metadata import version
from itertools import chain
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

try:
    from experiments.capacity_ladder import benchmark_arm6_context_canary as canary
    from experiments.capacity_ladder import benchmark_arm6_l40s as arm6
except ModuleNotFoundError as error:
    if error.name != "experiments":
        raise
    import benchmark_arm6_context_canary as canary
    import benchmark_arm6_l40s as arm6
from morgott.models.mmbert.core import (
    LORA_RANK,
    MAX_TOKENS,
    MODEL_ID,
    MODEL_REVISION,
    add_lora,
    source_provenance,
)
from morgott.models.mmbert.train import (
    _configure_compiled_backward_autocast,
    _new_multitask_head,
    prepare_training_data,
)

if TYPE_CHECKING:
    from collections.abc import Iterator, Sequence


CAP = 1024
REPLICAS = 3
DEFAULT_MICROBATCH_SIZE = 24
DEFAULT_OUTPUT_ROOT = Path("artifacts/mmbert")
MODES = (
    {"name": "uncompiled", "compile_backend": None},
    {"name": "dynamo-eager", "compile_backend": "eager"},
    {"name": "aot-eager", "compile_backend": "aot_eager"},
    {"name": "inductor", "compile_backend": "inductor"},
)
EFFICIENT_EVENT_MARKERS = ("efficient_attention",)
DISALLOWED_EVENT_MARKERS = (
    "flash_attention",
    "cudnn_attention",
    "attention_math",
    "scaled_dot_product_attention_math",
)


@dataclass
class _ProbeData:
    record: dict
    whole_gradient: np.ndarray
    parameter_gradients: dict[str, np.ndarray]


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--run",
        action="store_true",
        help="execute the GPU diagnostic; the default only prints the plan",
    )
    mode.add_argument(
        "--dry-run",
        action="store_true",
        help="explicit spelling of the default no-GPU, no-write behavior",
    )
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument(
        "--external-dir", type=Path, default=Path("artifacts/mmbert/data")
    )
    parser.add_argument(
        "--pairs",
        type=Path,
        default=Path("data-archive/matched_pairs_20260726.jsonl.gz"),
    )
    parser.add_argument(
        "--additional-pairs",
        type=Path,
        default=Path("artifacts/mmbert_lpft_new_data_rebuilt/train/pairs.jsonl.gz"),
    )
    parser.add_argument(
        "--prep-cache", type=Path, default=Path("artifacts/mmbert/prep-cache")
    )
    parser.add_argument("--microbatch-size", type=int, default=DEFAULT_MICROBATCH_SIZE)
    parser.add_argument(
        "--output",
        type=Path,
        help="write-once result path; its name must contain the full identity",
    )
    parser.add_argument(
        "--allow-non-l40s",
        action="store_true",
        help="development-only escape hatch; the report still records the device",
    )
    return parser


def _identity(microbatch_size: int) -> str:
    return (
        f"arm6-context-parity-cap{CAP}-efficient-s{arm6.SEED}"
        f"-r{REPLICAS}-mb{microbatch_size}"
    )


def _resolve_output(output: Path | None, *, microbatch_size: int) -> tuple[str, Path]:
    identity = _identity(microbatch_size)
    resolved = output or DEFAULT_OUTPUT_ROOT / f"{identity}.json"
    if identity not in resolved.name:
        raise ValueError(
            "output filename must contain the complete resolved experiment identity "
            f"{identity!r}"
        )
    return identity, resolved


def _validate_args(args: argparse.Namespace) -> tuple[str, Path]:
    if MAX_TOKENS != canary.BASELINE_CAP:
        raise RuntimeError(
            "diagnostic baseline no longer matches maintained MAX_TOKENS: "
            f"expected {canary.BASELINE_CAP}, found {MAX_TOKENS}"
        )
    if CAP != canary.CANDIDATE_CAP:
        raise RuntimeError(
            "diagnostic cap no longer matches the context canary candidate: "
            f"expected {canary.CANDIDATE_CAP}, found {CAP}"
        )
    if (
        args.microbatch_size < 2
        or args.microbatch_size > arm6.BATCH_SIZE
        or args.microbatch_size % 2
    ):
        raise ValueError("microbatch size must be even and in [2, 128]")
    identity, output = _resolve_output(
        args.output, microbatch_size=args.microbatch_size
    )
    if output.exists():
        raise FileExistsError(f"refusing to replace parity diagnostic output: {output}")
    return identity, output


def _dry_plan(args: argparse.Namespace, identity: str, output: Path) -> dict:
    return {
        "mode": "dry-run",
        "run_requested": False,
        "identity": identity,
        "max_tokens": CAP,
        "correctness_updates_per_probe": 1,
        "optimizer_steps_per_probe": 0,
        "replicas_per_mode": REPLICAS,
        "fresh_same_seed_model_per_replica": True,
        "modes": [mode["name"] for mode in MODES],
        "forced_attention_backend": "SDPBackend.EFFICIENT_ATTENTION",
        "microbatch_size": args.microbatch_size,
        "output": str(output),
        "writes": False,
        "gpu_work": False,
        "next_step": "pass --run to execute the bounded correctness diagnostic",
    }


def _canonical_float32(value: np.ndarray) -> np.ndarray:
    return np.ascontiguousarray(np.asarray(value, dtype="<f4").reshape(-1))


def _array_summary(value: np.ndarray) -> dict:
    vector = _canonical_float32(value)
    return {
        "elements": int(vector.size),
        "finite": bool(np.isfinite(vector).all()),
        "l2_norm": float(np.linalg.norm(vector)),
        "max_abs": float(np.abs(vector).max(initial=0.0)),
        "sha256": hashlib.sha256(vector.tobytes()).hexdigest(),
    }


def _attention_backend_evidence(attention_events: list[dict]) -> dict:
    events = sorted(
        (
            {"name": str(event["name"]), "count": int(event["count"])}
            for event in attention_events
        ),
        key=lambda event: event["name"],
    )
    efficient = sorted(
        {
            event["name"]
            for event in events
            if any(
                marker in event["name"].lower() for marker in EFFICIENT_EVENT_MARKERS
            )
        }
    )
    disallowed = sorted(
        {
            event["name"]
            for event in events
            if any(
                marker in event["name"].lower() for marker in DISALLOWED_EVENT_MARKERS
            )
        }
    )
    return {
        "required_backend": "SDPBackend.EFFICIENT_ATTENTION",
        "enabled_backends": ["SDPBackend.EFFICIENT_ATTENTION"],
        "flash_cudnn_and_math_backends_disabled": True,
        "attention_events": events,
        "efficient_events": efficient,
        "disallowed_backend_events": disallowed,
        "attention_event_count": sum(event["count"] for event in events),
        "passed": bool(events and efficient and not disallowed),
    }


def _parameter_parity(
    reference: dict[str, np.ndarray],
    probe: dict[str, np.ndarray],
) -> dict:
    reference_names = set(reference)
    probe_names = set(probe)
    missing = sorted(reference_names - probe_names)
    unexpected = sorted(probe_names - reference_names)
    rows = []
    total_difference_energy = 0.0
    staged = []
    for name in sorted(reference_names & probe_names):
        expected = _canonical_float32(reference[name])
        observed = _canonical_float32(probe[name])
        if expected.shape != observed.shape:
            rows.append(
                {
                    "name": name,
                    "shape_match": False,
                    "reference_elements": int(expected.size),
                    "probe_elements": int(observed.size),
                    "passes_gradient_thresholds": False,
                }
            )
            continue
        difference = observed - expected
        difference_energy = float(np.dot(difference, difference))
        total_difference_energy += difference_energy
        staged.append((name, expected, observed, difference, difference_energy))
    for name, expected, observed, difference, difference_energy in staged:
        expected_norm = float(np.linalg.norm(expected))
        observed_norm = float(np.linalg.norm(observed))
        difference_l2 = float(np.linalg.norm(difference))
        if expected_norm * observed_norm <= 1e-30:
            cosine = 1.0 if difference_l2 <= 1e-30 else 0.0
        else:
            cosine = float(np.dot(expected, observed) / (expected_norm * observed_norm))
        relative_l2 = difference_l2 / max(expected_norm, 1e-30)
        rows.append(
            {
                "name": name,
                "shape_match": True,
                "elements": int(expected.size),
                "reference_l2_norm": expected_norm,
                "probe_l2_norm": observed_norm,
                "gradient_cosine": cosine,
                "gradient_relative_l2": relative_l2,
                "gradient_difference_l2": difference_l2,
                "gradient_max_abs_difference": float(
                    np.abs(difference).max(initial=0.0)
                ),
                "difference_energy_fraction": (
                    difference_energy / total_difference_energy
                    if total_difference_energy
                    else 0.0
                ),
                "passes_gradient_thresholds": bool(
                    cosine >= arm6.GRADIENT_COSINE_MINIMUM
                    and relative_l2 <= arm6.GRADIENT_RELATIVE_L2_MAXIMUM
                ),
            }
        )
    return {
        "diagnostic_only_not_an_additional_launch_gate": True,
        "thresholds_shown_for_localization_only": {
            "minimum_gradient_cosine": arm6.GRADIENT_COSINE_MINIMUM,
            "maximum_gradient_relative_l2": arm6.GRADIENT_RELATIVE_L2_MAXIMUM,
        },
        "parameter_names_match": not missing and not unexpected,
        "missing_parameter_names": missing,
        "unexpected_parameter_names": unexpected,
        "parameters": sorted(rows, key=lambda row: row["name"]),
    }


def _comparison(
    reference_label: str,
    reference: _ProbeData,
    probe_label: str,
    probe: _ProbeData,
) -> dict:
    whole = arm6._parity(
        reference.record,
        reference.whole_gradient,
        probe.record,
        probe.whole_gradient,
    )
    whole["reference"] = reference_label
    whole["probe"] = probe_label
    per_parameter = _parameter_parity(
        reference.parameter_gradients, probe.parameter_gradients
    )
    integrity = bool(
        reference.record["integrity"]["passed"]
        and probe.record["integrity"]["passed"]
        and per_parameter["parameter_names_match"]
        and all(row["shape_match"] for row in per_parameter["parameters"])
    )
    return {
        "reference": reference_label,
        "probe": probe_label,
        "unchanged_whole_vector_gate": whole,
        "per_parameter_gradient_parity": per_parameter,
        "integrity_passed": integrity,
        "passed": bool(integrity and whole["passed"]),
    }


def _decision(
    probe_records: dict[str, list[dict]],
    cross_mode: list[dict],
    within_mode: list[dict],
) -> dict:
    required_probe_count = len(MODES) * REPLICAS
    successful = [
        probe
        for probes in probe_records.values()
        for probe in probes
        if probe.get("status") == "ok"
    ]
    exact_probe_gates = all(
        probe["integrity"]["passed"]
        and probe["precision_recipe"]["passed"]
        and probe["efficient_backend_evidence"]["passed"]
        for probe in successful
    )
    all_cross = bool(cross_mode) and all(value["passed"] for value in cross_mode)
    all_within = bool(within_mode) and all(value["passed"] for value in within_mode)

    inductor_labels = {f"inductor/replica-{index}" for index in range(REPLICAS)}
    inductor_cross = [
        value for value in cross_mode if value["probe"] in inductor_labels
    ]
    inductor_within = [
        value
        for value in within_mode
        if value["reference"] in inductor_labels and value["probe"] in inductor_labels
    ]
    inductor_probe_gates = all(
        probe.get("status") == "ok"
        and probe.get("integrity", {}).get("passed", False)
        and probe.get("precision_recipe", {}).get("passed", False)
        and probe.get("efficient_backend_evidence", {}).get("passed", False)
        for probe in probe_records.get("inductor", [])
    )
    uncompiled_probe_gates = all(
        probe.get("status") == "ok"
        and probe.get("integrity", {}).get("passed", False)
        and probe.get("precision_recipe", {}).get("passed", False)
        and probe.get("efficient_backend_evidence", {}).get("passed", False)
        for probe in probe_records.get("uncompiled", [])
    )
    inductor_passed = bool(
        len(probe_records.get("inductor", [])) == REPLICAS
        and len(probe_records.get("uncompiled", [])) == REPLICAS
        and inductor_probe_gates
        and uncompiled_probe_gates
        and len(inductor_cross) == REPLICAS
        and all(value["passed"] for value in inductor_cross)
        and len(inductor_within) == 3
        and all(value["passed"] for value in inductor_within)
    )
    full_passed = bool(
        len(successful) == required_probe_count
        and exact_probe_gates
        and len(cross_mode) == (len(MODES) - 1) * REPLICAS
        and all_cross
        and len(within_mode) == len(MODES) * 3
        and all_within
    )
    return {
        "unchanged_numerical_thresholds": {
            "maximum_loss_relative_difference": arm6.LOSS_RELATIVE_TOLERANCE,
            "minimum_gradient_cosine": arm6.GRADIENT_COSINE_MINIMUM,
            "maximum_gradient_relative_l2": arm6.GRADIENT_RELATIVE_L2_MAXIMUM,
        },
        "required_probe_count": required_probe_count,
        "successful_probe_count": len(successful),
        "all_exact_probe_gates_passed": exact_probe_gates,
        "all_cross_mode_comparisons_passed": all_cross,
        "all_within_mode_comparisons_passed": all_within,
        "full_diagnostic_passed": full_passed,
        "inductor_1024_launch_gate": {
            "passed": inductor_passed,
            "rule": (
                "all three Inductor and uncompiled reference replicas must use "
                "only efficient SDPA and match the actual precision recipe; each "
                "Inductor replica must pass the unchanged whole-vector gate versus "
                "its same-index uncompiled replica, and all three within-Inductor "
                "repeatability comparisons must pass"
            ),
            "does_not_authorize_training_or_promotion": True,
        },
    }


@contextmanager
def _efficient_attention_only() -> Iterator[None]:
    from torch.nn.attention import SDPBackend, sdpa_kernel

    if not hasattr(SDPBackend, "EFFICIENT_ATTENTION"):
        raise RuntimeError("this Torch build exposes no EFFICIENT_ATTENTION backend")
    with sdpa_kernel(backends=[SDPBackend.EFFICIENT_ATTENTION]):
        yield


def _named_trainable_parameters(encoder, head) -> list[tuple[str, object]]:
    values = [
        *(
            (f"head.{name}", parameter)
            for name, parameter in head.named_parameters()
            if parameter.requires_grad
        ),
        *(
            (f"encoder.{name}", parameter)
            for name, parameter in encoder.named_parameters()
            if parameter.requires_grad
        ),
    ]
    identities = [id(parameter) for _, parameter in values]
    if len(identities) != len(set(identities)):
        raise RuntimeError("trainable parameter traversal contains aliases")
    return values


def _precision_recipe(encoder, head, optimizer, *, compile_backend: str | None) -> dict:
    import torch

    parameters = [*encoder.parameters(), *head.parameters()]
    trainable = [parameter for parameter in parameters if parameter.requires_grad]
    frozen = [parameter for parameter in parameters if not parameter.requires_grad]
    trainable_dtypes = dict(
        sorted(Counter(str(parameter.dtype) for parameter in trainable).items())
    )
    frozen_dtypes = dict(
        sorted(Counter(str(parameter.dtype) for parameter in frozen).items())
    )
    dropout_modules = [
        module
        for module in chain(encoder.modules(), head.modules())
        if isinstance(module, torch.nn.Dropout)
    ]
    default_cuda_autocast_dtype = torch.get_autocast_dtype("cuda")
    with torch.autocast("cuda", dtype=torch.bfloat16):
        explicit_autocast_enabled = torch.is_autocast_enabled("cuda")
        explicit_autocast_dtype = torch.get_autocast_dtype("cuda")
    matmul_precision = torch.get_float32_matmul_precision()
    compiled_backward = None
    if compile_backend is not None:
        from torch._functorch import config as functorch_config

        compiled_backward = str(functorch_config.backward_pass_autocast)
    optimizer_state = [
        value
        for state in optimizer.state.values()
        for value in state.values()
        if isinstance(value, torch.Tensor)
    ]
    passed = bool(
        set(frozen_dtypes) == {"torch.bfloat16"}
        and set(trainable_dtypes) == {"torch.float32"}
        and explicit_autocast_enabled
        and explicit_autocast_dtype == torch.bfloat16
        and torch.backends.cuda.matmul.allow_tf32
        and torch.backends.cudnn.allow_tf32
        and matmul_precision == "high"
        and not encoder.training
        and not head.training
        and all(not module.training for module in dropout_modules)
        and (compile_backend is None or compiled_backward == "off")
        and not optimizer_state
    )
    return {
        "base_frozen_parameter_dtypes": frozen_dtypes,
        "trainable_parameter_dtypes": trainable_dtypes,
        "workload_uses_explicit_cuda_autocast": True,
        "explicit_workload_autocast_enabled": explicit_autocast_enabled,
        "explicit_workload_autocast_dtype": str(explicit_autocast_dtype),
        "unrelated_global_default_cuda_autocast_dtype": str(
            default_cuda_autocast_dtype
        ),
        "float32_matmul_precision": matmul_precision,
        "cuda_matmul_allow_tf32": bool(torch.backends.cuda.matmul.allow_tf32),
        "cudnn_allow_tf32": bool(torch.backends.cudnn.allow_tf32),
        "compiled_backward_autocast": compiled_backward,
        "encoder_eval": not encoder.training,
        "head_eval": not head.training,
        "dropout_modules": len(dropout_modules),
        "dropout_modules_in_training_mode": sum(
            module.training for module in dropout_modules
        ),
        "optimizer_state_tensor_count": len(optimizer_state),
        "optimizer_step_performed": False,
        "gradient_clip_performed": False,
        "passed": passed,
    }


def _setup_model(compile_backend: str | None):
    import torch

    arm6._seed_everything(arm6.SEED)
    started = time.perf_counter()
    encoder = arm6._load_encoder("sdpa")
    load_seconds = time.perf_counter() - started
    encoder.gradient_checkpointing_disable()
    encoder = add_lora(encoder)
    head = _new_multitask_head(encoder.config.hidden_size, arm6.SEED, 2).to("cuda")
    optimizer, fused_optimizer = arm6._new_optimizer(encoder, head)
    torch.set_float32_matmul_precision("high")
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    compile_started = time.perf_counter()
    if compile_backend is not None:
        _configure_compiled_backward_autocast()
        encoder.compile(backend=compile_backend)
        head.compile(backend=compile_backend)
    compile_api_seconds = time.perf_counter() - compile_started
    encoder.eval()
    head.eval()
    return (
        encoder,
        head,
        optimizer,
        {
            "base_model_load_seconds": load_seconds,
            "setup_seconds": time.perf_counter() - started,
            "compile_api_seconds": compile_api_seconds,
            "fused_adamw_constructed_but_never_stepped": fused_optimizer,
        },
    )


def _collect_gradients(encoder, head) -> tuple[dict, np.ndarray, dict[str, np.ndarray]]:
    gradients = {}
    parameters = []
    missing = []
    gradient_dtypes: Counter[str] = Counter()
    parameter_summaries = []
    for name, parameter in _named_trainable_parameters(encoder, head):
        if parameter.grad is None:
            value = np.zeros(parameter.numel(), dtype="<f4")
            missing.append(name)
            gradient_dtype = None
        else:
            gradient_dtype = str(parameter.grad.dtype)
            gradient_dtypes[gradient_dtype] += 1
            value = _canonical_float32(parameter.grad.detach().float().cpu().numpy())
        gradients[name] = value
        parameters.append(value)
        parameter_summaries.append(
            {
                "name": name,
                "shape": list(parameter.shape),
                "dtype": str(parameter.dtype),
                "gradient_dtype": gradient_dtype,
                "missing": parameter.grad is None,
                **_array_summary(value),
            }
        )
    if not parameters:
        raise RuntimeError("model exposes no trainable parameters")
    whole = _canonical_float32(np.concatenate(parameters))
    summary = {
        **_array_summary(whole),
        "missing_parameter_gradients": len(missing),
        "missing_parameter_names": sorted(missing),
        "gradient_dtypes": dict(sorted(gradient_dtypes.items())),
        "parameter_count": len(parameter_summaries),
        "parameters": sorted(parameter_summaries, key=lambda value: value["name"]),
    }
    return summary, whole, gradients


def _run_probe(
    tokenizer,
    stress: dict,
    *,
    mode: dict,
    replica: int,
    harmful_class_weights: dict[int, float],
    microbatch_size: int,
    cache_path: Path,
) -> _ProbeData:
    import torch
    from torch.profiler import ProfilerActivity, profile

    encoder = head = optimizer = encoding_cache = None
    try:
        canary._set_inductor_cache(cache_path)
        encoder, head, optimizer, setup = _setup_model(mode["compile_backend"])
        recipe = _precision_recipe(
            encoder, head, optimizer, compile_backend=mode["compile_backend"]
        )
        encoding_cache = canary._CappedEncodingCache(tokenizer, max_tokens=CAP)
        encoding_cache.warm(
            chain(
                (row["text"] for row in stress["canonical"]),
                (row["text"] for row in stress["promptshield"]),
                (row["text"] for pair in stress["pairs"] for row in pair),
            )
        )
        prewarmed = encoding_cache.snapshot()
        encoding_cache.reset_metrics()
        optimizer.zero_grad(set_to_none=True)
        arm6._seed_everything(arm6.PROBE_SEED)
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
        started = time.perf_counter()
        with profile(
            activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
            record_shapes=False,
            profile_memory=False,
            with_stack=False,
        ) as trace:
            with _efficient_attention_only():
                metrics = arm6._backward_workload(
                    encoder,
                    tokenizer,
                    head,
                    stress,
                    harmful_class_weights=harmful_class_weights,
                    microbatch_size=microbatch_size,
                    cache=encoding_cache,
                )
        torch.cuda.synchronize()
        seconds = time.perf_counter() - started
        events = [
            {"name": str(event.key), "count": int(event.count)}
            for event in trace.key_averages()
            if "attention" in str(event.key).lower()
        ]
        backend = _attention_backend_evidence(events)
        gradient, whole, by_parameter = _collect_gradients(encoder, head)
        integrity = {
            "finite": gradient["finite"],
            "missing_parameter_gradients": gradient["missing_parameter_gradients"],
            "gradient_dtypes": gradient["gradient_dtypes"],
            "encoding_cache_misses_during_probe": encoding_cache.snapshot()[
                "unique_misses"
            ],
        }
        integrity["passed"] = bool(
            integrity["finite"]
            and integrity["missing_parameter_gradients"] == 0
            and set(integrity["gradient_dtypes"]) == {"torch.float32"}
            and integrity["encoding_cache_misses_during_probe"] == 0
        )
        record = {
            "status": "ok",
            "label": f"{mode['name']}/replica-{replica}",
            "mode": mode["name"],
            "compile_backend": mode["compile_backend"],
            "replica": replica,
            "model_seed": arm6.SEED,
            "workload_seed": arm6.PROBE_SEED,
            "max_tokens": CAP,
            "correctness_updates": 1,
            "optimizer_steps": 0,
            "dropout": "disabled_via_eval_for_deterministic_kernel_parity",
            "seconds_including_first_compile_and_profiler": seconds,
            "setup": setup,
            "losses": arm6._scalar_metrics(metrics),
            "gradient": gradient,
            "integrity": integrity,
            "precision_recipe": recipe,
            "efficient_backend_evidence": backend,
            "prewarmed_encoding_cache": prewarmed,
            "probe_encoding_cache": encoding_cache.snapshot(),
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
            "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "compiler_counters": arm6._dynamo_counters(),
        }
        optimizer.zero_grad(set_to_none=True)
        return _ProbeData(record, whole, by_parameter)
    finally:
        del encoding_cache, optimizer, head, encoder
        gc.collect()
        arm6._clear_compiler_state()
        torch.cuda.empty_cache()


def _publish_json_exclusive(path: Path, value: dict) -> None:
    """Atomically publish without ever replacing an existing result."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError as error:
            raise FileExistsError(
                f"refusing to replace parity diagnostic output: {path}"
            ) from error
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _failed_probe(mode: dict, replica: int, error: Exception) -> dict:
    return {
        "status": "oom" if type(error).__name__ == "OutOfMemoryError" else "failed",
        "label": f"{mode['name']}/replica-{replica}",
        "mode": mode["name"],
        "compile_backend": mode["compile_backend"],
        "replica": replica,
        "model_seed": arm6.SEED,
        "workload_seed": arm6.PROBE_SEED,
        "max_tokens": CAP,
        "error_type": type(error).__name__,
        "raw_error_message_omitted": True,
    }


def _run(args: argparse.Namespace, *, identity: str, output: Path) -> int:
    previous_cache = os.environ.get("TORCHINDUCTOR_CACHE_DIR")
    probes: dict[str, list[_ProbeData | None]] = {mode["name"]: [] for mode in MODES}
    records: dict[str, list[dict]] = {mode["name"]: [] for mode in MODES}
    with tempfile.TemporaryDirectory(prefix=f"morgott-{identity}-") as root:
        cache_root = Path(root)
        try:
            device = arm6._device_report(allow_non_l40s=args.allow_non_l40s)
            print("preparing aggregate-only cap-1024 stress workload", flush=True)
            data = prepare_training_data(
                args.data_dir,
                args.external_dir,
                args.pairs,
                seed=arm6.SEED,
                additional_pair_archive=args.additional_pairs,
                cache_dir=args.prep_cache,
            )
            from transformers import AutoTokenizer

            tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REVISION)
            (
                _representative,
                stress,
                harmful_counts,
                harmful_class_weights,
                workload_metadata,
            ) = canary._build_workloads(data, tokenizer)
            length_cache = canary._BoundedLengthCache(tokenizer, ceiling=CAP)
            length_groups = canary._length_groups(
                [stress],
                microbatch_size=args.microbatch_size,
                length_cache=length_cache,
            )
            stress_lengths = canary._summarize_length_groups(length_groups, cap=CAP)
            reached = {
                population: values["padded_width"]["maximum"] == CAP
                for population, values in stress_lengths["by_population"].items()
            }
            for mode in MODES:
                for replica in range(REPLICAS):
                    label = f"{mode['name']}/replica-{replica}"
                    print(f"running correctness-only {label}", flush=True)
                    try:
                        probe = _run_probe(
                            tokenizer,
                            stress,
                            mode=mode,
                            replica=replica,
                            harmful_class_weights=harmful_class_weights,
                            microbatch_size=args.microbatch_size,
                            cache_path=cache_root / mode["name"] / f"replica-{replica}",
                        )
                    except Exception as error:
                        probes[mode["name"]].append(None)
                        records[mode["name"]].append(
                            _failed_probe(mode, replica, error)
                        )
                    else:
                        probes[mode["name"]].append(probe)
                        records[mode["name"]].append(probe.record)

            cross_mode = []
            for mode in MODES[1:]:
                for replica in range(REPLICAS):
                    reference = probes["uncompiled"][replica]
                    probe = probes[mode["name"]][replica]
                    if reference is not None and probe is not None:
                        cross_mode.append(
                            _comparison(
                                f"uncompiled/replica-{replica}",
                                reference,
                                f"{mode['name']}/replica-{replica}",
                                probe,
                            )
                        )

            within_mode = []
            for mode in MODES:
                values = probes[mode["name"]]
                for left, right in ((0, 1), (0, 2), (1, 2)):
                    if values[left] is not None and values[right] is not None:
                        within_mode.append(
                            _comparison(
                                f"{mode['name']}/replica-{left}",
                                values[left],
                                f"{mode['name']}/replica-{right}",
                                values[right],
                            )
                        )
            decision = _decision(records, cross_mode, within_mode)
            report = {
                "schema_version": 1,
                "identity": identity,
                "created_at": datetime.now(UTC).isoformat(),
                "experiment_only": True,
                "device": device,
                "software": {
                    "torch": version("torch"),
                    "transformers": version("transformers"),
                    "peft": version("peft"),
                },
                "recipe": {
                    "model_id": MODEL_ID,
                    "model_revision": MODEL_REVISION,
                    "lora_rank": LORA_RANK,
                    "model_seed": arm6.SEED,
                    "workload_seed": arm6.PROBE_SEED,
                    "max_tokens": CAP,
                    "batch_size": arm6.BATCH_SIZE,
                    "microbatch_size": args.microbatch_size,
                    "attention": "EFFICIENT_ATTENTION only; all fallbacks disabled",
                    "base_parameters": "bfloat16",
                    "trainable_parameters": "float32",
                    "float32_matmul_precision": "high with CUDA and cuDNN TF32 enabled",
                    "compiled_backward_autocast": "off",
                    "dropout": "disabled via eval for correctness comparison",
                    "optimizer_steps": 0,
                    "gradient_clipping": False,
                },
                "measurement": {
                    "dry_by_default": True,
                    "write_once": True,
                    "correctness_only": True,
                    "correctness_updates_per_probe": 1,
                    "fresh_same_seed_model_per_probe": True,
                    "replicas_per_mode": REPLICAS,
                    "modes": list(MODES),
                    "compiler_cache": (
                        "isolated empty temporary directory per mode and replica"
                    ),
                    "profiler_scope": (
                        "the exact loss/backward pass whose gradients are compared"
                    ),
                    "gradient_vectors_written": False,
                },
                "workload": {
                    "selection": workload_metadata["forced_longest_width"],
                    "representative_updates_executed": 0,
                    "forced_longest_width_updates_per_probe": 1,
                    "candidate_cap_reached_by_population": reached,
                    "all_populations_reached_candidate_cap": all(reached.values()),
                    "aggregate_token_lengths": stress_lengths,
                    "harmful_counts": harmful_counts,
                    "harmful_class_weights": {
                        "negative": harmful_class_weights[0],
                        "positive": harmful_class_weights[1],
                    },
                },
                "probes": records,
                "comparisons": {
                    "cross_mode_same_replica": cross_mode,
                    "within_mode_repeatability": within_mode,
                },
                "decision": decision,
                "sources": source_provenance(
                    Path(__file__),
                    Path(canary.__file__),
                    Path(arm6.__file__),
                    Path(__file__).resolve().parents[2]
                    / "src/morgott/models/mmbert/train.py",
                    Path(__file__).resolve().parents[2]
                    / "src/morgott/models/mmbert/head_contract.py",
                    Path(__file__).resolve().parents[2]
                    / "src/morgott/models/mmbert/core.py",
                ),
                "privacy": (
                    "Only scalar losses, aggregate token and numerical summaries, "
                    "parameter names/shapes, compiler counters, profiler event "
                    "names/counts, and gradient hashes are emitted. Prompt text, "
                    "row identity, predictions, and gradient vectors are omitted."
                ),
                "limitations": [
                    "This diagnoses numerical parity for one forced-width update; it is not a quality evaluation.",
                    "The profiler adds overhead, so elapsed seconds are not throughput measurements.",
                    "A passing gate does not authorize training, blocking, registry promotion, or deployment.",
                ],
            }
            _publish_json_exclusive(output, report)
            print(output)
            return 0 if decision["full_diagnostic_passed"] else 1
        finally:
            if previous_cache is None:
                os.environ.pop("TORCHINDUCTOR_CACHE_DIR", None)
            else:
                os.environ["TORCHINDUCTOR_CACHE_DIR"] = previous_cache


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    identity, output = _validate_args(args)
    if not args.run:
        print(json.dumps(_dry_plan(args, identity, output), indent=2, sort_keys=True))
        return 0
    return _run(args, identity=identity, output=output)


if __name__ == "__main__":
    raise SystemExit(main())
