"""Dry-by-default Arm 6 context canary for the 512-to-1024 ablation.

This is experiment-only code.  It reuses the retained Arm 6 stream and loss
helpers, but owns an explicit token cap so the maintained 512-token model code
and the existing attention benchmark artifact remain unchanged.

Running without ``--run`` prints the resolved identity and output path without
loading data, importing Torch, or touching CUDA.  The GPU canary must be opted
into explicitly::

    HF_HOME=/workspace/hf_cache \
      LD_LIBRARY_PATH=/usr/local/cuda-13.0/compat${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH} \
      uv run --locked --extra encoder --extra tracking \
      python experiments/capacity_ladder/benchmark_arm6_context_canary.py --run

Only aggregate lengths, timings, hardware telemetry, losses, and gradient
summaries are written.  Prompt text and row identities are never emitted.
"""

from __future__ import annotations

import argparse
import gc
import heapq
import json
import math
import os
import tempfile
import threading
import time
from collections import Counter, defaultdict
from contextlib import contextmanager
from datetime import UTC, datetime
from importlib.metadata import version
from itertools import chain, islice
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

try:
    from experiments.capacity_ladder import benchmark_arm6_l40s as arm6
except ModuleNotFoundError as error:
    if error.name != "experiments":
        raise
    import benchmark_arm6_l40s as arm6
from morgott.models.mmbert.core import (
    LORA_RANK,
    MAX_TOKENS,
    MODEL_ID,
    MODEL_REVISION,
    source_provenance,
)
from morgott.models.mmbert.data import batches, shuffled
from morgott.models.mmbert.train import (
    BalancedIndexCycle,
    PairIndexCycle,
    _cached_batch_logits,
    _harmful_balance,
    _head_contract,
    prepare_training_data,
)
from morgott.normalization import strict_normalize

if TYPE_CHECKING:
    from collections.abc import Iterable, Iterator, Sequence


BASELINE_CAP = 512
CANDIDATE_CAP = 1024
REPRESENTATIVE_UPDATES = 32
STEADY_PASSES = 2
STRESS_CANDIDATES = 4096
DEFAULT_MICROBATCH_SIZE = 24
DEFAULT_TELEMETRY_INTERVAL_SECONDS = 1.0
DEFAULT_OUTPUT_ROOT = Path("artifacts/mmbert")
MINIMUM_L40S_HEADROOM_FRACTION = 0.10
PORTABLE_DEVICE_BYTES = 24 * 1024**3
PORTABLE_HEADROOM_FRACTION = 0.20
LENGTH_BUCKETS = (
    ("1-64", 64),
    ("65-128", 128),
    ("129-256", 256),
    ("257-512", 512),
    ("513-1024", 1024),
    (">1024", None),
)
FUSED_EVENT_MARKERS = (
    "efficient_attention",
    "flash_attention",
    "cudnn_attention",
)
MATH_EVENT_MARKERS = (
    "attention_math",
    "scaled_dot_product_attention_math",
)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--run",
        action="store_true",
        help="execute the GPU canary; without this flag only the plan is printed",
    )
    mode.add_argument(
        "--dry-run",
        action="store_true",
        help="explicit spelling of the default no-GPU, no-write behavior",
    )
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument(
        "--external-dir", type=Path, default=Path("artifacts/mmbert/data")
    )
    parser.add_argument(
        "--pairs",
        type=Path,
        default=Path("data-archive/matched_pairs_20260726.jsonl.gz"),
    )
    parser.add_argument(
        "--additional-pairs",
        type=Path,
        default=Path("artifacts/mmbert_lpft_new_data_rebuilt/train/pairs.jsonl.gz"),
    )
    parser.add_argument(
        "--prep-cache",
        type=Path,
        default=Path("artifacts/mmbert/prep-cache"),
    )
    parser.add_argument("--microbatch-size", type=int, default=DEFAULT_MICROBATCH_SIZE)
    parser.add_argument(
        "--telemetry-interval-seconds",
        type=float,
        default=DEFAULT_TELEMETRY_INTERVAL_SECONDS,
    )
    parser.add_argument(
        "--validation-timing",
        action="store_true",
        help="also time one cap-aware forward-only validation sweep per cap",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="write-once result path; its name must contain the resolved identity",
    )
    parser.add_argument(
        "--allow-non-l40s",
        action="store_true",
        help="development-only escape hatch; the report still records the device",
    )
    return parser


def _identity(microbatch_size: int) -> str:
    return (
        f"arm6-context-cap{BASELINE_CAP}-vs-cap{CANDIDATE_CAP}"
        f"-s{arm6.SEED}-u{REPRESENTATIVE_UPDATES}-mb{microbatch_size}"
    )


def _resolve_output(output: Path | None, *, microbatch_size: int) -> tuple[str, Path]:
    identity = _identity(microbatch_size)
    resolved = output or DEFAULT_OUTPUT_ROOT / f"{identity}.json"
    if identity not in resolved.name:
        raise ValueError(
            "output filename must contain the complete resolved experiment identity "
            f"{identity!r}"
        )
    return identity, resolved


def _validate_args(args: argparse.Namespace) -> tuple[str, Path]:
    if MAX_TOKENS != BASELINE_CAP:
        raise RuntimeError(
            "context canary baseline no longer matches maintained MAX_TOKENS: "
            f"expected {BASELINE_CAP}, found {MAX_TOKENS}"
        )
    if (
        args.microbatch_size < 2
        or args.microbatch_size > arm6.BATCH_SIZE
        or args.microbatch_size % 2
    ):
        raise ValueError("microbatch size must be even and in [2, 128]")
    if (
        not math.isfinite(args.telemetry_interval_seconds)
        or args.telemetry_interval_seconds < 0.5
    ):
        raise ValueError("telemetry interval must be finite and at least 0.5 seconds")
    identity, output = _resolve_output(
        args.output, microbatch_size=args.microbatch_size
    )
    if output.exists():
        raise FileExistsError(f"refusing to replace context canary output: {output}")
    return identity, output


def _dry_plan(args: argparse.Namespace, identity: str, output: Path) -> dict:
    return {
        "mode": "dry-run",
        "run_requested": False,
        "identity": identity,
        "caps": [BASELINE_CAP, CANDIDATE_CAP],
        "representative_updates": REPRESENTATIVE_UPDATES,
        "forced_longest_width_updates": 1,
        "microbatch_size": args.microbatch_size,
        "telemetry_interval_seconds": args.telemetry_interval_seconds,
        "validation_timing": args.validation_timing,
        "output": str(output),
        "writes": False,
        "gpu_work": False,
        "next_step": "pass --run to execute the bounded canary",
    }


class _CappedEncodingCache:
    """Experiment-local equivalent of the trainer cache with an explicit cap."""

    def __init__(self, tokenizer, *, max_tokens: int) -> None:
        if max_tokens < 2:
            raise ValueError("max_tokens must be at least two")
        self._tokenizer = tokenizer
        self.max_tokens = max_tokens
        self._encoded: dict[str, np.ndarray] = {}
        self._requests = 0
        self._misses = 0
        self._encode_calls = 0
        self._encode_seconds = 0.0

    def __len__(self) -> int:
        return len(self._encoded)

    def snapshot(self) -> dict[str, int | float]:
        return {
            "entries": len(self._encoded),
            "requests": self._requests,
            "unique_misses": self._misses,
            "encode_calls": self._encode_calls,
            "normalization_and_tokenization_seconds": self._encode_seconds,
        }

    def reset_metrics(self) -> None:
        self._requests = 0
        self._misses = 0
        self._encode_calls = 0
        self._encode_seconds = 0.0

    def encode(self, texts: list[str]) -> list[list[int]]:
        self._requests += len(texts)
        missing = list(
            dict.fromkeys(text for text in texts if text not in self._encoded)
        )
        if missing:
            started = time.perf_counter()
            encoded = self._tokenizer(
                [strict_normalize(text) for text in missing],
                add_special_tokens=True,
                max_length=self.max_tokens,
                truncation=True,
            )["input_ids"]
            self._encode_seconds += time.perf_counter() - started
            self._encode_calls += 1
            self._misses += len(missing)
            for text, ids in zip(missing, encoded, strict=True):
                self._encoded[text] = np.asarray(ids, dtype=np.int32)
        return [self._encoded[text].tolist() for text in texts]

    def warm(self, texts: Iterable[str], *, workers: int = 0) -> None:
        # The bounded canary has only thousands of distinct strings.  Keeping
        # this sequential avoids spawning processes after CUDA initialization.
        del workers
        pending = list(
            dict.fromkeys(text for text in texts if text not in self._encoded)
        )
        for start in range(0, len(pending), 1024):
            self.encode(pending[start : start + 1024])


class _BoundedLengthCache:
    """Measure token lengths up to candidate_cap + 1 without retaining tokens."""

    def __init__(self, tokenizer, *, ceiling: int) -> None:
        self._tokenizer = tokenizer
        self._limit = ceiling + 1
        self._lengths: dict[str, int] = {}

    def lengths(self, texts: Sequence[str]) -> list[int]:
        missing = list(
            dict.fromkeys(text for text in texts if text not in self._lengths)
        )
        for start in range(0, len(missing), 512):
            window = missing[start : start + 512]
            encoded = self._tokenizer(
                [strict_normalize(text) for text in window],
                add_special_tokens=True,
                max_length=self._limit,
                truncation=True,
            )["input_ids"]
            for text, ids in zip(window, encoded, strict=True):
                self._lengths[text] = len(ids)
        return [self._lengths[text] for text in texts]


def _top_raw_candidates(values: Iterable[object], *, limit: int, key) -> list[object]:
    ranked = heapq.nlargest(
        limit,
        enumerate(values),
        key=lambda item: (key(item[1]), -item[0]),
    )
    return [value for _, value in ranked]


def _top_rows_by_token_width(
    rows: list[dict],
    *,
    count: int,
    length_cache: _BoundedLengthCache,
) -> list[dict]:
    lengths = length_cache.lengths([row["text"] for row in rows])
    ranked = sorted(
        enumerate(zip(rows, lengths, strict=True)),
        key=lambda item: (
            item[1][1],
            len(item[1][0]["text"]),
            -item[0],
        ),
        reverse=True,
    )[:count]
    selected = [row for _, (row, _) in ranked]
    return sorted(selected, key=lambda row: len(row["text"]))


def _top_pairs_by_token_width(
    pairs: list[tuple[dict, dict]],
    *,
    count: int,
    length_cache: _BoundedLengthCache,
) -> list[tuple[dict, dict]]:
    texts = [row["text"] for pair in pairs for row in pair]
    lengths = iter(length_cache.lengths(texts))
    widths = [max(next(lengths), next(lengths)) for _ in pairs]
    ranked = sorted(
        enumerate(zip(pairs, widths, strict=True)),
        key=lambda item: (
            item[1][1],
            max(len(item[1][0][0]["text"]), len(item[1][0][1]["text"])),
            -item[0],
        ),
        reverse=True,
    )[:count]
    selected = [pair for _, (pair, _) in ranked]
    return sorted(
        selected,
        key=lambda pair: max(len(pair[0]["text"]), len(pair[1]["text"])),
    )


def _build_workloads(data, tokenizer) -> tuple[list[dict], dict, dict, dict, dict]:
    """Build one shared row sequence and one bounded longest-width stress update."""
    canonical = arm6._canonical_stream(data)
    harmful_counts, harmful_class_weights = _harmful_balance(canonical)
    stream = shuffled(canonical, seed=arm6.SEED, buffer_size=arm6.SHUFFLE_BUFFER)
    canonical_batches = islice(batches(stream, arm6.BATCH_SIZE), REPRESENTATIVE_UPDATES)
    promptshield_cycle = BalancedIndexCycle(
        np.asarray([row["label"] for row in data.promptshield], dtype=np.int64),
        seed=arm6.SEED + 10_001,
    )
    pair_cycle = PairIndexCycle(len(data.pairs), seed=arm6.SEED + 20_003)
    representative = []
    for canonical_batch in canonical_batches:
        if len(canonical_batch) != arm6.BATCH_SIZE:
            raise ValueError("representative canonical batch is incomplete")
        promptshield_indices = promptshield_cycle.take(arm6.BATCH_SIZE // 2)
        pair_indices = pair_cycle.take(arm6.BATCH_SIZE // 4)
        representative.append(
            {
                "canonical": sorted(canonical_batch, key=lambda row: len(row["text"])),
                "promptshield": sorted(
                    [data.promptshield[int(index)] for index in promptshield_indices],
                    key=lambda row: len(row["text"]),
                ),
                "pairs": sorted(
                    [data.pairs[int(index)] for index in pair_indices],
                    key=lambda pair: max(len(pair[0]["text"]), len(pair[1]["text"])),
                ),
            }
        )
    if len(representative) != REPRESENTATIVE_UPDATES:
        raise ValueError(
            f"built {len(representative)} representative updates, "
            f"expected {REPRESENTATIVE_UPDATES}"
        )

    lengths = _BoundedLengthCache(tokenizer, ceiling=CANDIDATE_CAP)
    canonical_candidates = _top_raw_candidates(
        canonical,
        limit=STRESS_CANDIDATES,
        key=lambda row: len(row["text"]),
    )
    promptshield_candidates = _top_raw_candidates(
        data.promptshield,
        limit=min(STRESS_CANDIDATES, len(data.promptshield)),
        key=lambda row: len(row["text"]),
    )
    pair_candidates = _top_raw_candidates(
        data.pairs,
        limit=min(STRESS_CANDIDATES, len(data.pairs)),
        key=lambda pair: max(len(pair[0]["text"]), len(pair[1]["text"])),
    )
    stress = {
        "canonical": _top_rows_by_token_width(
            canonical_candidates,
            count=arm6.BATCH_SIZE,
            length_cache=lengths,
        ),
        "promptshield": _top_rows_by_token_width(
            promptshield_candidates,
            count=arm6.BATCH_SIZE // 2,
            length_cache=lengths,
        ),
        "pairs": _top_pairs_by_token_width(
            pair_candidates,
            count=arm6.BATCH_SIZE // 4,
            length_cache=lengths,
        ),
    }
    if (
        len(stress["canonical"]) != arm6.BATCH_SIZE
        or len(stress["promptshield"]) != arm6.BATCH_SIZE // 2
        or len(stress["pairs"]) != arm6.BATCH_SIZE // 4
    ):
        raise ValueError("could not construct a complete longest-width stress update")
    metadata = {
        "representative": (
            f"same epoch-0 seed-{arm6.SEED} stream, batch-{arm6.BATCH_SIZE} "
            "sorting, PromptShield cycle, and pair cycle used by Arm 6"
        ),
        "forced_longest_width": (
            f"top {STRESS_CANDIDATES} raw-character candidates per population, "
            f"reranked by strict-normalized tokenizer width measured through "
            f"{CANDIDATE_CAP + 1} tokens"
        ),
        "shared_in_memory_across_caps": True,
        "raw_text_or_row_identity_emitted": False,
    }
    return representative, stress, harmful_counts, harmful_class_weights, metadata


def _bucket_name(length: int) -> str:
    for name, maximum in LENGTH_BUCKETS:
        if maximum is None or length <= maximum:
            return name
    raise AssertionError("unreachable length bucket")


def _quantiles(values: list[int]) -> dict[str, int | float]:
    array = np.asarray(values, dtype=np.int64)
    return {
        "minimum": int(array.min()),
        "p50": float(np.percentile(array, 50)),
        "p95": float(np.percentile(array, 95)),
        "p99": float(np.percentile(array, 99)),
        "maximum": int(array.max()),
    }


def _summarize_length_groups(
    groups_by_population: dict[str, list[list[int]]], *, cap: int
) -> dict:
    result = {}
    for population, groups in sorted(groups_by_population.items()):
        real_histogram: Counter[str] = Counter()
        width_histogram: Counter[str] = Counter()
        padded_tokens_by_width: Counter[str] = Counter()
        untruncated_histogram: Counter[str] = Counter()
        widths = []
        real_tokens = 0
        padded_tokens = 0
        truncated_rows = 0
        rows = 0
        for group in groups:
            if not group:
                raise ValueError("length summary received an empty microbatch")
            capped = [min(length, cap) for length in group]
            width = max(capped)
            width_bucket = _bucket_name(width)
            widths.append(width)
            rows += len(group)
            real_tokens += sum(capped)
            padded = width * len(group)
            padded_tokens += padded
            padded_tokens_by_width[width_bucket] += padded
            width_histogram[width_bucket] += 1
            truncated_rows += sum(length > cap for length in group)
            real_histogram.update(_bucket_name(length) for length in capped)
            untruncated_histogram.update(_bucket_name(length) for length in group)
        result[population] = {
            "rows": rows,
            "microbatches": len(groups),
            "truncated_rows": truncated_rows,
            "real_tokens": real_tokens,
            "padded_tokens": padded_tokens,
            "padding_utilization": real_tokens / padded_tokens,
            "real_token_length_histogram": dict(sorted(real_histogram.items())),
            "bounded_untruncated_length_histogram": dict(
                sorted(untruncated_histogram.items())
            ),
            "padded_width_histogram": dict(sorted(width_histogram.items())),
            "padded_tokens_by_width_histogram": dict(
                sorted(padded_tokens_by_width.items())
            ),
            "padded_width": _quantiles(widths),
        }
    totals = {
        "rows": sum(value["rows"] for value in result.values()),
        "microbatches": sum(value["microbatches"] for value in result.values()),
        "truncated_rows": sum(value["truncated_rows"] for value in result.values()),
        "real_tokens": sum(value["real_tokens"] for value in result.values()),
        "padded_tokens": sum(value["padded_tokens"] for value in result.values()),
    }
    totals["padding_utilization"] = totals["real_tokens"] / totals["padded_tokens"]
    return {"by_population": result, "total": totals}


def _length_groups(
    updates: list[dict],
    *,
    microbatch_size: int,
    length_cache: _BoundedLengthCache,
) -> dict[str, list[list[int]]]:
    groups: dict[str, list[list[int]]] = defaultdict(list)
    for update in updates:
        for population in ("canonical", "promptshield"):
            rows = update[population]
            for batch in batches(rows, microbatch_size):
                groups[population].append(
                    length_cache.lengths([row["text"] for row in batch])
                )
        pair_microbatch = max(1, microbatch_size // 2)
        for pair_batch in batches(update["pairs"], pair_microbatch):
            rows = [pair[0] for pair in pair_batch] + [pair[1] for pair in pair_batch]
            groups["pairs"].append(length_cache.lengths([row["text"] for row in rows]))
    return dict(groups)


def _population_report(
    tokenizer,
    representative: list[dict],
    stress: dict,
    *,
    microbatch_size: int,
) -> dict:
    length_cache = _BoundedLengthCache(tokenizer, ceiling=CANDIDATE_CAP)
    panels = {
        "representative": _length_groups(
            representative,
            microbatch_size=microbatch_size,
            length_cache=length_cache,
        ),
        "forced_longest_width": _length_groups(
            [stress],
            microbatch_size=microbatch_size,
            length_cache=length_cache,
        ),
    }
    summaries = {
        panel: {
            str(cap): _summarize_length_groups(groups, cap=cap)
            for cap in (BASELINE_CAP, CANDIDATE_CAP)
        }
        for panel, groups in panels.items()
    }
    forced_candidate = summaries["forced_longest_width"][str(CANDIDATE_CAP)][
        "by_population"
    ]
    reached = {
        population: values["padded_width"]["maximum"] == CANDIDATE_CAP
        for population, values in forced_candidate.items()
    }
    return {
        "length_measurement": (
            f"strict-normalized token counts clipped at {CANDIDATE_CAP + 1}; "
            f"{CANDIDATE_CAP + 1} denotes a true length above the "
            f"{CANDIDATE_CAP} candidate cap"
        ),
        "forced_width_check": {
            "candidate_cap": CANDIDATE_CAP,
            "candidate_cap_reached_by_population": reached,
            "all_populations_reached_candidate_cap": all(reached.values()),
            "selection_scope": (
                "bounded raw-length prescreen followed by exact tokenizer-width rerank"
            ),
        },
        "panels": summaries,
    }


def _cache_delta(before: dict, after: dict) -> dict:
    return {key: after[key] - before[key] for key in before if key != "entries"} | {
        "entries_before": before["entries"],
        "entries_after": after["entries"],
    }


def _prewarm_auxiliary(
    cache: _CappedEncodingCache,
    representative: list[dict],
    stress: dict,
) -> dict:
    before = cache.snapshot()
    started = time.perf_counter()
    cache.warm(
        chain(
            (
                row["text"]
                for update in representative
                for row in update["promptshield"]
            ),
            (
                row["text"]
                for update in representative
                for pair in update["pairs"]
                for row in pair
            ),
            (row["text"] for row in stress["promptshield"]),
            (row["text"] for pair in stress["pairs"] for row in pair),
        )
    )
    elapsed = time.perf_counter() - started
    after = cache.snapshot()
    cache.reset_metrics()
    return {"seconds": elapsed, **_cache_delta(before, after)}


def _read_host_cpu() -> tuple[int, int, int, float]:
    fields = Path("/proc/stat").read_text(encoding="utf-8").splitlines()[0].split()
    if not fields or fields[0] != "cpu" or len(fields) < 9:
        raise RuntimeError("unexpected /proc/stat CPU format")
    values = [int(value) for value in fields[1:9]]
    total = sum(values)
    idle = values[3]
    iowait = values[4]
    process = Path("/proc/self/stat").read_text(encoding="utf-8")
    remainder = process[process.rfind(")") + 2 :].split()
    process_ticks = int(remainder[11]) + int(remainder[12])
    return total, idle, iowait, process_ticks / os.sysconf("SC_CLK_TCK")


def _safe_nvml(call, *args):
    try:
        return call(*args)
    except Exception:
        return None


class _TelemetrySampler:
    """Sample NVML plus Linux CPU counters at a fixed interval."""

    def __init__(self, *, interval_seconds: float) -> None:
        self.interval_seconds = interval_seconds
        self.stage = "setup"
        self.samples: list[dict] = []
        self.error: str | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._nvml = None
        self._handle = None

    def start(self) -> None:
        try:
            import pynvml

            pynvml.nvmlInit()
            self._nvml = pynvml
            self._handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        except Exception as error:
            raise RuntimeError(
                "NVML telemetry is required; install/run with --extra tracking"
            ) from error
        self._thread = threading.Thread(
            target=self._sample_loop,
            name="arm6-context-telemetry",
            daemon=True,
        )
        self._thread.start()

    def set_stage(self, stage: str) -> None:
        self.stage = stage

    def stop(self) -> dict:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=max(5.0, self.interval_seconds * 3))
            if self._thread.is_alive():
                self.error = self.error or "telemetry thread did not stop"
        if self._nvml is not None:
            _safe_nvml(self._nvml.nvmlShutdown)
        return self.report()

    def _gpu_sample(self) -> dict:
        nvml = self._nvml
        handle = self._handle
        utilization = _safe_nvml(nvml.nvmlDeviceGetUtilizationRates, handle)
        memory = _safe_nvml(nvml.nvmlDeviceGetMemoryInfo, handle)
        reasons = _safe_nvml(nvml.nvmlDeviceGetCurrentClocksThrottleReasons, handle)

        def reason_active(name: str) -> bool | None:
            flag = getattr(nvml, name, None)
            if reasons is None or flag is None:
                return None
            return bool(reasons & flag)

        power_mw = _safe_nvml(nvml.nvmlDeviceGetPowerUsage, handle)
        return {
            "gpu_utilization_percent": (
                int(utilization.gpu) if utilization is not None else None
            ),
            "memory_utilization_percent": (
                int(utilization.memory) if utilization is not None else None
            ),
            "memory_used_bytes": int(memory.used) if memory is not None else None,
            "power_watts": power_mw / 1000.0 if power_mw is not None else None,
            "temperature_c": _safe_nvml(
                nvml.nvmlDeviceGetTemperature,
                handle,
                nvml.NVML_TEMPERATURE_GPU,
            ),
            "sm_clock_mhz": _safe_nvml(
                nvml.nvmlDeviceGetClockInfo, handle, nvml.NVML_CLOCK_SM
            ),
            "memory_clock_mhz": _safe_nvml(
                nvml.nvmlDeviceGetClockInfo, handle, nvml.NVML_CLOCK_MEM
            ),
            "sw_thermal_slowdown_active": reason_active(
                "nvmlClocksThrottleReasonSwThermalSlowdown"
            ),
            "hw_thermal_slowdown_active": reason_active(
                "nvmlClocksThrottleReasonHwThermalSlowdown"
            ),
        }

    def _sample_loop(self) -> None:
        started = time.monotonic()
        previous = None
        try:
            while not self._stop.is_set():
                sampled_at = time.monotonic()
                total, idle, iowait, process_seconds = _read_host_cpu()
                sample = {
                    "elapsed_seconds": sampled_at - started,
                    "stage": self.stage,
                    **self._gpu_sample(),
                }
                if previous is not None:
                    prior_at, prior_total, prior_idle, prior_iowait, prior_process = (
                        previous
                    )
                    delta_total = total - prior_total
                    delta_idle = idle - prior_idle
                    delta_iowait = iowait - prior_iowait
                    delta_wall = sampled_at - prior_at
                    delta_process = process_seconds - prior_process
                    if delta_total > 0 and delta_wall > 0:
                        sample.update(
                            {
                                "host_cpu_busy_percent": 100.0
                                * (delta_total - delta_idle - delta_iowait)
                                / delta_total,
                                "host_cpu_iowait_percent": 100.0
                                * delta_iowait
                                / delta_total,
                                "process_cpu_core_equivalents": delta_process
                                / delta_wall,
                                "process_cpu_machine_percent": 100.0
                                * delta_process
                                / (delta_wall * (os.cpu_count() or 1)),
                            }
                        )
                self.samples.append(sample)
                previous = (sampled_at, total, idle, iowait, process_seconds)
                spent = time.monotonic() - sampled_at
                self._stop.wait(max(0.0, self.interval_seconds - spent))
        except Exception as error:
            self.error = f"{type(error).__name__}: {str(error)[:1000]}"
            self._stop.set()

    def report(self) -> dict:
        numeric: dict[str, list[float]] = defaultdict(list)
        numeric_by_stage: dict[str, dict[str, list[float]]] = defaultdict(
            lambda: defaultdict(list)
        )
        by_stage: Counter[str] = Counter()
        for sample in self.samples:
            by_stage[sample["stage"]] += 1
            for key, value in sample.items():
                if (
                    key not in {"elapsed_seconds", "stage"}
                    and isinstance(value, (int, float))
                    and not isinstance(value, bool)
                ):
                    numeric[key].append(float(value))
                    numeric_by_stage[sample["stage"]][key].append(float(value))
        summaries = {
            key: {
                "minimum": min(values),
                "mean": sum(values) / len(values),
                "maximum": max(values),
            }
            for key, values in sorted(numeric.items())
            if values
        }
        stage_summaries = {
            stage: {
                key: {
                    "minimum": min(values),
                    "mean": sum(values) / len(values),
                    "maximum": max(values),
                }
                for key, values in sorted(metrics.items())
                if values
            }
            for stage, metrics in sorted(numeric_by_stage.items())
        }
        sw = [sample["sw_thermal_slowdown_active"] for sample in self.samples]
        hw = [sample["hw_thermal_slowdown_active"] for sample in self.samples]
        thermal_supported = bool(sw and hw and None not in sw and None not in hw)
        return {
            "interval_seconds": self.interval_seconds,
            "samples": self.samples,
            "sample_count": len(self.samples),
            "sample_count_by_stage": dict(sorted(by_stage.items())),
            "numeric_summary": summaries,
            "numeric_summary_by_stage": stage_summaries,
            "thermal_flags_supported": thermal_supported,
            "sw_thermal_slowdown_samples": sum(value is True for value in sw),
            "hw_thermal_slowdown_samples": sum(value is True for value in hw),
            "error": self.error,
        }


@contextmanager
def _fused_sdpa_only() -> Iterator[tuple[str, ...]]:
    from torch.nn.attention import SDPBackend, sdpa_kernel

    # Disabling every fallback makes an unsupported shape fail instead of
    # silently materializing the quadratic math-attention intermediate.  Keep
    # every fused backend available so the 512 control still follows PyTorch's
    # normal fused-SDPA choice rather than benchmarking a different kernel.
    names = ("FLASH_ATTENTION", "EFFICIENT_ATTENTION", "CUDNN_ATTENTION")
    enabled = [
        (name, getattr(SDPBackend, name)) for name in names if hasattr(SDPBackend, name)
    ]
    if not enabled:
        raise RuntimeError("this Torch build exposes no fused SDPA backend")
    with sdpa_kernel(backends=[backend for _, backend in enabled]):
        yield tuple(name for name, _ in enabled)


def _timed_pass(
    encoder,
    tokenizer,
    head,
    optimizer,
    updates: list[dict],
    *,
    harmful_class_weights: dict[int, float],
    microbatch_size: int,
    cache: _CappedEncodingCache,
    seed: int,
) -> dict:
    import torch

    arm6._seed_everything(seed)
    before = cache.snapshot()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    wall_started = time.perf_counter()
    process_started = time.process_time()
    event_pairs = []
    with _fused_sdpa_only():
        for update in updates:
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            start.record()
            arm6._run_update(
                encoder,
                tokenizer,
                head,
                optimizer,
                update,
                harmful_class_weights=harmful_class_weights,
                microbatch_size=microbatch_size,
                cache=cache,
            )
            end.record()
            event_pairs.append((start, end))
    torch.cuda.synchronize()
    process_seconds = time.process_time() - process_started
    wall_seconds = time.perf_counter() - wall_started
    cuda_seconds = [start.elapsed_time(end) / 1000.0 for start, end in event_pairs]
    cuda_total_seconds = sum(cuda_seconds)
    after = cache.snapshot()
    return {
        "updates": len(updates),
        "wall_seconds": wall_seconds,
        "wall_mean_update_seconds": wall_seconds / len(updates),
        "wall_updates_per_second": len(updates) / wall_seconds,
        "process_cpu_seconds": process_seconds,
        "process_cpu_core_equivalents": process_seconds / wall_seconds,
        "wall_minus_process_cpu_seconds": max(0.0, wall_seconds - process_seconds),
        "wall_minus_cuda_event_seconds": max(0.0, wall_seconds - cuda_total_seconds),
        "wall_minus_cuda_event_fraction": max(0.0, wall_seconds - cuda_total_seconds)
        / wall_seconds,
        "cuda_event_update_seconds": {
            "mean": float(np.mean(cuda_seconds)),
            "median": float(np.median(cuda_seconds)),
            "p95": float(np.percentile(cuda_seconds, 95)),
            "minimum": min(cuda_seconds),
            "maximum": max(cuda_seconds),
        },
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
        "encoding_cache_delta": _cache_delta(before, after),
    }


def _profile_fused_backend(
    encoder,
    tokenizer,
    head,
    optimizer,
    update: dict,
    *,
    harmful_class_weights: dict[int, float],
    microbatch_size: int,
    cache: _CappedEncodingCache,
) -> dict:
    import torch
    from torch.profiler import ProfilerActivity, profile

    torch.cuda.reset_peak_memory_stats()
    with profile(
        activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
        record_shapes=False,
        profile_memory=False,
        with_stack=False,
    ) as trace:
        with _fused_sdpa_only() as enabled_backends:
            arm6._run_update(
                encoder,
                tokenizer,
                head,
                optimizer,
                update,
                harmful_class_weights=harmful_class_weights,
                microbatch_size=microbatch_size,
                cache=cache,
            )
    torch.cuda.synchronize()
    attention_events = []
    for event in trace.key_averages():
        name = str(event.key)
        if "attention" in name.lower():
            attention_events.append({"name": name, "count": int(event.count)})
    names = [event["name"].lower() for event in attention_events]
    fused = sorted(
        {
            event["name"]
            for event in attention_events
            if any(marker in event["name"].lower() for marker in FUSED_EVENT_MARKERS)
        }
    )
    math_events = sorted(
        {
            event["name"]
            for event in attention_events
            if any(marker in event["name"].lower() for marker in MATH_EVENT_MARKERS)
        }
    )
    return {
        "enabled_backends": [f"SDPBackend.{name}" for name in enabled_backends],
        "math_backend_disabled": True,
        "attention_events": sorted(attention_events, key=lambda value: value["name"]),
        "fused_events": fused,
        "math_events": math_events,
        "passed": bool(fused and not math_events and names),
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
    }


def _cleanup_cuda() -> None:
    import torch

    gc.collect()
    arm6._clear_compiler_state()
    torch.cuda.empty_cache()


def _set_inductor_cache(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=False)
    os.environ["TORCHINDUCTOR_CACHE_DIR"] = str(path)
    arm6._clear_compiler_state()


def _eager_reference(
    tokenizer,
    stress: dict,
    *,
    cap: int,
    harmful_class_weights: dict[int, float],
    microbatch_size: int,
    cache_root: Path,
) -> tuple[dict, np.ndarray | None]:
    import torch

    encoder = head = optimizer = cache = None
    gradient = None
    cell = {"name": f"cap{cap}-sdpa-eager", "attention": "sdpa", "compile": False}
    try:
        _set_inductor_cache(cache_root)
        encoder, head, optimizer, setup = arm6._setup_cell(tokenizer, cell)
        cache = _CappedEncodingCache(tokenizer, max_tokens=cap)
        _prewarm_auxiliary(cache, [], stress)
        with _fused_sdpa_only():
            probe, gradient = arm6._correctness_probe(
                encoder,
                tokenizer,
                head,
                optimizer,
                stress,
                harmful_class_weights=harmful_class_weights,
                microbatch_size=microbatch_size,
                cache=cache,
            )
        backend = _profile_fused_backend(
            encoder,
            tokenizer,
            head,
            optimizer,
            stress,
            harmful_class_weights=harmful_class_weights,
            microbatch_size=microbatch_size,
            cache=cache,
        )
        return {
            "status": "ok",
            **cell,
            "max_tokens": cap,
            "setup": setup,
            "correctness_probe": probe,
            "fused_backend_evidence": backend,
            "eligible_reference": bool(
                probe["gradient"]["finite"] and backend["passed"]
            ),
        }, gradient
    except torch.OutOfMemoryError as error:
        return {
            "status": "oom",
            **cell,
            "max_tokens": cap,
            "error": f"{type(error).__name__}: {str(error)[:2000]}",
            "eligible_reference": False,
        }, None
    except Exception as error:
        return {
            "status": "unavailable",
            **cell,
            "max_tokens": cap,
            "error": f"{type(error).__name__}: {str(error)[:2000]}",
            "eligible_reference": False,
        }, None
    finally:
        del cache, optimizer, head, encoder
        _cleanup_cuda()


def _validation_forward_timing(
    encoder,
    tokenizer,
    head,
    data,
    *,
    cap: int,
    microbatch_size: int,
) -> dict:
    import torch

    cache = _CappedEncodingCache(tokenizer, max_tokens=cap)
    was_encoder_training = encoder.training
    was_head_training = head.training
    encoder.eval()
    head.eval()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    rows = 0
    batch_count = 0
    try:
        with torch.no_grad(), _fused_sdpa_only():
            for population in (data.checkpoint, data.promptshield_validation):
                for batch in batches(population, microbatch_size):
                    values = _cached_batch_logits(
                        encoder,
                        tokenizer,
                        head,
                        [row["text"] for row in batch],
                        train_encoder=False,
                        cache=cache,
                        column=None,
                    )
                    # Match validation's device-to-host synchronization without
                    # publishing predictions or labels.
                    values.float().cpu()
                    rows += len(batch)
                    batch_count += 1
        torch.cuda.synchronize()
        seconds = time.perf_counter() - started
        return {
            "scope": "cap-aware forward and device-to-host only; excludes BCE summaries and checkpoint I/O",
            "rows": rows,
            "batches": batch_count,
            "seconds": seconds,
            "rows_per_second": rows / seconds,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
            "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "encoding_cache": cache.snapshot(),
        }
    finally:
        encoder.train(was_encoder_training)
        head.train(was_head_training)


def _compiled_candidate(
    tokenizer,
    data,
    representative: list[dict],
    stress: dict,
    *,
    cap: int,
    harmful_class_weights: dict[int, float],
    microbatch_size: int,
    reference_probe: dict | None,
    reference_gradient: np.ndarray | None,
    cache_root: Path,
    total_memory: int,
    telemetry_interval_seconds: float,
    validation_timing: bool,
) -> dict:
    import torch

    encoder = head = optimizer = cache = None
    telemetry = _TelemetrySampler(interval_seconds=telemetry_interval_seconds)
    telemetry_report = None
    cell = {"name": f"cap{cap}-sdpa-compile", "attention": "sdpa", "compile": True}
    try:
        telemetry.start()
        telemetry.set_stage(f"cap{cap}:setup")
        _set_inductor_cache(cache_root / "correctness")
        encoder, head, optimizer, setup = arm6._setup_cell(tokenizer, cell)
        correctness_cache = _CappedEncodingCache(tokenizer, max_tokens=cap)
        _prewarm_auxiliary(correctness_cache, [], stress)
        telemetry.set_stage(f"cap{cap}:correctness")
        with _fused_sdpa_only():
            probe, gradient = arm6._correctness_probe(
                encoder,
                tokenizer,
                head,
                optimizer,
                stress,
                harmful_class_weights=harmful_class_weights,
                microbatch_size=microbatch_size,
                cache=correctness_cache,
            )
        if reference_probe is None or reference_gradient is None:
            parity = {
                "reference": f"cap{cap}-sdpa-eager",
                "passed": False,
                "error": "eager correctness reference unavailable",
            }
        else:
            parity = arm6._parity(
                reference_probe,
                reference_gradient,
                probe,
                gradient,
            )
            parity["reference"] = f"cap{cap}-sdpa-eager"

        # The real timed graph gets a distinct empty disk cache.  The cache
        # object is also fresh: only auxiliaries are prewarmed, so the first
        # representative pass measures canonical misses and cold compilation.
        _set_inductor_cache(cache_root / "training")
        cache = _CappedEncodingCache(tokenizer, max_tokens=cap)
        auxiliary_prewarm = _prewarm_auxiliary(cache, representative, stress)
        telemetry.set_stage(f"cap{cap}:cold-canonical")
        cold = _timed_pass(
            encoder,
            tokenizer,
            head,
            optimizer,
            representative,
            harmful_class_weights=harmful_class_weights,
            microbatch_size=microbatch_size,
            cache=cache,
            seed=arm6.PROBE_SEED + 1,
        )
        counters_after_cold = arm6._dynamo_counters()
        warm = []
        for index in range(STEADY_PASSES):
            telemetry.set_stage(f"cap{cap}:warm-canonical-{index + 1}")
            warm.append(
                _timed_pass(
                    encoder,
                    tokenizer,
                    head,
                    optimizer,
                    representative,
                    harmful_class_weights=harmful_class_weights,
                    microbatch_size=microbatch_size,
                    cache=cache,
                    seed=arm6.PROBE_SEED + 2 + index,
                )
            )
        counters_after_warm = arm6._dynamo_counters()
        telemetry.set_stage(f"cap{cap}:forced-profile")
        backend = _profile_fused_backend(
            encoder,
            tokenizer,
            head,
            optimizer,
            stress,
            harmful_class_weights=harmful_class_weights,
            microbatch_size=microbatch_size,
            cache=cache,
        )
        counters_after_profile = arm6._dynamo_counters()
        telemetry.set_stage(f"cap{cap}:forced-width-warm")
        forced = _timed_pass(
            encoder,
            tokenizer,
            head,
            optimizer,
            [stress],
            harmful_class_weights=harmful_class_weights,
            microbatch_size=microbatch_size,
            cache=cache,
            seed=arm6.PROBE_SEED + 100,
        )
        counters_after_forced = arm6._dynamo_counters()
        validation = None
        if validation_timing:
            telemetry.set_stage(f"cap{cap}:validation-forward")
            validation = _validation_forward_timing(
                encoder,
                tokenizer,
                head,
                data,
                cap=cap,
                microbatch_size=microbatch_size,
            )
        telemetry_report = telemetry.stop()
        telemetry = None

        stages = [probe, cold, *warm, backend, forced]
        if validation is not None:
            stages.append(validation)
        peak_allocated = max(value["peak_allocated_bytes"] for value in stages)
        peak_reserved = max(value["peak_reserved_bytes"] for value in stages)
        warm_means = [value["wall_mean_update_seconds"] for value in warm]
        thermal_clear = bool(
            telemetry_report["thermal_flags_supported"]
            and telemetry_report["sw_thermal_slowdown_samples"] == 0
            and telemetry_report["hw_thermal_slowdown_samples"] == 0
            and telemetry_report["error"] is None
        )
        measured_headroom = total_memory - peak_reserved
        portable_limit = int(PORTABLE_DEVICE_BYTES * (1.0 - PORTABLE_HEADROOM_FRACTION))
        eligibility = {
            "parity": bool(parity["passed"]),
            "fused_sdpa": bool(backend["passed"]),
            "measured_device_headroom": bool(
                measured_headroom >= int(total_memory * MINIMUM_L40S_HEADROOM_FRACTION)
            ),
            "thermal_flags_clear": thermal_clear,
        }
        portable_24g = bool(peak_reserved <= portable_limit)
        return {
            "status": "ok",
            **cell,
            "max_tokens": cap,
            "setup": setup,
            "correctness_probe": probe,
            "parity": parity,
            "auxiliary_prewarm": auxiliary_prewarm,
            "cold_canonical_and_compile": {
                **cold,
                "compiler_counters_after": counters_after_cold,
            },
            "warm_canonical": {
                "passes": warm,
                "mean_update_seconds": float(np.mean(warm_means)),
                "median_update_seconds": float(np.median(warm_means)),
                "updates_per_second": 1.0 / float(np.mean(warm_means)),
                "cold_to_warm_ratio": cold["wall_mean_update_seconds"]
                / float(np.mean(warm_means)),
                "compiler_counters_after": counters_after_warm,
            },
            "forced_longest_width": {
                **forced,
                "compiler_counters_after": counters_after_forced,
            },
            "fused_backend_evidence": {
                **backend,
                "compiler_counters_after": counters_after_profile,
            },
            "validation_timing": validation,
            "telemetry": telemetry_report,
            "peak_allocated_bytes": peak_allocated,
            "peak_reserved_bytes": peak_reserved,
            "headroom_bytes": measured_headroom,
            "portable_24g": {
                "device_bytes": PORTABLE_DEVICE_BYTES,
                "minimum_headroom_fraction": PORTABLE_HEADROOM_FRACTION,
                "maximum_eligible_reserved_bytes": portable_limit,
                "passed": portable_24g,
                "role": (
                    "advisory hardware-portability gate; does not invalidate "
                    "a sound L40S measurement"
                ),
            },
            "precision": arm6._precision_report(encoder, head, optimizer),
            "eligibility": eligibility,
            "eligible": all(eligibility.values()),
        }
    except torch.OutOfMemoryError as error:
        if telemetry is not None:
            telemetry_report = telemetry.stop()
            telemetry = None
        return {
            "status": "oom",
            **cell,
            "max_tokens": cap,
            "error": f"{type(error).__name__}: {str(error)[:2000]}",
            "telemetry": telemetry_report,
            "eligible": False,
        }
    except Exception as error:
        if telemetry is not None:
            telemetry_report = telemetry.stop()
            telemetry = None
        return {
            "status": "unavailable",
            **cell,
            "max_tokens": cap,
            "error": f"{type(error).__name__}: {str(error)[:2000]}",
            "telemetry": telemetry_report,
            "eligible": False,
        }
    finally:
        if telemetry is not None:
            telemetry.stop()
        del cache, optimizer, head, encoder
        _cleanup_cuda()


def _comparison(cap_results: dict[str, dict], population: dict) -> dict | None:
    baseline = cap_results[str(BASELINE_CAP)]["compiled_candidate"]
    candidate = cap_results[str(CANDIDATE_CAP)]["compiled_candidate"]
    if baseline.get("status") != "ok" or candidate.get("status") != "ok":
        return None
    baseline_seconds = baseline["warm_canonical"]["mean_update_seconds"]
    candidate_seconds = candidate["warm_canonical"]["mean_update_seconds"]
    baseline_population = population["panels"]["representative"][str(BASELINE_CAP)][
        "total"
    ]
    candidate_population = population["panels"]["representative"][str(CANDIDATE_CAP)][
        "total"
    ]
    return {
        "warm_update_seconds_ratio_1024_over_512": candidate_seconds / baseline_seconds,
        "warm_throughput_ratio_1024_over_512": baseline_seconds / candidate_seconds,
        "peak_reserved_ratio_1024_over_512": candidate["peak_reserved_bytes"]
        / baseline["peak_reserved_bytes"],
        "representative_real_token_ratio_1024_over_512": candidate_population[
            "real_tokens"
        ]
        / baseline_population["real_tokens"],
        "representative_padded_token_ratio_1024_over_512": candidate_population[
            "padded_tokens"
        ]
        / baseline_population["padded_tokens"],
        "forced_update_seconds_ratio_1024_over_512": candidate["forced_longest_width"][
            "wall_mean_update_seconds"
        ]
        / baseline["forced_longest_width"]["wall_mean_update_seconds"],
        "both_caps_eligible": bool(baseline["eligible"] and candidate["eligible"]),
    }


def _publish_json_exclusive(path: Path, value: dict) -> None:
    """Atomically publish without ever replacing an existing result."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError as error:
            raise FileExistsError(
                f"refusing to replace context canary output: {path}"
            ) from error
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _run(args: argparse.Namespace, *, identity: str, output: Path) -> int:
    previous_cache = os.environ.get("TORCHINDUCTOR_CACHE_DIR")
    with tempfile.TemporaryDirectory(prefix=f"morgott-{identity}-inductor-") as root:
        cache_root = Path(root)
        os.environ["TORCHINDUCTOR_CACHE_DIR"] = str(cache_root)
        try:
            device = arm6._device_report(allow_non_l40s=args.allow_non_l40s)
            print("preparing shared aggregate-only context workload", flush=True)
            data = prepare_training_data(
                args.data_dir,
                args.external_dir,
                args.pairs,
                seed=arm6.SEED,
                additional_pair_archive=args.additional_pairs,
                cache_dir=args.prep_cache,
            )
            from transformers import AutoTokenizer

            tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REVISION)
            (
                representative,
                stress,
                harmful_counts,
                harmful_class_weights,
                row_sequence,
            ) = _build_workloads(data, tokenizer)
            population = _population_report(
                tokenizer,
                representative,
                stress,
                microbatch_size=args.microbatch_size,
            )
            cap_results = {}
            for cap in (BASELINE_CAP, CANDIDATE_CAP):
                print(f"cap={cap}: eager fused-SDPA reference", flush=True)
                reference, reference_gradient = _eager_reference(
                    tokenizer,
                    stress,
                    cap=cap,
                    harmful_class_weights=harmful_class_weights,
                    microbatch_size=args.microbatch_size,
                    cache_root=cache_root / f"cap{cap}" / "eager-reference",
                )
                print(f"cap={cap}: compiled fused-SDPA candidate", flush=True)
                candidate = _compiled_candidate(
                    tokenizer,
                    data,
                    representative,
                    stress,
                    cap=cap,
                    harmful_class_weights=harmful_class_weights,
                    microbatch_size=args.microbatch_size,
                    reference_probe=(
                        reference.get("correctness_probe")
                        if reference.get("status") == "ok"
                        else None
                    ),
                    reference_gradient=reference_gradient,
                    cache_root=cache_root / f"cap{cap}" / "compiled-candidate",
                    total_memory=device["total_memory_bytes"],
                    telemetry_interval_seconds=args.telemetry_interval_seconds,
                    validation_timing=args.validation_timing,
                )
                cap_results[str(cap)] = {
                    "eager_reference": reference,
                    "compiled_candidate": candidate,
                }
                print(
                    json.dumps(
                        {
                            "cap": cap,
                            "status": candidate["status"],
                            "eligible": candidate.get("eligible", False),
                            "warm_updates_per_second": candidate.get(
                                "warm_canonical", {}
                            ).get("updates_per_second"),
                            "peak_reserved_bytes": candidate.get("peak_reserved_bytes"),
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
            report = {
                "schema_version": 1,
                "identity": {
                    "name": identity,
                    "baseline_cap": BASELINE_CAP,
                    "candidate_cap": CANDIDATE_CAP,
                    "seed": arm6.SEED,
                    "representative_updates": REPRESENTATIVE_UPDATES,
                    "forced_longest_width_updates": 1,
                    "microbatch_size": args.microbatch_size,
                },
                "purpose": (
                    "post-Arm6 512-versus-1024 compiled fused-SDPA runtime, "
                    "memory, cache, and hardware canary"
                ),
                "created_at": datetime.now(UTC).isoformat(),
                "model_id": MODEL_ID,
                "model_revision": MODEL_REVISION,
                "maintained_core_max_tokens_unchanged": MAX_TOKENS,
                "device": device,
                "versions": {
                    package: version(package)
                    for package in (
                        "numpy",
                        "nvidia-ml-py",
                        "peft",
                        "torch",
                        "transformers",
                    )
                },
                "workload": {
                    "arm": {
                        "mode": "lora",
                        "rank": LORA_RANK,
                        "harmful_head": True,
                    },
                    "head_contract": _head_contract(True),
                    "batch_size": arm6.BATCH_SIZE,
                    "microbatch_size": args.microbatch_size,
                    "shuffle_buffer": arm6.SHUFFLE_BUFFER,
                    "length_grouped": False,
                    "gradient_checkpointing": False,
                    "mixed_precision": "bfloat16",
                    "attention": "SDPA fused backends only; math disabled",
                    "canonical_loss": "one_forward_primary_plus_masked_harmful",
                    "harmful_counts": harmful_counts,
                    "harmful_class_weights": {
                        "negative": harmful_class_weights[0],
                        "positive": harmful_class_weights[1],
                    },
                },
                "row_sequence": row_sequence,
                "population": population,
                "measurement": {
                    "dry_by_default": True,
                    "caps": [BASELINE_CAP, CANDIDATE_CAP],
                    "cells_per_cap": ["sdpa-eager-reference", "sdpa-compile"],
                    "steady_passes": STEADY_PASSES,
                    "inductor_cache": (
                        "isolated empty directories by cap, cell, and "
                        "correctness/training stage"
                    ),
                    "fused_backend_gate": (
                        "Flash, efficient, and cuDNN SDPA backends enabled when "
                        "available; math disabled; profiler must observe a fused "
                        "event and no math event"
                    ),
                    "minimum_l40s_headroom_fraction": (MINIMUM_L40S_HEADROOM_FRACTION),
                    "portable_24g_headroom_fraction": PORTABLE_HEADROOM_FRACTION,
                    "telemetry_interval_seconds": (args.telemetry_interval_seconds),
                    "cpu_wait_telemetry": (
                        "per-pass process CPU and wall-minus-CUDA timings plus "
                        "one-second host busy/iowait and process-core samples"
                    ),
                    "validation_timing_requested": args.validation_timing,
                },
                "caps": cap_results,
                "comparison": _comparison(cap_results, population),
                "all_caps_completed": all(
                    result["compiled_candidate"].get("status") == "ok"
                    for result in cap_results.values()
                ),
                "all_caps_eligible": all(
                    result["compiled_candidate"].get("eligible", False)
                    for result in cap_results.values()
                ),
                "sources": source_provenance(
                    Path(__file__),
                    Path(arm6.__file__),
                    Path(__file__).resolve().parents[2]
                    / "src/morgott/models/mmbert/train.py",
                    Path(__file__).resolve().parents[2]
                    / "src/morgott/models/mmbert/head_contract.py",
                    Path(__file__).resolve().parents[2]
                    / "src/morgott/models/mmbert/core.py",
                ),
                "privacy": (
                    "Only aggregate token-length histograms, counts, timings, "
                    "losses, gradient summaries, compiler counters, and "
                    "hardware telemetry are emitted; no prompt text, score "
                    "array, or row identity is written."
                ),
                "limitations": [
                    "This is a bounded performance canary, not a training or quality result.",
                    "The forced-width update uses a bounded raw-length prescreen before tokenizer reranking.",
                    "Optional validation timing excludes BCE summaries and checkpoint/snapshot I/O.",
                    "Microbatch performance does not authorize a model run or promotion.",
                ],
            }
            _publish_json_exclusive(output, report)
            print(output)
            return (
                0 if report["all_caps_completed"] and report["all_caps_eligible"] else 1
            )
        finally:
            if previous_cache is None:
                os.environ.pop("TORCHINDUCTOR_CACHE_DIR", None)
            else:
                os.environ["TORCHINDUCTOR_CACHE_DIR"] = previous_cache


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    identity, output = _validate_args(args)
    if not args.run:
        print(json.dumps(_dry_plan(args, identity, output), indent=2, sort_keys=True))
        return 0
    return _run(args, identity=identity, output=output)


if __name__ == "__main__":
    raise SystemExit(main())
