"""Dry-by-default microbatch ladder for the 1,024-token no-harm recipe.

This experiment replays one fixed prefix of the exact seed-42, batch-128
optimizer stream used by the no-harm context run.  It compares compiled fused
SDPA at microbatches 24, 32, and 48 without taking a training decision from
free VRAM alone.  Every cell receives the same canonical rows, PromptShield
draws, matched pairs, initial weights, and token cap.

The deterministic probe disables dropout and compares the complete accumulated
gradient against microbatch 24.  Timed passes restore train mode, so their
dropout and optimizer workload match training.  Only aggregate shapes, token
counts, losses, gradient summaries, compiler counters, timing, memory, and
hardware telemetry are emitted; prompt text and row identities never are.

The default invocation is a no-write, no-CUDA plan.  Run the bounded GPU ladder
explicitly after the context evaluation matrix has released the device::

    HF_HOME=/workspace/hf_cache HF_HUB_OFFLINE=1 CUDA_VISIBLE_DEVICES=0 \
      LD_LIBRARY_PATH=/usr/local/cuda-13.0/compat${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH} \
      uv run --locked --extra encoder --extra tracking \
      python experiments/capacity_ladder/benchmark_noharm_context1024_microbatch.py \
      --run
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
import tempfile
import time
from collections import Counter
from datetime import UTC, datetime
from importlib.metadata import version
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

try:
    from experiments.capacity_ladder import benchmark_arm6_context_canary as canary
    from experiments.capacity_ladder import benchmark_arm6_l40s as arm6
except ModuleNotFoundError as error:
    if error.name != "experiments":
        raise
    import benchmark_arm6_context_canary as canary
    import benchmark_arm6_l40s as arm6
from morgott.models.mmbert.core import (
    LORA_RANK,
    MAX_TOKENS,
    MODEL_ID,
    MODEL_REVISION,
    add_lora,
    new_head,
    source_provenance,
)
from morgott.models.mmbert.train import (
    DOMAIN_WEIGHT,
    FULL_POPULATION,
    _classification_backward,
    _configure_compiled_backward_autocast,
    _head_contract,
    _pair_backward,
    prepare_training_data,
)

if TYPE_CHECKING:
    from collections.abc import Sequence


CAP = 1024
REGISTERED_MICROBATCHES = (24, 32, 48)
REFERENCE_MICROBATCH = 24
STEADY_PASSES = 3
MINIMUM_L40S_HEADROOM_FRACTION = 0.10
PORTABLE_DEVICE_BYTES = 24 * 1024**3
PORTABLE_HEADROOM_FRACTION = 0.20
MAXIMUM_STEADY_CV = 0.05
MINIMUM_SPEEDUP_TO_CHANGE = 0.05
MICROBATCH_LOSS_RELATIVE_TOLERANCE = 0.001
MICROBATCH_GRADIENT_COSINE_MINIMUM = 0.999
MICROBATCH_GRADIENT_RELATIVE_L2_MAXIMUM = 0.05
DEFAULT_TELEMETRY_INTERVAL_SECONDS = 1.0
DEFAULT_OUTPUT_ROOT = Path("artifacts/mmbert")


def _identity() -> str:
    cells = "-".join(str(value) for value in REGISTERED_MICROBATCHES)
    return (
        f"arm6-noharm-context{CAP}-microbatch-{cells}"
        f"-s{arm6.SEED}-u{canary.REPRESENTATIVE_UPDATES}"
    )


def _resolve_output(output: Path | None) -> tuple[str, Path]:
    identity = _identity()
    resolved = output or DEFAULT_OUTPUT_ROOT / f"{identity}.json"
    if identity not in resolved.name:
        raise ValueError(
            "output filename must contain the complete resolved experiment "
            f"identity {identity!r}"
        )
    return identity, resolved


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--run",
        action="store_true",
        help="execute the GPU ladder; the default prints a dry plan",
    )
    mode.add_argument(
        "--dry-run",
        action="store_true",
        help="explicit spelling of the default no-GPU, no-write behavior",
    )
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument(
        "--external-dir", type=Path, default=Path("artifacts/mmbert/data")
    )
    parser.add_argument(
        "--pairs",
        type=Path,
        default=Path("data-archive/matched_pairs_20260726.jsonl.gz"),
    )
    parser.add_argument(
        "--additional-pairs",
        type=Path,
        default=Path("artifacts/mmbert_lpft_new_data_rebuilt/train/pairs.jsonl.gz"),
    )
    parser.add_argument(
        "--prep-cache", type=Path, default=Path("artifacts/mmbert/prep-cache")
    )
    parser.add_argument(
        "--microbatch-sizes",
        type=int,
        nargs="+",
        default=list(REGISTERED_MICROBATCHES),
        help="registered comparison is exactly: 24 32 48",
    )
    parser.add_argument(
        "--telemetry-interval-seconds",
        type=float,
        default=DEFAULT_TELEMETRY_INTERVAL_SECONDS,
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument(
        "--allow-non-l40s",
        action="store_true",
        help="development-only escape hatch; hardware remains recorded",
    )
    return parser


def _validate_microbatches(values: Sequence[int]) -> tuple[int, ...]:
    resolved = tuple(values)
    if resolved != REGISTERED_MICROBATCHES:
        raise ValueError(
            "incomparable microbatch cells: the registered ladder is exactly "
            f"{REGISTERED_MICROBATCHES}"
        )
    if any(
        type(value) is not int or value < 2 or value > arm6.BATCH_SIZE or value % 2
        for value in resolved
    ):
        raise ValueError("microbatches must be even integers in [2, 128]")
    return resolved


def _validate_args(args: argparse.Namespace) -> tuple[str, Path]:
    if MAX_TOKENS != canary.BASELINE_CAP or CAP != canary.CANDIDATE_CAP:
        raise RuntimeError("context ladder cap contract no longer matches the trainer")
    _validate_microbatches(args.microbatch_sizes)
    if (
        not math.isfinite(args.telemetry_interval_seconds)
        or args.telemetry_interval_seconds < 0.5
    ):
        raise ValueError("telemetry interval must be finite and at least 0.5 seconds")
    identity, output = _resolve_output(args.output)
    if output.exists():
        raise FileExistsError(f"refusing to replace microbatch result: {output}")
    return identity, output


def _forward_partition(microbatch_size: int) -> dict:
    """Describe the trainer's exact full-step and epoch-tail partitions."""
    if (
        type(microbatch_size) is not int
        or microbatch_size < 2
        or microbatch_size > arm6.BATCH_SIZE
        or microbatch_size % 2
    ):
        raise ValueError("microbatch must be an even integer in [2, 128]")

    def chunks(total: int, size: int) -> list[int]:
        return [min(size, total - start) for start in range(0, total, size)]

    canonical = chunks(arm6.BATCH_SIZE, microbatch_size)
    promptshield = chunks(arm6.BATCH_SIZE // 2, microbatch_size)
    pair_atoms = chunks(arm6.BATCH_SIZE // 4, microbatch_size // 2)
    pair_rows = [2 * value for value in pair_atoms]
    forwards = len(canonical) + len(promptshield) + len(pair_rows)
    final_canonical_rows = FULL_POPULATION["canonical_rows"] % arm6.BATCH_SIZE
    final_canonical = chunks(final_canonical_rows, microbatch_size)
    if (
        sum(canonical) != arm6.BATCH_SIZE
        or sum(promptshield) != arm6.BATCH_SIZE // 2
        or sum(pair_atoms) != arm6.BATCH_SIZE // 4
    ):
        raise AssertionError("forward partition does not conserve the optimizer batch")
    return {
        "scope": "complete optimizer batch; epoch-final tail reported separately",
        "canonical_forward_rows": canonical,
        "promptshield_forward_rows": promptshield,
        "pair_forward_rows": pair_rows,
        "forwards_per_optimizer_update": forwards,
        "maximum_rows_per_forward": microbatch_size,
        "maximum_tokens_per_forward": microbatch_size * CAP,
        "maximum_tokens_per_optimizer_update": (
            (arm6.BATCH_SIZE + arm6.BATCH_SIZE // 2 + arm6.BATCH_SIZE // 2) * CAP
        ),
        "epoch_final_tail": {
            "canonical_rows": final_canonical_rows,
            "canonical_forward_rows": final_canonical,
            "forwards": len(final_canonical) + len(promptshield) + len(pair_rows),
        },
        "loss_normalization": {
            "canonical": f"sum(weighted row losses) / {arm6.BATCH_SIZE}",
            "promptshield": f"sum(row losses) / {arm6.BATCH_SIZE // 2}",
            "pairs": (
                "each pair-chunk mean is weighted by chunk_pairs / "
                f"{arm6.BATCH_SIZE // 4}"
            ),
        },
    }


def _shape_summary(tokenizer, updates: list[dict], *, microbatch_size: int) -> dict:
    """Aggregate the actual capped (batch rows, padded width) graph shapes."""
    length_cache = canary._BoundedLengthCache(tokenizer, ceiling=CAP)
    groups = canary._length_groups(
        updates,
        microbatch_size=microbatch_size,
        length_cache=length_cache,
    )
    by_population = {}
    all_shapes: Counter[tuple[int, int]] = Counter()
    for population, values in sorted(groups.items()):
        shapes = Counter((len(group), min(max(group), CAP)) for group in values)
        all_shapes.update(shapes)
        by_population[population] = {
            "forwards": len(values),
            "unique_shapes": len(shapes),
            "batch_dimensions": sorted({rows for rows, _ in shapes}),
            "padded_widths": {
                "minimum": min(width for _, width in shapes),
                "maximum": max(width for _, width in shapes),
                "unique": len({width for _, width in shapes}),
            },
        }
    return {
        "forwards": sum(len(values) for values in groups.values()),
        "unique_batch_width_shapes": len(all_shapes),
        "batch_dimensions": sorted({rows for rows, _ in all_shapes}),
        "by_population": by_population,
    }


def _dry_plan(args: argparse.Namespace, identity: str, output: Path) -> dict:
    return {
        "mode": "dry-run",
        "run_requested": False,
        "identity": identity,
        "max_tokens": CAP,
        "optimizer_batch_size": arm6.BATCH_SIZE,
        "microbatch_sizes": list(args.microbatch_sizes),
        "representative_updates": canary.REPRESENTATIVE_UPDATES,
        "steady_passes": STEADY_PASSES,
        "cells": [
            {
                "microbatch_size": value,
                "partition": _forward_partition(value),
            }
            for value in args.microbatch_sizes
        ],
        "output": str(output),
        "writes": False,
        "gpu_work": False,
        "next_step": "pass --run after the context evaluation matrix finishes",
    }


def _backward_workload(
    encoder,
    tokenizer,
    head,
    update: dict,
    *,
    microbatch_size: int,
    cache: canary._CappedEncodingCache,
) -> dict[str, object]:
    canonical = _classification_backward(
        encoder,
        tokenizer,
        head,
        update["canonical"],
        coefficient=DOMAIN_WEIGHT,
        microbatch_size=microbatch_size,
        train_encoder=True,
        cache=cache,
        max_tokens=CAP,
    )
    promptshield = _classification_backward(
        encoder,
        tokenizer,
        head,
        update["promptshield"],
        coefficient=DOMAIN_WEIGHT,
        microbatch_size=microbatch_size,
        train_encoder=True,
        cache=cache,
        max_tokens=CAP,
    )
    pair = _pair_backward(
        encoder,
        tokenizer,
        head,
        update["pairs"],
        ranking_weight=arm6.PAIR_RANKING_WEIGHT,
        microbatch_size=microbatch_size,
        train_encoder=True,
        cache=cache,
        max_tokens=CAP,
    )
    total = canonical + promptshield + pair
    return {
        "total_loss": total,
        "primary_loss": total,
        "canonical_primary_loss": canonical,
        "promptshield_loss": promptshield,
        "pair_loss": pair,
    }


def _setup_cell(tokenizer):
    import torch

    arm6._seed_everything(arm6.SEED)
    started = time.perf_counter()
    encoder = arm6._load_encoder("sdpa")
    load_seconds = time.perf_counter() - started
    encoder.gradient_checkpointing_disable()
    encoder = add_lora(encoder)
    head = new_head(encoder.config.hidden_size, arm6.SEED).to("cuda")
    optimizer, fused_optimizer = arm6._new_optimizer(encoder, head)
    torch.set_float32_matmul_precision("high")
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    _configure_compiled_backward_autocast()
    compile_started = time.perf_counter()
    encoder.compile()
    head.compile()
    compile_api_seconds = time.perf_counter() - compile_started
    encoder.train()
    head.train()
    return (
        encoder,
        head,
        optimizer,
        {
            "base_model_load_seconds": load_seconds,
            "setup_seconds": time.perf_counter() - started,
            "compile_api_seconds": compile_api_seconds,
            "fused_adamw": fused_optimizer,
        },
    )


def _correctness_probe(
    encoder,
    tokenizer,
    head,
    optimizer,
    update: dict,
    *,
    microbatch_size: int,
    cache: canary._CappedEncodingCache,
) -> tuple[dict, np.ndarray]:
    import torch

    encoder.eval()
    head.eval()
    optimizer.zero_grad(set_to_none=True)
    arm6._seed_everything(arm6.PROBE_SEED)
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    with canary._fused_sdpa_only():
        metrics = _backward_workload(
            encoder,
            tokenizer,
            head,
            update,
            microbatch_size=microbatch_size,
            cache=cache,
        )
    torch.cuda.synchronize()
    parameters = arm6._trainable_parameters(encoder, head)
    gradient, missing = arm6._gradient_vector(parameters)
    record = {
        "seconds": time.perf_counter() - started,
        "dropout": "disabled_via_eval_for_cross_microbatch_parity",
        "losses": arm6._scalar_metrics(metrics),
        "gradient": {
            "elements": int(gradient.size),
            "missing_parameter_gradients": missing,
            "finite": bool(np.isfinite(gradient).all()),
            "l2_norm": float(np.linalg.norm(gradient)),
            "max_abs": float(np.abs(gradient).max(initial=0.0)),
            "sha256": hashlib.sha256(gradient.tobytes()).hexdigest(),
        },
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
        "compiler_counters": arm6._dynamo_counters(),
    }
    optimizer.zero_grad(set_to_none=True)
    encoder.train()
    head.train()
    return record, gradient


def _run_update(
    encoder,
    tokenizer,
    head,
    optimizer,
    update: dict,
    *,
    microbatch_size: int,
    cache: canary._CappedEncodingCache,
) -> None:
    import torch

    optimizer.zero_grad(set_to_none=True)
    _backward_workload(
        encoder,
        tokenizer,
        head,
        update,
        microbatch_size=microbatch_size,
        cache=cache,
    )
    torch.nn.utils.clip_grad_norm_(
        arm6._trainable_parameters(encoder, head),
        1.0,
        error_if_nonfinite=True,
    )
    optimizer.step()


def _timed_pass(
    encoder,
    tokenizer,
    head,
    optimizer,
    updates: list[dict],
    *,
    microbatch_size: int,
    cache: canary._CappedEncodingCache,
    seed: int,
) -> dict:
    import torch

    arm6._seed_everything(seed)
    before = cache.snapshot()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    wall_started = time.perf_counter()
    process_started = time.process_time()
    event_pairs = []
    with canary._fused_sdpa_only():
        for update in updates:
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            start.record()
            _run_update(
                encoder,
                tokenizer,
                head,
                optimizer,
                update,
                microbatch_size=microbatch_size,
                cache=cache,
            )
            end.record()
            event_pairs.append((start, end))
    torch.cuda.synchronize()
    process_seconds = time.process_time() - process_started
    wall_seconds = time.perf_counter() - wall_started
    cuda_seconds = [start.elapsed_time(end) / 1000.0 for start, end in event_pairs]
    after = cache.snapshot()
    return {
        "updates": len(updates),
        "wall_seconds": wall_seconds,
        "wall_mean_update_seconds": wall_seconds / len(updates),
        "wall_updates_per_second": len(updates) / wall_seconds,
        "process_cpu_seconds": process_seconds,
        "process_cpu_core_equivalents": process_seconds / wall_seconds,
        "cuda_event_update_seconds": {
            "mean": float(np.mean(cuda_seconds)),
            "median": float(np.median(cuda_seconds)),
            "p95": float(np.percentile(cuda_seconds, 95)),
            "minimum": min(cuda_seconds),
            "maximum": max(cuda_seconds),
        },
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
        "encoding_cache_delta": canary._cache_delta(before, after),
    }


def _profile_backend(
    encoder,
    tokenizer,
    head,
    optimizer,
    update: dict,
    *,
    microbatch_size: int,
    cache: canary._CappedEncodingCache,
) -> dict:
    import torch
    from torch.profiler import ProfilerActivity, profile

    torch.cuda.reset_peak_memory_stats()
    with profile(
        activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
        record_shapes=False,
        profile_memory=False,
        with_stack=False,
    ) as trace:
        with canary._fused_sdpa_only() as enabled_backends:
            _run_update(
                encoder,
                tokenizer,
                head,
                optimizer,
                update,
                microbatch_size=microbatch_size,
                cache=cache,
            )
    torch.cuda.synchronize()
    events = sorted(
        (
            {"name": str(event.key), "count": int(event.count)}
            for event in trace.key_averages()
            if "attention" in str(event.key).lower()
        ),
        key=lambda value: value["name"],
    )
    fused = sorted(
        {
            event["name"]
            for event in events
            if any(
                marker in event["name"].lower() for marker in canary.FUSED_EVENT_MARKERS
            )
        }
    )
    math_events = sorted(
        {
            event["name"]
            for event in events
            if any(
                marker in event["name"].lower() for marker in canary.MATH_EVENT_MARKERS
            )
        }
    )
    return {
        "enabled_backends": [f"SDPBackend.{name}" for name in enabled_backends],
        "math_backend_disabled": True,
        "attention_events": events,
        "fused_events": fused,
        "math_events": math_events,
        "passed": bool(events and fused and not math_events),
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
    }


def _benchmark_cell(
    tokenizer,
    representative: list[dict],
    stress: dict,
    *,
    microbatch_size: int,
    cache_root: Path,
    total_memory: int,
    telemetry_interval_seconds: float,
) -> tuple[dict, np.ndarray | None]:
    import torch

    encoder = head = optimizer = cache = None
    gradient = None
    telemetry = canary._TelemetrySampler(interval_seconds=telemetry_interval_seconds)
    telemetry_report = None
    try:
        telemetry.start()
        telemetry.set_stage(f"mb{microbatch_size}:setup")
        canary._set_inductor_cache(cache_root / "correctness")
        encoder, head, optimizer, setup = _setup_cell(tokenizer)
        correctness_cache = canary._CappedEncodingCache(tokenizer, max_tokens=CAP)
        canary._prewarm_auxiliary(correctness_cache, [], stress)
        telemetry.set_stage(f"mb{microbatch_size}:correctness")
        probe, gradient = _correctness_probe(
            encoder,
            tokenizer,
            head,
            optimizer,
            stress,
            microbatch_size=microbatch_size,
            cache=correctness_cache,
        )

        canary._set_inductor_cache(cache_root / "training")
        cache = canary._CappedEncodingCache(tokenizer, max_tokens=CAP)
        auxiliary_prewarm = canary._prewarm_auxiliary(cache, representative, stress)
        telemetry.set_stage(f"mb{microbatch_size}:cold")
        cold = _timed_pass(
            encoder,
            tokenizer,
            head,
            optimizer,
            representative,
            microbatch_size=microbatch_size,
            cache=cache,
            seed=arm6.PROBE_SEED + 1,
        )
        counters_after_cold = arm6._dynamo_counters()
        steady = []
        for index in range(STEADY_PASSES):
            telemetry.set_stage(f"mb{microbatch_size}:steady-{index + 1}")
            steady.append(
                _timed_pass(
                    encoder,
                    tokenizer,
                    head,
                    optimizer,
                    representative,
                    microbatch_size=microbatch_size,
                    cache=cache,
                    seed=arm6.PROBE_SEED + 2 + index,
                )
            )
        counters_after_steady = arm6._dynamo_counters()
        telemetry.set_stage(f"mb{microbatch_size}:forced-profile")
        backend = _profile_backend(
            encoder,
            tokenizer,
            head,
            optimizer,
            stress,
            microbatch_size=microbatch_size,
            cache=cache,
        )
        telemetry.set_stage(f"mb{microbatch_size}:forced-width")
        forced = _timed_pass(
            encoder,
            tokenizer,
            head,
            optimizer,
            [stress],
            microbatch_size=microbatch_size,
            cache=cache,
            seed=arm6.PROBE_SEED + 100,
        )
        telemetry_report = telemetry.stop()
        telemetry = None

        stages = [probe, cold, *steady, backend, forced]
        peak_allocated = max(value["peak_allocated_bytes"] for value in stages)
        peak_reserved = max(value["peak_reserved_bytes"] for value in stages)
        means = np.asarray(
            [value["wall_mean_update_seconds"] for value in steady],
            dtype=np.float64,
        )
        mean_seconds = float(means.mean())
        cv = float(means.std(ddof=1) / mean_seconds) if len(means) > 1 else 0.0
        l40s_headroom = total_memory - peak_reserved
        portable_limit = int(PORTABLE_DEVICE_BYTES * (1 - PORTABLE_HEADROOM_FRACTION))
        thermal_clear = bool(
            telemetry_report["thermal_flags_supported"]
            and telemetry_report["sw_thermal_slowdown_samples"] == 0
            and telemetry_report["hw_thermal_slowdown_samples"] == 0
            and telemetry_report["error"] is None
        )
        return {
            "status": "ok",
            "microbatch_size": microbatch_size,
            "attention": "sdpa",
            "compile": True,
            "max_tokens": CAP,
            "setup": setup,
            "correctness_probe": probe,
            "auxiliary_prewarm": auxiliary_prewarm,
            "cold_canonical_and_compile": {
                **cold,
                "compiler_counters_after": counters_after_cold,
            },
            "steady_state": {
                "passes": steady,
                "mean_update_seconds": mean_seconds,
                "median_update_seconds": float(np.median(means)),
                "updates_per_second": 1.0 / mean_seconds,
                "coefficient_of_variation": cv,
                "compiler_counters_after": counters_after_steady,
            },
            "forced_longest_width": forced,
            "fused_backend_evidence": backend,
            "peak_allocated_bytes": peak_allocated,
            "peak_reserved_bytes": peak_reserved,
            "headroom_bytes": l40s_headroom,
            "portable_24g": {
                "device_bytes": PORTABLE_DEVICE_BYTES,
                "minimum_headroom_fraction": PORTABLE_HEADROOM_FRACTION,
                "maximum_eligible_reserved_bytes": portable_limit,
                "passed": peak_reserved <= portable_limit,
                "role": "memory portability only; timing needs a 4090 rerun",
            },
            "telemetry": telemetry_report,
            "precision": arm6._precision_report(encoder, head, optimizer),
            "pre_parity_gates": {
                "fused_sdpa": bool(backend["passed"]),
                "l40s_headroom": bool(
                    l40s_headroom >= int(total_memory * MINIMUM_L40S_HEADROOM_FRACTION)
                ),
                "thermal_flags_clear": thermal_clear,
                "steady_timing_stable": cv <= MAXIMUM_STEADY_CV,
                "gradient_finite": bool(probe["gradient"]["finite"]),
                "all_parameter_gradients_present": (
                    probe["gradient"]["missing_parameter_gradients"] == 0
                ),
            },
        }, gradient
    except torch.OutOfMemoryError as error:
        if telemetry is not None:
            telemetry_report = telemetry.stop()
            telemetry = None
        return {
            "status": "oom",
            "microbatch_size": microbatch_size,
            "error": f"{type(error).__name__}: {str(error)[:2000]}",
            "telemetry": telemetry_report,
        }, None
    except Exception as error:
        if telemetry is not None:
            telemetry_report = telemetry.stop()
            telemetry = None
        return {
            "status": "unavailable",
            "microbatch_size": microbatch_size,
            "error": f"{type(error).__name__}: {str(error)[:2000]}",
            "telemetry": telemetry_report,
        }, None
    finally:
        if telemetry is not None:
            telemetry.stop()
        del cache, optimizer, head, encoder
        gc.collect()
        canary._cleanup_cuda()


def _attach_parity(
    results: list[dict], gradients: dict[int, np.ndarray | None]
) -> None:
    by_microbatch = {value["microbatch_size"]: value for value in results}
    reference = by_microbatch[REFERENCE_MICROBATCH]
    reference_gradient = gradients[REFERENCE_MICROBATCH]
    reference_probe = reference.get("correctness_probe")
    for result in results:
        gradient = gradients[result["microbatch_size"]]
        if (
            result.get("status") != "ok"
            or reference.get("status") != "ok"
            or reference_probe is None
            or reference_gradient is None
            or gradient is None
        ):
            parity = {
                "reference": f"compiled-mb{REFERENCE_MICROBATCH}",
                "passed": False,
                "error": "reference or candidate correctness probe unavailable",
            }
        else:
            parity = _microbatch_parity(
                reference_probe,
                reference_gradient,
                result["correctness_probe"],
                gradient,
            )
        result["microbatch_parity"] = parity
        gates = result.get("pre_parity_gates", {})
        result["eligible_l40s"] = bool(
            gates and all(gates.values()) and parity["passed"]
        )
        result["eligible_portable_24g"] = bool(
            result["eligible_l40s"] and result.get("portable_24g", {}).get("passed")
        )


def _microbatch_parity(
    reference: dict,
    reference_gradient: np.ndarray,
    probe: dict,
    gradient: np.ndarray,
) -> dict:
    """Apply the tighter partition-only gate justified by same-SDPA evidence."""
    diagnostics = arm6._parity(reference, reference_gradient, probe, gradient)
    passed = bool(
        probe["gradient"]["finite"]
        and diagnostics["worst_loss_relative_difference"]
        <= MICROBATCH_LOSS_RELATIVE_TOLERANCE
        and diagnostics["gradient_cosine"] >= MICROBATCH_GRADIENT_COSINE_MINIMUM
        and diagnostics["gradient_relative_l2"]
        <= MICROBATCH_GRADIENT_RELATIVE_L2_MAXIMUM
    )
    return {
        **diagnostics,
        "reference": f"compiled-mb{REFERENCE_MICROBATCH}",
        "passed": passed,
        "thresholds": {
            "maximum_loss_relative_difference": (MICROBATCH_LOSS_RELATIVE_TOLERANCE),
            "minimum_gradient_cosine": MICROBATCH_GRADIENT_COSINE_MINIMUM,
            "maximum_gradient_relative_l2": (MICROBATCH_GRADIENT_RELATIVE_L2_MAXIMUM),
        },
        "gate_basis": (
            "partition-only same compiled-SDPA comparison; tighter than the "
            "earlier cross-backend launch gate"
        ),
    }


def _decision(results: list[dict]) -> dict:
    eligible = [value for value in results if value.get("eligible_l40s")]
    portable = [value for value in results if value.get("eligible_portable_24g")]
    reference = next(
        value for value in results if value["microbatch_size"] == REFERENCE_MICROBATCH
    )

    def fastest(values: list[dict]) -> dict | None:
        if not values:
            return None
        return min(
            values,
            key=lambda value: value["steady_state"]["mean_update_seconds"],
        )

    selected = fastest(eligible)
    selected_portable = fastest(portable)
    reference_seconds = reference.get("steady_state", {}).get("mean_update_seconds")
    selected_seconds = (
        selected.get("steady_state", {}).get("mean_update_seconds")
        if selected is not None
        else None
    )
    speedup = (
        1.0 - selected_seconds / reference_seconds
        if reference_seconds and selected_seconds
        else None
    )
    change = bool(
        selected is not None
        and selected["microbatch_size"] != REFERENCE_MICROBATCH
        and speedup is not None
        and speedup >= MINIMUM_SPEEDUP_TO_CHANGE
    )
    return {
        "reference_microbatch": REFERENCE_MICROBATCH,
        "selected_l40s_microbatch": (
            selected["microbatch_size"] if selected is not None else None
        ),
        "selected_memory_portable_24g_microbatch": (
            selected_portable["microbatch_size"]
            if selected_portable is not None
            else None
        ),
        "selected_speedup_over_mb24": speedup,
        "minimum_speedup_to_change": MINIMUM_SPEEDUP_TO_CHANGE,
        "recommend_change_from_mb24": change,
        "rule": (
            "change only when the fastest parity/backend/memory/thermal/stability-"
            "passing cell improves mean update time by at least 5%; otherwise "
            "retain microbatch 24"
        ),
        "portable_24g_caveat": (
            "the portable selection is a memory gate, not a 4090 throughput claim"
        ),
    }


def _run(args: argparse.Namespace, *, identity: str, output: Path) -> int:
    previous_cache = os.environ.get("TORCHINDUCTOR_CACHE_DIR")
    with tempfile.TemporaryDirectory(prefix=f"morgott-{identity}-inductor-") as root:
        cache_root = Path(root)
        os.environ["TORCHINDUCTOR_CACHE_DIR"] = str(cache_root)
        try:
            device = arm6._device_report(allow_non_l40s=args.allow_non_l40s)
            print("preparing one shared aggregate-only optimizer stream", flush=True)
            data = prepare_training_data(
                args.data_dir,
                args.external_dir,
                args.pairs,
                seed=arm6.SEED,
                additional_pair_archive=args.additional_pairs,
                cache_dir=args.prep_cache,
            )
            from transformers import AutoTokenizer

            tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REVISION)
            representative, stress, _, _, row_sequence = canary._build_workloads(
                data, tokenizer
            )
            populations = {}
            shapes = {}
            partitions = {}
            for value in REGISTERED_MICROBATCHES:
                populations[str(value)] = canary._population_report(
                    tokenizer,
                    representative,
                    stress,
                    microbatch_size=value,
                )
                shapes[str(value)] = {
                    "representative": _shape_summary(
                        tokenizer, representative, microbatch_size=value
                    ),
                    "forced_longest_width": _shape_summary(
                        tokenizer, [stress], microbatch_size=value
                    ),
                }
                partitions[str(value)] = _forward_partition(value)

            results = []
            gradients = {}
            for value in REGISTERED_MICROBATCHES:
                print(f"benchmarking compiled SDPA microbatch {value}", flush=True)
                result, gradient = _benchmark_cell(
                    tokenizer,
                    representative,
                    stress,
                    microbatch_size=value,
                    cache_root=cache_root / f"mb{value}",
                    total_memory=device["total_memory_bytes"],
                    telemetry_interval_seconds=args.telemetry_interval_seconds,
                )
                result["partition"] = partitions[str(value)]
                result["population"] = populations[str(value)]
                result["compiled_shape_summary"] = shapes[str(value)]
                results.append(result)
                gradients[value] = gradient
                print(
                    json.dumps(
                        {
                            "microbatch_size": value,
                            "status": result["status"],
                            "steady_mean_update_seconds": result.get(
                                "steady_state", {}
                            ).get("mean_update_seconds"),
                            "peak_reserved_bytes": result.get("peak_reserved_bytes"),
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
            _attach_parity(results, gradients)
            del gradients
            report = {
                "schema_version": 1,
                "identity": identity,
                "purpose": (
                    "post-context-evaluation microbatch capacity ladder for the "
                    "1,024-token no-harm rank-8 LoRA recipe"
                ),
                "created_at": datetime.now(UTC).isoformat(),
                "device": device,
                "model_id": MODEL_ID,
                "model_revision": MODEL_REVISION,
                "recipe": {
                    "mode": "lora",
                    "rank": LORA_RANK,
                    "harmful_head": False,
                    "head_contract": _head_contract(False),
                    "optimizer_batch_size": arm6.BATCH_SIZE,
                    "max_tokens": CAP,
                    "microbatch_sizes": list(REGISTERED_MICROBATCHES),
                    "length_grouped": False,
                    "gradient_checkpointing": False,
                    "mixed_precision": "bfloat16",
                    "attention": "compiled fused SDPA; math backend disabled",
                    "seed": arm6.SEED,
                },
                "semantics": {
                    "optimizer_batch_and_row_sequence_fixed": True,
                    "loss_denominators_fixed": True,
                    "batch_norm_present": False,
                    "base_encoder_dropout": 0.0,
                    "lora_dropout": 0.05,
                    "head_dropout": 0.1,
                    "bitwise_identical": False,
                    "caveat": (
                        "dropout draw shapes, padding, BF16 reduction order, and "
                        "gradient accumulation order vary with the partition; "
                        "the deterministic full-gradient probe measures the "
                        "partition-only numerical delta with dropout disabled"
                    ),
                },
                "row_sequence": row_sequence,
                "measurement": {
                    "dry_by_default": True,
                    "representative_updates": canary.REPRESENTATIVE_UPDATES,
                    "forced_longest_width_updates": 1,
                    "steady_passes": STEADY_PASSES,
                    "inductor_cache": (
                        "isolated empty directories per microbatch and "
                        "correctness/training stage"
                    ),
                    "minimum_l40s_headroom_fraction": (MINIMUM_L40S_HEADROOM_FRACTION),
                    "portable_24g_headroom_fraction": PORTABLE_HEADROOM_FRACTION,
                    "maximum_steady_coefficient_of_variation": MAXIMUM_STEADY_CV,
                    "telemetry_interval_seconds": args.telemetry_interval_seconds,
                },
                "results": results,
                "decision": _decision(results),
                "benchmark_completed": all(
                    value["status"] in {"ok", "oom"} for value in results
                ),
                "reference_cell_passed": next(
                    value["eligible_l40s"]
                    for value in results
                    if value["microbatch_size"] == REFERENCE_MICROBATCH
                ),
                "versions": {
                    package: version(package)
                    for package in (
                        "numpy",
                        "nvidia-ml-py",
                        "peft",
                        "torch",
                        "transformers",
                    )
                },
                "sources": source_provenance(
                    Path(__file__),
                    Path(arm6.__file__),
                    Path(canary.__file__),
                    Path(__file__).resolve().parents[2]
                    / "src/morgott/models/mmbert/train.py",
                    Path(__file__).resolve().parents[2]
                    / "src/morgott/models/mmbert/core.py",
                ),
                "privacy": (
                    "Only aggregate shapes, token counts, losses, gradient "
                    "summaries, compiler counters, timing, memory, and telemetry "
                    "are emitted; no prompt text, score array, or row identity."
                ),
                "limitations": [
                    "This is a bounded performance experiment, not a quality result.",
                    "4090 portability is a memory gate; throughput must be rerun there.",
                    "Microbatch 64 is not in this registered ladder; test it only if 48 beats 24 while retaining substantial headroom.",
                    "A faster cell changes future execution only; it cannot rewrite the completed context comparison.",
                ],
            }
            canary._publish_json_exclusive(output, report)
            print(output)
            return int(
                not (report["benchmark_completed"] and report["reference_cell_passed"])
            )
        finally:
            if previous_cache is None:
                os.environ.pop("TORCHINDUCTOR_CACHE_DIR", None)
            else:
                os.environ["TORCHINDUCTOR_CACHE_DIR"] = previous_cache


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    identity, output = _validate_args(args)
    if not args.run:
        print(json.dumps(_dry_plan(args, identity, output), indent=2, sort_keys=True))
        return 0
    return _run(args, identity=identity, output=output)


if __name__ == "__main__":
    raise SystemExit(main())
