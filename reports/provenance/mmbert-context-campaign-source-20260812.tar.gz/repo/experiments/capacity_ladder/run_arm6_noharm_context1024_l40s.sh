#!/usr/bin/env bash
# Matched 1024-token context ablation against the completed contemporary
# no-harm 512-token control. This launcher never changes the data or sampler.
set -euo pipefail

cd "$(dirname "$0")/../.."

# The initial ctx1024 process reached update 500 on 2026-08-10, then exposed
# and stopped on a validation-only missing-no-grad bug before its first
# checkpoint. Its Trackio trace and log are preserved under `-failed-u500`, so
# this corrected process keeps the preregistered successful-arm identity.
RUN_NAME=mmbert-lora-full-s42-mb24-nolengthgroup-noharm-ctx1024
RUNS=${RUNS:-artifacts/mmbert/runs}
LOGS=${LOGS:-artifacts/mmbert/ladder-logs}
PAIRS=${PAIRS:-artifacts/mmbert_lpft_new_data_rebuilt/train/pairs.jsonl.gz}
PROJECT=${PROJECT:-morgott-ladder-v2}
TAIL_AUDIT=${TAIL_AUDIT:-artifacts/mmbert/context-tail-audit-cap512-vs1024-s42-v2.json}
MICROBATCH=24
MAX_TOKENS=1024
ATTENTION=sdpa
CUDA_COMPAT_DIR=${CUDA_COMPAT_DIR:-/usr/local/cuda-13.0/compat}

if [[ ! -d "$CUDA_COMPAT_DIR" ]]; then
  echo "missing CUDA 13 compatibility libraries: $CUDA_COMPAT_DIR" >&2
  exit 2
fi
if [[ ! -f "$PAIRS" ]]; then
  echo "missing rebuilt long-code/SWE pair archive: $PAIRS" >&2
  exit 2
fi
if [[ -e "$RUNS/$RUN_NAME" ]]; then
  echo "refusing to replace completed run: $RUNS/$RUN_NAME" >&2
  exit 2
fi

export LD_LIBRARY_PATH="$CUDA_COMPAT_DIR${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export HF_HOME=${HF_HOME:-/workspace/hf_cache}
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-0}
export PYTHONUNBUFFERED=1
export TOKENIZERS_PARALLELISM=true

if [[ ! -f "$TAIL_AUDIT" ]]; then
  uv run --locked --extra encoder \
    python experiments/capacity_ladder/audit_context_tail.py \
    --run \
    --additional-pairs "$PAIRS" \
    --output "$TAIL_AUDIT"
fi
uv run --locked --extra encoder \
  python experiments/capacity_ladder/audit_context_tail.py \
  --verify "$TAIL_AUDIT" \
  --additional-pairs "$PAIRS"

mkdir -p "$RUNS" "$LOGS"
LOG="$LOGS/$RUN_NAME.train.log"
CHECKPOINT="$RUNS/.$RUN_NAME.checkpoint.pt"
SNAPSHOTS="$RUNS/.$RUN_NAME.snapshots"

resume=()
if [[ -f "$CHECKPOINT" ]]; then
  resume=(--resume)
elif [[ -e "$LOG" || -e "$SNAPSHOTS" ]]; then
  echo "fresh run has stale log/snapshots but no matching checkpoint" >&2
  echo "move them aside or restore $CHECKPOINT" >&2
  exit 2
fi

echo "[$(date -u +%FT%TZ)] run=$RUN_NAME max_tokens=$MAX_TOKENS attention=$ATTENTION compile=1 resume=${#resume[@]}" \
  | tee -a "$LOG"

uv run --locked --extra encoder --extra fa2 --extra tracking \
  python -m morgott.models.mmbert.train \
  --mode lora \
  --lora-rank 8 \
  --no-length-grouped \
  --no-gradient-checkpointing \
  --additional-pairs "$PAIRS" \
  --microbatch-size "$MICROBATCH" \
  --max-tokens "$MAX_TOKENS" \
  --attention "$ATTENTION" \
  --compile \
  --selection-rule source_macro \
  --validation-interval 500 \
  --snapshot-every 500 \
  --comparison-update 17000 \
  --checkpoint-interval 500 \
  --output "$RUNS" \
  --run-name "$RUN_NAME" \
  --trackio \
  --trackio-project "$PROJECT" \
  --trackio-group context-length-ablation \
  "${resume[@]}" \
  2>&1 | tee -a "$LOG"
