#!/usr/bin/env bash
set -euo pipefail

cd /workspace/code/morgott

export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export CUDA_VISIBLE_DEVICES=0
export LD_LIBRARY_PATH="/usr/local/cuda-13.0/compat${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

run_dir="artifacts/mmbert/runs/mmbert-lora-full-s42-mb24-nolengthgroup-noharm-ctx1024"
snapshot="artifacts/mmbert/runs/.mmbert-lora-full-s42-mb24-nolengthgroup-noharm-ctx1024.snapshots/update-018500.pt"
additional_pairs="artifacts/mmbert_lpft_new_data_rebuilt/train/pairs.jsonl.gz"
pair_sha="84a3b1e185755739afca5165ef9aaadb55ce248695bb4c426351f94126ebbbba"
full_output="$run_dir/evaluation-update-18500-trainctx1024-evalctx1024"
full_journal="$run_dir/.evaluation-update-18500-trainctx1024-evalctx1024.score-journal"
reserve_output="$run_dir/redteam-reserve-evaluation-update-18500-trainctx1024-evalctx1024/evaluation.json"
longcode_output="$run_dir/longcode-evaluation-update-18500-trainctx1024-evalctx1024/evaluation.json"
log_dir="artifacts/mmbert/evaluation-logs"
main_log="$log_dir/update18500-native-queue.log"

mkdir -p "$log_dir"

note() {
    printf '%s %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*" | tee -a "$main_log"
}

[[ -s "$snapshot" ]]
[[ -s "$additional_pairs" ]]
[[ ! -e "$full_output" ]]
[[ ! -e "$full_journal" ]]
[[ ! -e "$reserve_output" ]]
[[ ! -e "$longcode_output" ]]

note "GPU 0 starting update-18,500 trainctx1024/evalctx1024 full panel"
uv run --locked --extra encoder python -m morgott.models.mmbert.evaluate \
    "$run_dir" \
    --snapshot "$snapshot" \
    --additional-pairs "$additional_pairs" \
    --batch-size 24 \
    --tokenizer-workers 17 \
    --evaluation-max-tokens 1024 \
    --output "$full_output" \
    --score-journal "$full_journal" \
    > "$log_dir/update18500-trainctx1024-evalctx1024-full.log" 2>&1
[[ -s "$full_output/evaluation.json" ]]
note "GPU 0 completed update-18,500 native full panel"

note "GPU 0 starting update-18,500 native reserve"
uv run --locked --extra encoder \
    python -m experiments.mmbert_redteam_snapshot_eval.run \
    "$run_dir" \
    --snapshot "$snapshot" \
    --full-evaluation "$full_output/evaluation.json" \
    --evaluation-max-tokens 1024 \
    --additional-pairs "$additional_pairs" \
    --batch-size 24 \
    > "$log_dir/update18500-trainctx1024-evalctx1024-reserve.log" 2>&1
[[ -s "$reserve_output" ]]
note "GPU 0 completed update-18,500 native reserve"

note "GPU 0 starting update-18,500 native long-code"
uv run --locked --extra encoder \
    python -m experiments.mmbert_longcode_snapshot_eval.run \
    "$run_dir" \
    --snapshot "$snapshot" \
    --full-evaluation "$full_output/evaluation.json" \
    --evaluation-max-tokens 1024 \
    --batch-size 24 \
    --require-update 18500 \
    --require-additional-pairs-sha256 "$pair_sha" \
    > "$log_dir/update18500-trainctx1024-evalctx1024-longcode.log" 2>&1
[[ -s "$longcode_output" ]]
note "GPU 0 completed update-18,500 native suite"
