#!/usr/bin/env bash
set -euo pipefail

cd /workspace/code/morgott

export HF_HOME=/workspace/hf_cache
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export CUDA_VISIBLE_DEVICES=1
export LD_LIBRARY_PATH="/usr/local/cuda-13.0/compat${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

log_dir="artifacts/mmbert/evaluation-logs"
queue_log="$log_dir/gpu1-granite-or-eval512-queue.log"
canary_json="$log_dir/granite32-canary.json"
canary_log="$log_dir/granite32-canary.log"
granite_output="artifacts/comparisons/granite-guardian-3.2-3b-a800m"
granite_journal="artifacts/comparisons/.granite-guardian-3.2-3b-a800m.rendered-length-v1.score-journal"
panel_sha="2f2c032f63b35d223b06547f1e2289b935fbc70e2c4d7cb20045c1dfa470877d"

run_dir="artifacts/mmbert/runs/mmbert-lora-full-s42-mb24-nolengthgroup-noharm-ctx1024"
snapshot="artifacts/mmbert/runs/.mmbert-lora-full-s42-mb24-nolengthgroup-noharm-ctx1024.snapshots/update-018500.pt"
additional_pairs="artifacts/mmbert_lpft_new_data_rebuilt/train/pairs.jsonl.gz"
pair_sha="84a3b1e185755739afca5165ef9aaadb55ce248695bb4c426351f94126ebbbba"
full512="$run_dir/evaluation-update-18500-trainctx1024-evalctx512"
journal512="$run_dir/.evaluation-update-18500-trainctx1024-evalctx512.score-journal"
longcode512="$run_dir/longcode-evaluation-update-18500-trainctx1024-evalctx512/evaluation.json"

mkdir -p "$log_dir"

note() {
    printf '%s %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*" | tee -a "$queue_log"
}

[[ ! -e "$canary_json" ]]
[[ ! -e "$granite_output" ]]
[[ ! -e "$granite_journal" ]]

note "GPU 1 starting Granite Guardian 3.2 polarity and 4,096-row throughput canary"
uv run --locked --extra encoder python /tmp/granite32_canary.py \
    > "$canary_json" 2> "$canary_log"
note "GPU 1 completed Granite Guardian 3.2 canary"

if jq -e '.gate_passed == true and .panel_sha256 == "'"$panel_sha"'"' "$canary_json" >/dev/null; then
    note "GPU 1 Granite canary passed 90-minute gate; starting full current-panel evaluation"
    uv run --locked --extra encoder python -m experiments.guard_baselines.run \
        --baseline granite-guardian-3.2-3b-a800m \
        --score-journal "$granite_journal" \
        --require-panel-sha256 "$panel_sha" \
        > "$log_dir/granite32-full.log" 2>&1
    [[ -s "$granite_output/evaluation.json" ]]
    note "GPU 1 completed Granite Guardian 3.2 full evaluation"
else
    note "GPU 1 Granite canary exceeded gate; starting update-18,500 eval-at-512 fallback"
    [[ ! -e "$full512" ]]
    [[ ! -e "$journal512" ]]
    [[ ! -e "$longcode512" ]]
    uv run --locked --extra encoder python -m morgott.models.mmbert.evaluate \
        "$run_dir" \
        --snapshot "$snapshot" \
        --additional-pairs "$additional_pairs" \
        --batch-size 24 \
        --tokenizer-workers 17 \
        --evaluation-max-tokens 512 \
        --output "$full512" \
        --score-journal "$journal512" \
        > "$log_dir/update18500-trainctx1024-evalctx512-full.log" 2>&1
    [[ -s "$full512/evaluation.json" ]]
    uv run --locked --extra encoder \
        python -m experiments.mmbert_longcode_snapshot_eval.run \
        "$run_dir" --snapshot "$snapshot" \
        --full-evaluation "$full512/evaluation.json" \
        --evaluation-max-tokens 512 --batch-size 24 --require-update 18500 \
        --require-additional-pairs-sha256 "$pair_sha" \
        > "$log_dir/update18500-trainctx1024-evalctx512-longcode.log" 2>&1
    [[ -s "$longcode512" ]]
    note "GPU 1 completed update-18,500 eval-at-512 fallback"
fi
