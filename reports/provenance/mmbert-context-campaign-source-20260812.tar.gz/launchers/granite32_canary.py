from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np

from experiments.guard_baselines.adapters import build_baseline
from experiments.guard_baselines.run import build_panel, score_rows


SLUG = "granite-guardian-3.2-3b-a800m"
SAMPLE_ROWS = 4096


def main() -> None:
    panel_started = time.perf_counter()
    panel = build_panel(
        data_dir=Path("data"),
        external_dir=Path("artifacts/mmbert/data"),
        pairs=Path("data-archive/matched_pairs_20260726.jsonl.gz"),
        redteam=Path("data-archive/redteam/frozen-reserve.jsonl.gz"),
        allow_drift=False,
        prep_cache=Path("artifacts/mmbert/prep-cache"),
    )
    panel_seconds = time.perf_counter() - panel_started
    rows = [row for values in panel["slices"].values() for row in values]
    if panel["redteam"]:
        rows.extend(panel["redteam"])
    total_rows = len(rows)
    ordered = sorted(range(total_rows), key=lambda index: (len(rows[index]["text"]), index))
    positions = np.linspace(0, total_rows - 1, num=min(SAMPLE_ROWS, total_rows), dtype=np.int64)
    sample = [rows[ordered[int(position)]] for position in positions]

    baseline = build_baseline(SLUG, batch_size=4)
    load_started = time.perf_counter()
    baseline.load()
    load_seconds = time.perf_counter() - load_started
    try:
        scored = score_rows(
            baseline,
            sample,
            batch_size=4,
            label="granite32-canary",
            journal=None,
        )
    finally:
        baseline.unload()

    runtime = scored["runtime"]
    rows_per_second = float(runtime["rows_per_second"])
    projected_score_seconds = total_rows / rows_per_second
    projected_full_seconds_with_buffer = load_seconds + 1.25 * projected_score_seconds
    print(
        json.dumps(
            {
                "schema_version": 1,
                "baseline": SLUG,
                "panel_sha256": panel["panel_sha256"],
                "total_rows": total_rows,
                "sample_rows": len(sample),
                "sample_method": "even quantiles after sorting full panel by raw character length",
                "polarity_smoke_passed": True,
                "panel_seconds": panel_seconds,
                "load_seconds": load_seconds,
                "score_seconds": runtime["seconds"],
                "rows_per_second": rows_per_second,
                "projected_score_seconds": projected_score_seconds,
                "projected_full_seconds_with_buffer": projected_full_seconds_with_buffer,
                "gate_seconds": 5400,
                "gate_passed": projected_full_seconds_with_buffer <= 5400,
                "truncated_fraction": scored["truncation"]["truncated_fraction"],
                "batching": runtime["batching"],
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
