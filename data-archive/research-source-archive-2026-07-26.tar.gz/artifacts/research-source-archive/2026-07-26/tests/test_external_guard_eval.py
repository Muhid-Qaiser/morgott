import unittest

import numpy as np

from morgott.external_guard_eval import (
    _multitask_logits,
    _prepare_examples,
    _route_evaluation,
)


class _Tokenizer:
    pad_token_id = 0
    cls_token_id = 101
    sep_token_id = 102

    def num_special_tokens_to_add(self, pair: bool) -> int:
        return 2

    def encode(self, text: str, *, add_special_tokens: bool) -> list[int]:
        return list(range(int(text)))


def _record(
    text: str,
    channel: str,
    direct: int | None,
    indirect: int | None,
) -> dict:
    return {
        "text": text,
        "hash": text.zfill(64),
        "channel": channel,
        "source": "source",
        "group": f"group:{text}",
        "label_strength": "supported",
        "finance": False,
        "targets": {
            "direct_instruction_subversion": direct,
            "indirect_instruction_subversion": indirect,
            "jailbreak": None,
            "harmful_intent": None,
        },
    }


class ExternalGuardEvaluationTests(unittest.TestCase):
    def test_shared_window_policy_matches_morgott_limits(self):
        records = [
            _record("300", "direct_user", 0, None),
            _record("1000", "untrusted_content", None, 1),
        ]
        examples, metadata = _prepare_examples(_Tokenizer(), records)

        self.assertEqual(
            [len(example["input_ids"]) for example in examples], [256, 512, 512, 238]
        )
        direct = metadata[next(key for key in metadata if key.endswith("direct_user"))]
        indirect = metadata[
            next(key for key in metadata if key.endswith("untrusted_content"))
        ]
        self.assertTrue(direct["truncated"])
        self.assertEqual(direct["window_count"], 1)
        self.assertFalse(indirect["truncated"])
        self.assertEqual(indirect["window_count"], 3)

    def test_shared_route_uses_the_provenance_selected_axis(self):
        records = [
            _record("1", "direct_user", 0, None),
            _record("2", "direct_user", 1, None),
            _record("3", "untrusted_content", None, 0),
            _record("4", "untrusted_content", None, 1),
        ]
        for record in records:
            record["token_length"] = 1
            record["window_count"] = 1

        result = _route_evaluation(
            records,
            np.asarray([0.1, 0.9, 0.2, 0.8], dtype=np.float32),
        )

        self.assertEqual(result["known_rows"], 4)
        self.assertEqual(result["all"]["recall"], 1.0)
        self.assertEqual(result["all"]["fpr"], 0.0)
        self.assertEqual(result["all"]["pr_auc"], 1.0)

    def test_binary_probability_is_reused_without_changing_rank(self):
        logits = _multitask_logits(np.asarray([0.1, 0.9], dtype=np.float32))

        self.assertEqual(logits.shape, (2, 4))
        np.testing.assert_allclose(logits[:, 0], logits[:, 3])
        self.assertLess(logits[0, 0], logits[1, 0])


if __name__ == "__main__":
    unittest.main()
