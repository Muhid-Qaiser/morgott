import unittest

import numpy as np

from morgott.external_guard_analysis import _rates, _threshold


class ExternalGuardAnalysisTests(unittest.TestCase):
    def test_threshold_respects_zero_allowed_false_positives(self):
        labels = np.asarray([0, 0, 1], dtype=np.int8)
        scores = np.asarray([0.1, 0.9, 0.8])

        threshold = _threshold(labels, scores, 0.001)

        self.assertGreater(threshold, 0.9)

    def test_rates_separates_false_positives_and_recall(self):
        labels = np.asarray([0, 0, 1, 1], dtype=np.int8)
        predictions = np.asarray([False, True, True, False])

        self.assertEqual(
            _rates(labels, predictions),
            {
                "rows": 4,
                "positive": 2,
                "negative": 2,
                "recall": 0.5,
                "fpr": 0.5,
                "review_rate": 0.5,
            },
        )

    def test_threshold_requires_negatives(self):
        with self.assertRaisesRegex(ValueError, "requires negative rows"):
            _threshold(np.asarray([1]), np.asarray([0.5]), 0.01)


if __name__ == "__main__":
    unittest.main()
