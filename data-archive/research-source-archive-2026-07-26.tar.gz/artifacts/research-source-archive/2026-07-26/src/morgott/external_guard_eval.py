from __future__ import annotations

import argparse
import gc
import hashlib
import json
import time
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

import numpy as np

from .data import atomic_write_text, file_sha256
from .routing_encoder import (
    DIRECT_MAX_TOKENS,
    HEADS,
    QUICK_FOLDS,
    UNTRUSTED_MAX_TOKENS,
    UNTRUSTED_OVERLAP,
    _binary_metrics,
    _collate,
    _example_batches,
    _lineage_roles,
    _locked_evaluation_hashes,
    _metric_slices,
    _quick_fold_records,
    _records_summary,
    _threshold_profile,
    chunk_token_ids,
    evaluate_scores,
    evaluate_threshold_profiles,
    runtime_metadata,
)

MODEL_SPECS = {
    "prompt_guard_2_86m": {
        "model_id": "meta-llama/Llama-Prompt-Guard-2-86M",
        "revision": "a8ded8e697ce7c355e395a0df51f94adb4a2fd27",
        "scope_heads": (
            "direct_instruction_subversion",
            "indirect_instruction_subversion",
            "jailbreak",
        ),
        "training_overlap": "unknown: exact training sources are not disclosed",
    },
    "wolf_defender": {
        "model_id": "patronus-studio/wolf-defender-prompt-injection",
        "revision": "ecc382bd4d98ffa19e1c9c2ce4a0722904c04a3c",
        "scope_heads": (
            "direct_instruction_subversion",
            "indirect_instruction_subversion",
            "jailbreak",
        ),
        "training_overlap": (
            "known: WildJailbreak, LLMail, NotInject, and deepset "
            "prompt-injections are also Morgott sources"
        ),
    },
    "protectai_deberta_v2": {
        "model_id": "protectai/deberta-v3-base-prompt-injection-v2",
        "revision": "90c9989b1a342275dd0d1a95aad283c04e075671",
        "scope_heads": (
            "direct_instruction_subversion",
            "indirect_instruction_subversion",
        ),
        "training_overlap": (
            "known corpus overlap through XSTest; the card excludes jailbreak detection"
        ),
    },
    "sentinel_v2": {
        "model_id": "rogue-security/prompt-injection-jailbreak-sentinel-v2",
        "revision": "05ff9bfd1f28c5228e53121d5ee4427bb5205212",
        "scope_heads": (
            "direct_instruction_subversion",
            "indirect_instruction_subversion",
            "jailbreak",
        ),
        "training_overlap": (
            "unknown: v2 training sources are not disclosed; WildJailbreak and "
            "deepset prompt-injections are named evaluation sources"
        ),
    },
}

PADDED_TOKEN_BUDGET = 2_048
EVALUATION_POLICY = {
    "direct_max_tokens": DIRECT_MAX_TOKENS,
    "untrusted_max_tokens": UNTRUSTED_MAX_TOKENS,
    "untrusted_overlap": UNTRUSTED_OVERLAP,
    "document_aggregation": "maximum malicious probability across windows",
    "class_probability": "softmax class index 1",
    "inference_dtype": "float16",
}


def _record_key(record: dict) -> str:
    raw_hash = hashlib.sha256(record["text"].encode()).hexdigest()
    return f"{record['hash']}:{raw_hash}:{record['channel']}"


def _row_set_sha256(records: list[dict]) -> str:
    digest = hashlib.sha256()
    for key in sorted(_record_key(record) for record in records):
        digest.update(key.encode())
    return digest.hexdigest()


def _unique_records(partitions: dict[str, dict[str, list[dict]]]) -> list[dict]:
    records = {}
    for fold in partitions.values():
        for rows in fold.values():
            for record in rows:
                records.setdefault(_record_key(record), record)
    return [records[key] for key in sorted(records)]


def _prepare_examples(tokenizer, records: list[dict]) -> tuple[list[dict], dict]:
    examples = []
    metadata = {}
    special_tokens = tokenizer.num_special_tokens_to_add(pair=False)
    for record_index, record in enumerate(records):
        token_ids = np.asarray(
            tokenizer.encode(record["text"], add_special_tokens=False),
            dtype=np.int64,
        )
        if record["channel"] == "direct_user":
            content_limit = DIRECT_MAX_TOKENS - special_tokens
            chunks = [token_ids[:content_limit]]
            truncated = len(token_ids) > content_limit
        else:
            content_limit = UNTRUSTED_MAX_TOKENS - special_tokens
            chunks = chunk_token_ids(
                token_ids,
                content_limit=content_limit,
                overlap=UNTRUSTED_OVERLAP,
            )
            truncated = False
        key = _record_key(record)
        metadata[key] = {
            "token_length": len(token_ids),
            "window_count": len(chunks),
            "truncated": truncated,
        }
        for chunk in chunks:
            if special_tokens == 0:
                input_ids = chunk
            elif (
                special_tokens == 2
                and tokenizer.cls_token_id is not None
                and tokenizer.sep_token_id is not None
            ):
                input_ids = np.empty(len(chunk) + 2, dtype=np.int64)
                input_ids[0] = tokenizer.cls_token_id
                input_ids[1:-1] = chunk
                input_ids[-1] = tokenizer.sep_token_id
            else:
                raise ValueError("unsupported checkpoint special-token contract")
            if len(input_ids) > (
                DIRECT_MAX_TOKENS
                if record["channel"] == "direct_user"
                else UNTRUSTED_MAX_TOKENS
            ):
                raise ValueError(
                    "tokenizer special tokens exceeded the evaluation limit"
                )
            examples.append(
                {
                    "input_ids": input_ids,
                    "record_index": record_index,
                }
            )
    return examples, metadata


def _configure_padding(tokenizer, model) -> str:
    if tokenizer.pad_token_id is not None:
        source = "tokenizer"
    elif tokenizer.eos_token_id is not None:
        tokenizer.pad_token = tokenizer.eos_token
        source = "eos"
    elif tokenizer.unk_token_id is not None:
        tokenizer.pad_token = tokenizer.unk_token
        source = "unknown"
    else:
        raise ValueError("checkpoint tokenizer has no usable padding token")
    model.config.pad_token_id = tokenizer.pad_token_id
    text_config = model.config.get_text_config()
    text_config.pad_token_id = tokenizer.pad_token_id
    return source


def _score_records(spec: dict, records: list[dict]) -> tuple[dict, dict]:
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    model_id = spec["model_id"]
    revision = spec["revision"]
    tokenizer = AutoTokenizer.from_pretrained(model_id, revision=revision)
    model = AutoModelForSequenceClassification.from_pretrained(
        model_id,
        revision=revision,
        dtype=torch.float16,
    )
    padding_source = _configure_padding(tokenizer, model)
    if hasattr(model.config, "use_cache"):
        model.config.use_cache = False
    device = torch.device("cuda")
    model.to(device)
    model.eval()
    examples, metadata = _prepare_examples(tokenizer, records)
    scores = np.zeros(len(records), dtype=np.float32)
    started = time.monotonic()
    torch.cuda.reset_peak_memory_stats(device)
    with torch.inference_mode():
        for indices in _example_batches(
            examples,
            token_budget=PADDED_TOKEN_BUDGET,
            seed=None,
        ):
            input_ids, attention_mask = _collate(
                examples,
                indices,
                tokenizer.pad_token_id,
                device,
            )
            probabilities = torch.softmax(
                model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                ).logits.float(),
                dim=-1,
            )[:, 1]
            for example_index, probability in zip(
                indices,
                probabilities.tolist(),
                strict=True,
            ):
                record_index = examples[example_index]["record_index"]
                scores[record_index] = max(scores[record_index], probability)
    elapsed = time.monotonic() - started
    values = {}
    for record, score in zip(records, scores, strict=True):
        key = _record_key(record)
        values[key] = {"score": float(score), **metadata[key]}
    runtime = {
        "records": len(records),
        "windows": len(examples),
        "seconds": elapsed,
        "records_per_second": len(records) / elapsed,
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(device),
        "padding_source": padding_source,
        "padded_token_budget": PADDED_TOKEN_BUDGET,
    }
    del model
    gc.collect()
    torch.cuda.empty_cache()
    return values, runtime


def _probability_logits(scores: np.ndarray) -> np.ndarray:
    clipped = np.clip(scores.astype(np.float64), 1e-7, 1.0 - 1e-7)
    return np.log(clipped / (1.0 - clipped))


def _multitask_logits(scores: np.ndarray) -> np.ndarray:
    return np.repeat(_probability_logits(scores)[:, None], len(HEADS), axis=1)


def _route_labels(records: list[dict]) -> tuple[np.ndarray, list[dict]]:
    labels = []
    selected = []
    for record in records:
        head = (
            "direct_instruction_subversion"
            if record["channel"] == "direct_user"
            else "indirect_instruction_subversion"
        )
        label = record["targets"][head]
        if label is not None:
            labels.append(label)
            selected.append(record)
    return np.asarray(labels, dtype=np.int8), selected


def _route_evaluation(records: list[dict], scores: np.ndarray) -> dict:
    labels, selected_records = _route_labels(records)
    selected_mask = np.asarray(
        [
            (
                record["targets"]["direct_instruction_subversion"]
                if record["channel"] == "direct_user"
                else record["targets"]["indirect_instruction_subversion"]
            )
            is not None
            for record in records
        ]
    )
    selected_scores = scores[selected_mask]
    group_sizes = Counter(record["group"] for record in selected_records)
    group_weights = np.asarray(
        [1.0 / group_sizes[record["group"]] for record in selected_records]
    )
    slices = _metric_slices(
        selected_records,
        labels,
        selected_scores,
        threshold=0.5,
    )
    source_pr_auc = [
        metrics["pr_auc"]
        for metrics in slices["by_source"].values()
        if metrics["pr_auc"] is not None
    ]
    return {
        "known_rows": len(selected_records),
        "all": _binary_metrics(labels, selected_scores),
        "group_weighted": _binary_metrics(
            labels,
            selected_scores,
            weights=group_weights,
        ),
        "source_macro_pr_auc": (
            float(np.mean(source_pr_auc)) if source_pr_auc else None
        ),
        **slices,
        "threshold_profiles": _threshold_profile(labels, selected_scores),
    }


def _route_operating_points(
    records: list[dict],
    scores: np.ndarray,
    validation: dict,
) -> dict:
    labels, selected_records = _route_labels(records)
    selected_mask = np.asarray(
        [
            (
                record["targets"]["direct_instruction_subversion"]
                if record["channel"] == "direct_user"
                else record["targets"]["indirect_instruction_subversion"]
            )
            is not None
            for record in records
        ]
    )
    selected_scores = scores[selected_mask]
    result = {}
    for name, profile in validation["threshold_profiles"].items():
        if profile is None:
            result[name] = None
            continue
        threshold = profile["threshold"]
        slices = _metric_slices(
            selected_records,
            labels,
            selected_scores,
            threshold=threshold,
        )
        source_fprs = [
            metrics["fpr"]
            for metrics in slices["by_source"].values()
            if metrics["fpr"] is not None
        ]
        result[name] = {
            "threshold": threshold,
            "all": _binary_metrics(labels, selected_scores, threshold=threshold),
            **slices,
            "worst_source_fpr": max(source_fprs) if source_fprs else None,
        }
    return result


def _scores_for(records: list[dict], values: dict) -> np.ndarray:
    for record in records:
        metadata = values[_record_key(record)]
        record.update(
            {
                "token_length": metadata["token_length"],
                "window_count": metadata["window_count"],
                "truncated": metadata["truncated"],
            }
        )
    return np.asarray(
        [values[_record_key(record)]["score"] for record in records],
        dtype=np.float32,
    )


def _load_or_score(
    spec: dict,
    records: list[dict],
    cache_path: Path,
) -> tuple[dict, dict, bool]:
    row_set_sha256 = _row_set_sha256(records)
    if cache_path.is_file():
        cache = json.loads(cache_path.read_bytes())
        if (
            cache.get("model_revision") == spec["revision"]
            and cache.get("row_set_sha256") == row_set_sha256
            and cache.get("evaluation_policy") == EVALUATION_POLICY
        ):
            return cache["values"], cache["runtime"], True
    values, runtime = _score_records(spec, records)
    cache = {
        "schema_version": 1,
        "model_id": spec["model_id"],
        "model_revision": spec["revision"],
        "row_set_sha256": row_set_sha256,
        "evaluation_policy": EVALUATION_POLICY,
        "runtime": runtime,
        "values": values,
    }
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(cache_path, json.dumps(cache, sort_keys=True) + "\n")
    return values, runtime, False


def _external_runtime_metadata() -> dict:
    metadata = runtime_metadata()
    for key in (
        "model_id",
        "model_revision",
        "flash_repository",
        "flash_revision",
        "flash_binary_sha256",
    ):
        metadata.pop(key)
    metadata["runner_sha256"] = file_sha256(Path(__file__))
    return metadata


def _partitions(data_dir: Path, manifest: dict) -> dict:
    lineage_roles = _lineage_roles(data_dir, manifest)
    locked_hashes = _locked_evaluation_hashes(data_dir, manifest)
    result = {}
    for fold_name in QUICK_FOLDS:
        selected = _quick_fold_records(
            data_dir,
            manifest,
            fold_name,
            lineage_roles,
            locked_hashes,
        )
        result[fold_name] = {
            "checkpoint_validation": selected["selection"],
            "source_heldout_validation": selected["heldout"],
            "boundary_validation": selected["boundary_validation"],
        }
    return result


def run_model(
    data_dir: Path,
    artifacts_dir: Path,
    model_name: str,
    *,
    manifest_bytes: bytes | None = None,
    partitions: dict | None = None,
) -> dict:
    spec = MODEL_SPECS[model_name]
    if manifest_bytes is None:
        manifest_bytes = (data_dir / "manifest.json").read_bytes()
    if partitions is None:
        partitions = _partitions(data_dir, json.loads(manifest_bytes))
    records = _unique_records(partitions)
    run_dir = artifacts_dir / "routing_encoder_runs" / "external" / model_name
    values, scoring_runtime, cache_hit = _load_or_score(
        spec,
        records,
        run_dir / "scores.json",
    )
    folds = {}
    for fold_name, fold in partitions.items():
        selection_records = fold["checkpoint_validation"]
        heldout_records = fold["source_heldout_validation"]
        boundary_records = fold["boundary_validation"]
        selection_scores = _scores_for(selection_records, values)
        heldout_scores = _scores_for(heldout_records, values)
        boundary_scores = _scores_for(boundary_records, values)
        selection = evaluate_scores(
            selection_records,
            _multitask_logits(selection_scores),
        )
        heldout = evaluate_scores(
            heldout_records,
            _multitask_logits(heldout_scores),
        )
        route_selection = _route_evaluation(selection_records, selection_scores)
        folds[fold_name] = {
            "selection": {
                "checkpoint_validation": _records_summary(selection_records),
                "source_heldout_validation": _records_summary(heldout_records),
                "boundary_validation": _records_summary(boundary_records),
            },
            "checkpoint_validation": selection,
            "source_heldout_validation": heldout,
            "source_heldout_operating_points": evaluate_threshold_profiles(
                heldout_records,
                _multitask_logits(heldout_scores),
                selection,
            ),
            "boundary_pairs": evaluate_scores(
                boundary_records,
                _multitask_logits(boundary_scores),
            )["pairs"],
            "shared_instruction_subversion": {
                "checkpoint_validation": route_selection,
                "source_heldout_validation": _route_evaluation(
                    heldout_records,
                    heldout_scores,
                ),
                "source_heldout_operating_points": _route_operating_points(
                    heldout_records,
                    heldout_scores,
                    route_selection,
                ),
            },
        }
    result = {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "model_name": model_name,
        "model_id": spec["model_id"],
        "model_revision": spec["revision"],
        "scope_heads": spec["scope_heads"],
        "training_overlap": spec["training_overlap"],
        "data_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "evaluation_policy": EVALUATION_POLICY,
        "runtime": _external_runtime_metadata(),
        "scoring_runtime": scoring_runtime,
        "score_cache_hit": cache_hit,
        "folds": folds,
        "advisory_only": True,
    }
    atomic_write_text(
        run_dir / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    return result


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument("--artifacts-dir", type=Path, default=Path("artifacts"))
    parser.add_argument(
        "--model",
        choices=tuple(MODEL_SPECS),
        action="append",
        required=True,
    )
    return parser


def main() -> None:
    args = _parser().parse_args()
    manifest_bytes = (args.data_dir / "manifest.json").read_bytes()
    partitions = _partitions(args.data_dir, json.loads(manifest_bytes))
    summaries = {}
    for model_name in args.model:
        result = run_model(
            args.data_dir,
            args.artifacts_dir,
            model_name,
            manifest_bytes=manifest_bytes,
            partitions=partitions,
        )
        summaries[model_name] = {
            "result": str(
                args.artifacts_dir
                / "routing_encoder_runs"
                / "external"
                / model_name
                / "result.json"
            ),
            "seconds": result["scoring_runtime"]["seconds"],
            "score_cache_hit": result["score_cache_hit"],
        }
    print(json.dumps(summaries, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
