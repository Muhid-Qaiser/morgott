from __future__ import annotations

import hashlib
import heapq
import json
import math
import platform
import random
import subprocess
from collections import Counter, defaultdict
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
from sklearn.feature_extraction import DictVectorizer
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.metrics import average_precision_score, roc_auc_score

from .corpus import BOUNDARY_INSTRUCTION_FAMILIES
from .data import (
    atomic_write_text,
    file_sha256,
    iter_verified_jsonl,
    manifest_output_path,
    normalize_text,
)

HEADS = (
    "direct_instruction_subversion",
    "indirect_instruction_subversion",
    "jailbreak",
    "harmful_intent",
)
MODEL_ID = "answerdotai/ModernBERT-base"
MODEL_REVISION = "8949b909ec900327062f0ebf497f51aef5e6f0c8"
FLASH_REPOSITORY = "kernels-community/flash-attn2"
FLASH_REVISION = "239bb21bd566f598d7e2228eab9788b0a9239b2d"
FLASH_BINARY_SHA256 = "1433d3fe1187211c5ce622a7373d8c0487227384a2b8c74064e5ed6dfc820727"
FLASH_IMPLEMENTATION = f"{FLASH_REPOSITORY}@{FLASH_REVISION}"
DIRECT_MAX_TOKENS = 256
UNTRUSTED_MAX_TOKENS = 512
UNTRUSTED_OVERLAP = 128
PADDED_TOKEN_BUDGET = 4_096
MAX_RESERVED_BYTES = int(5.2 * 1024**3)
CHECKPOINT_EPOCHS = (0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0)
CONSOLIDATED_MAX_PER_STRATUM = 2_000
CONSOLIDATED_DEFAULT_PROFILE = "0.100%"
CONSOLIDATED_LONG_PROFILE = "1.000%"
LONG_CONTEXT_CHARACTERS = 6_000
LONG_CONTEXT_POSITIONS = ("prefix", "middle", "suffix")
BIPIA_MATCHED_POSITIONS = ("prefix", "middle", "suffix")
FINANCE_SOURCES = {
    "banking77",
    "financebench",
    "harper_valley_bank",
    "tatqa",
    "tensor_trust_raw",
}
JAILBREAK_AXIS_SOURCES = {
    "jailbreaks_over_time",
    "multi_turn",
    "toxic_chat",
    "wildjailbreak",
}
COMBINED_ROUTE_HEADS = {
    "direct_user": (
        "direct_instruction_subversion",
        "jailbreak",
    ),
    "untrusted_content": ("indirect_instruction_subversion",),
}
COMBINED_ROUTE_POSITIVE_LABELS = {
    "direct_jailbreak",
    "direct_prompt_injection",
    "indirect_prompt_injection",
}
PRODUCT_ROUTE_HEADS = frozenset(
    {
        "direct_instruction_subversion",
        "indirect_instruction_subversion",
        "jailbreak",
    }
)
BOUNDARY_DIRECT_FAMILIES = {
    "direct_instruction_override",
    "obfuscation_encoding",
    "roleplay_jailbreak",
    "system_prompt_extraction",
}
FOLDS = {
    "wildjailbreak": {
        "sources": {"wildjailbreak"},
        "heads": {
            "direct_instruction_subversion",
            "jailbreak",
            "harmful_intent",
        },
    },
    "short_finance_agent": {
        "sources": {
            "banking77",
            "financebench",
            "harper_valley_bank",
            "tatqa",
            "tensor_trust_raw",
        },
        "heads": {"direct_instruction_subversion", "harmful_intent"},
    },
    "browsesafe": {
        "sources": {"browsesafe"},
        "heads": {"indirect_instruction_subversion"},
    },
    "task_dialogue": {
        "sources": {"hackaprompt", "schema_guided_dialogue", "taskmaster"},
        "heads": {
            "direct_instruction_subversion",
            "jailbreak",
            "harmful_intent",
        },
    },
    "tail_hard_benign": {
        "sources": {
            "coconot",
            "false_reject",
            "gandalf",
            "lmsys_arena",
            "massive_en",
            "mind2web",
            "prompt_injections",
            "toxic_chat",
        },
        "heads": {
            "direct_instruction_subversion",
            "jailbreak",
            "harmful_intent",
        },
    },
    "bipia": {
        "sources": {"bipia"},
        "heads": {"indirect_instruction_subversion"},
    },
    "llmail": {
        "sources": {"llmail"},
        "heads": {"indirect_instruction_subversion"},
    },
}
QUICK_FOLDS = ("wildjailbreak", "short_finance_agent", "browsesafe")
RECIPES = {
    "core_bce": {"boundary": False, "ranking_weight": 0.0},
    "boundary_bce": {"boundary": True, "ranking_weight": 0.0},
    "boundary_ranking": {"boundary": True, "ranking_weight": 0.25},
}
_LINEAGE_ROLE_CACHE: dict[tuple[str, str], dict[str, str]] = {}


def _origins(row: dict) -> list[dict]:
    origins = row.get("origins")
    return origins if isinstance(origins, list) and origins else [row]


def _weak_origin(origin: dict) -> bool:
    basis = str(origin.get("label_basis", "")).casefold()
    return "weak" in basis or "unverified" in basis


def _boundary_evidence(origin: dict) -> dict[str, int | None]:
    evidence = dict.fromkeys(HEADS)
    family = origin.get("source_pair_family")
    if family not in BOUNDARY_INSTRUCTION_FAMILIES:
        return evidence
    label = origin.get("source_boundary_label")
    if type(label) is not int or label not in {0, 1}:
        return evidence
    if family in BOUNDARY_DIRECT_FAMILIES:
        evidence["direct_instruction_subversion"] = label
    else:
        evidence["indirect_instruction_subversion"] = label
    if family == "roleplay_jailbreak":
        evidence["jailbreak"] = label
    return evidence


def _origin_evidence(origin: dict) -> dict[str, int | None]:
    evidence = dict.fromkeys(HEADS)
    source = origin.get("source")
    role = origin.get("source_role")
    if role == "uncertain":
        return evidence
    if source == "agentic_boundary_pairs":
        return _boundary_evidence(origin)
    if role == "auxiliary":
        if source == "bipia" and origin.get("input_channel") == "untrusted_content":
            if origin.get("injection_label") == 0:
                evidence["indirect_instruction_subversion"] = 0
        return evidence
    if _weak_origin(origin):
        return evidence

    channel = origin.get("input_channel")
    injection = origin.get("injection_label")
    security = origin.get("security_label")
    if channel == "direct_user":
        if security in {"direct_jailbreak", "direct_prompt_injection"}:
            evidence["direct_instruction_subversion"] = 1
        elif (
            source != "toxic_chat"
            and injection == 0
            and security in {"benign", "harmful_non_injection"}
        ):
            evidence["direct_instruction_subversion"] = 0
    elif channel == "untrusted_content":
        if security == "indirect_prompt_injection":
            evidence["indirect_instruction_subversion"] = 1
        elif injection == 0 and security == "benign":
            evidence["indirect_instruction_subversion"] = 0

    if source in JAILBREAK_AXIS_SOURCES:
        if security == "direct_jailbreak":
            evidence["jailbreak"] = 1
        elif injection == 0:
            evidence["jailbreak"] = 0

    basis = str(origin.get("label_basis", ""))
    goal = origin.get("goal_policy_status")
    if "not_human_safety_annotation" not in basis:
        if goal == "unsafe":
            evidence["harmful_intent"] = 1
        elif goal == "safe":
            evidence["harmful_intent"] = 0
    return evidence


def project_targets(row: dict) -> dict[str, int | None]:
    values = {head: set() for head in HEADS}
    for origin in _origins(row):
        for head, value in _origin_evidence(origin).items():
            if value is not None:
                values[head].add(value)
    return {
        head: next(iter(head_values)) if len(head_values) == 1 else None
        for head, head_values in values.items()
    }


def derive_advisory_result(
    scores: dict[str, float],
    *,
    channel: str,
    thresholds: dict[str, float],
    uncertain: bool = False,
) -> dict:
    if channel not in {"direct_user", "untrusted_content"}:
        raise ValueError("trusted provenance must select a supported channel")
    missing = set(HEADS) - scores.keys() | (set(HEADS) - thresholds.keys())
    if missing:
        raise ValueError(f"missing model outputs or thresholds: {sorted(missing)}")
    direct = (
        channel == "direct_user"
        and scores["direct_instruction_subversion"]
        >= thresholds["direct_instruction_subversion"]
    )
    indirect = (
        channel == "untrusted_content"
        and scores["indirect_instruction_subversion"]
        >= thresholds["indirect_instruction_subversion"]
    )
    jailbreak = (
        channel == "direct_user" and scores["jailbreak"] >= thresholds["jailbreak"]
    )
    harmful = scores["harmful_intent"] >= thresholds["harmful_intent"]
    review_required = direct or indirect or jailbreak or uncertain
    return {
        "decision": "allow",
        "advisory_only": True,
        "direct_instruction_subversion": direct,
        "indirect_instruction_subversion": indirect,
        "jailbreak": jailbreak,
        "harmful_intent": harmful,
        "harmful_non_injection": harmful and not (direct or indirect or jailbreak),
        "content_safety_review_recommended": harmful,
        "review_required": review_required,
        "no_security_signal": not (review_required or harmful),
        "uncertain": bool(uncertain),
    }


def chunk_token_ids(
    token_ids: list[int], *, content_limit: int, overlap: int
) -> list[list[int]]:
    if content_limit < 1 or overlap < 0 or overlap >= content_limit:
        raise ValueError("invalid chunk size or overlap")
    if len(token_ids) <= content_limit:
        return [token_ids]
    step = content_limit - overlap
    return [
        token_ids[start : start + content_limit]
        for start in range(0, len(token_ids), step)
        if len(token_ids[start : start + content_limit])
    ]


def masked_bce_loss(logits, targets, target_mask, sample_weights=None):
    import torch
    import torch.nn.functional as functional

    if logits.shape != targets.shape or logits.shape != target_mask.shape:
        raise ValueError("logits, targets, and target mask must have equal shape")
    weights = (
        torch.ones(logits.shape[0], device=logits.device, dtype=logits.dtype)
        if sample_weights is None
        else sample_weights.to(device=logits.device, dtype=logits.dtype)
    )
    head_losses = []
    for head_index in range(logits.shape[1]):
        selected = target_mask[:, head_index].bool()
        if not selected.any():
            continue
        losses = functional.binary_cross_entropy_with_logits(
            logits[selected, head_index],
            targets[selected, head_index].to(logits.dtype),
            reduction="none",
        )
        selected_weights = weights[selected]
        head_losses.append((losses * selected_weights).sum() / selected_weights.sum())
    if not head_losses:
        raise ValueError("masked BCE batch has no known targets")
    return torch.stack(head_losses).mean()


def aligned_pair_ranking_loss(
    logits,
    pair_ids: list[str | None],
    pair_heads: list[int | None],
    pair_labels,
):
    import torch
    import torch.nn.functional as functional

    members = defaultdict(dict)
    for index, (pair_id, head_index) in enumerate(zip(pair_ids, pair_heads)):
        if pair_id is not None and head_index is not None:
            members[(pair_id, head_index)][int(pair_labels[index])] = index
    losses = []
    for (_, head_index), indices in members.items():
        if set(indices) != {0, 1}:
            continue
        benign = logits[indices[0], head_index]
        attack = logits[indices[1], head_index]
        losses.append(functional.softplus(benign - attack))
    if not losses:
        return torch.zeros((), device=logits.device, dtype=logits.dtype)
    return torch.stack(losses).mean()


def document_bag_bce_loss(logits, bag_ids, bag_heads, bag_labels):
    import torch
    import torch.nn.functional as functional

    members = defaultdict(list)
    metadata = {}
    for index, (bag_id, head_index, label) in enumerate(
        zip(bag_ids, bag_heads, bag_labels, strict=True)
    ):
        if bag_id is None or head_index is None or label is None:
            continue
        key = (bag_id, head_index)
        members[key].append(index)
        metadata.setdefault(key, label)
        if metadata[key] != label:
            raise ValueError("document bag has conflicting labels")
    losses = [
        functional.binary_cross_entropy_with_logits(
            logits[indices, head_index].max(),
            torch.tensor(
                float(metadata[(bag_id, head_index)]),
                device=logits.device,
                dtype=logits.dtype,
            ),
        )
        for (bag_id, head_index), indices in members.items()
    ]
    return torch.stack(losses).mean() if losses else None


def flash_gate_passes(result: dict) -> bool:
    comparisons = result.get("comparisons", {})
    return bool(comparisons) and all(
        values.get("finite")
        and values.get("predictions_match")
        and values.get("max_bf16_logit_difference", math.inf) <= 0.125
        and values.get("gradient_cosine", -1.0) >= 0.995
        for values in comparisons.values()
    )


def _record(row: dict, data_role: str) -> dict:
    origins = _origins(row)
    sources = sorted(
        {
            origin.get("source")
            for origin in origins
            if isinstance(origin.get("source"), str)
        }
    )
    source = row.get("source")
    targets = project_targets(row)
    pair_family = next(
        (
            origin.get("source_pair_family")
            for origin in origins
            if origin.get("source") == "agentic_boundary_pairs"
        ),
        None,
    )
    boundary_label = next(
        (
            origin.get("source_boundary_label")
            for origin in origins
            if origin.get("source") == "agentic_boundary_pairs"
        ),
        None,
    )
    pair_head = None
    if pair_family in BOUNDARY_DIRECT_FAMILIES:
        pair_head = HEADS.index("direct_instruction_subversion")
    elif pair_family in BOUNDARY_INSTRUCTION_FAMILIES:
        pair_head = HEADS.index("indirect_instruction_subversion")
    return {
        "id": row["id"],
        "text": row["text"],
        "hash": row["normalized_text_sha256"],
        "source": source,
        "sources": sources,
        "group": row["split_group_id"],
        "channel": row["input_channel"],
        "security_label": row["security_label"],
        "targets": targets,
        "data_role": data_role,
        "label_strength": (
            "weak"
            if origins and all(_weak_origin(origin) for origin in origins)
            else "supported"
        ),
        "finance": any(value in FINANCE_SOURCES for value in sources)
        or any(
            "finance" in str(origin.get("source_risk_domain", "")).casefold()
            or "bank" in str(origin.get("source_risk_domain", "")).casefold()
            for origin in origins
        ),
        "known_payload_span": any(
            value
            for origin in origins
            for key, value in origin.items()
            if "payload_span" in key
        ),
        "payload_char_span": None,
        "pair_id": next(
            (
                origin.get("source_pair_id")
                for origin in origins
                if origin.get("source") == "agentic_boundary_pairs"
            ),
            None,
        ),
        "pair_family": pair_family,
        "pair_head": pair_head,
        "pair_label": boundary_label,
    }


def _lineage_roles(data_dir: Path, manifest: dict) -> dict[str, str]:
    cache_key = (
        str(data_dir.resolve()),
        manifest["source_outputs"]["bipia"]["sha256"],
    )
    if cache_key in _LINEAGE_ROLE_CACHE:
        return _LINEAGE_ROLE_CACHE[cache_key]
    roles = {}
    for split in ("train", "validation", "dev_test"):
        output = manifest["routing_views"][split]
        for row in iter_verified_jsonl(
            manifest_output_path(data_dir, output), output["sha256"]
        ):
            if any(origin.get("source") == "bipia" for origin in _origins(row)):
                roles[row["split_group_id"]] = split
    _LINEAGE_ROLE_CACHE[cache_key] = roles
    return roles


def load_records(
    data_dir: Path,
    manifest: dict,
    split: str,
    *,
    include_boundary: bool,
    include_bipia_clean: bool = True,
) -> list[dict]:
    if split not in {"train", "validation", "dev_test"}:
        raise ValueError(f"unsupported data role: {split}")
    output = manifest["routing_views"][split]
    rows = list(
        iter_verified_jsonl(manifest_output_path(data_dir, output), output["sha256"])
    )
    if include_bipia_clean:
        lineage_roles = _lineage_roles(data_dir, manifest)
        source_output = manifest["source_outputs"]["bipia"]
        for row in iter_verified_jsonl(
            manifest_output_path(data_dir, source_output),
            source_output["sha256"],
        ):
            if (
                row["source_role"] == "auxiliary"
                and lineage_roles.get(row["split_group_id"]) == split
            ):
                rows.append(row)
    if include_boundary:
        source_output = manifest["source_outputs"]["agentic_boundary_pairs"]
        source_split = "test" if split == "dev_test" else split
        for row in iter_verified_jsonl(
            manifest_output_path(data_dir, source_output),
            source_output["sha256"],
        ):
            if (
                row["source_split"] == source_split
                and row.get("source_pair_family") in BOUNDARY_INSTRUCTION_FAMILIES
            ):
                rows.append(row)
    records = []
    seen = set()
    for row in rows:
        record = _record(row, split)
        key = (record["hash"], tuple(record["targets"].items()))
        if (
            key not in seen
            and record["channel"] in {"direct_user", "untrusted_content"}
            and any(value is not None for value in record["targets"].values())
        ):
            seen.add(key)
            records.append(record)
    return records


def apply_fold(
    records: list[dict], fold_name: str, *, training: bool
) -> tuple[list[dict], int]:
    heldout = FOLDS[fold_name]["sources"]
    selected = []
    cross_boundary = 0
    for record in records:
        sources = set(record["sources"])
        touches = bool(sources & heldout)
        crosses = touches and bool(sources - heldout)
        if crosses:
            cross_boundary += 1
            continue
        if touches != (not training):
            continue
        selected.append(record)
    return selected, cross_boundary


def cap_records(records: list[dict], maximum: int) -> list[dict]:
    if maximum < 1:
        raise ValueError("record cap must be positive")
    strata = defaultdict(lambda: defaultdict(list))
    for record in records:
        key = (record["source"], record["security_label"])
        strata[key][record["group"]].append(record)
    selected = []
    for groups in strata.values():
        count = 0
        for group, group_rows in sorted(
            groups.items(),
            key=lambda item: hashlib.sha256(item[0].encode()).digest(),
        ):
            if count and count + len(group_rows) > maximum:
                continue
            selected.extend(group_rows)
            count += len(group_rows)
            if count >= maximum:
                break
    return sorted(selected, key=lambda record: record["hash"])


def _fold_record_status(
    record: dict,
    fold_name: str | None,
    *,
    training: bool,
) -> tuple[bool, bool]:
    if fold_name is None:
        return True, False
    heldout = FOLDS[fold_name]["sources"]
    sources = set(record["sources"])
    touches = bool(sources & heldout)
    crosses = touches and bool(sources - heldout)
    return touches != training and not crosses, crosses


def _cap_grouped_record_stream(
    records,
    maximum: int,
    *,
    fold_name: str | None,
    training: bool,
) -> tuple[list[dict], int]:
    heaps = defaultdict(list)
    group_positions = Counter()
    crossing = 0
    sequence = 0
    for record in records:
        keep, crosses = _fold_record_status(
            record,
            fold_name,
            training=training,
        )
        crossing += crosses
        if not keep:
            continue
        stratum = (record["source"], record["security_label"])
        group_key = (stratum, record["group"])
        position = group_positions[group_key]
        group_positions[group_key] += 1
        group_rank = int.from_bytes(
            hashlib.sha256(record["group"].encode()).digest()[:16]
        )
        row_rank = int(record["hash"], 16)
        item = (-position, -group_rank, -row_rank, sequence, record)
        sequence += 1
        heap = heaps[stratum]
        if len(heap) < maximum:
            heapq.heappush(heap, item)
        elif item > heap[0]:
            heapq.heapreplace(heap, item)
    selected = []
    for heap in heaps.values():
        selected.extend(item[-1] for item in heap)
    selected.sort(key=lambda record: record["hash"])
    return selected, crossing


def load_capped_fold_records(
    data_dir: Path,
    manifest: dict,
    split: str,
    *,
    fold_name: str | None,
    training: bool,
    include_boundary: bool,
    maximum: int,
    lineage_roles: dict[str, str],
) -> tuple[list[dict], int]:
    output = manifest["routing_views"][split]

    def routing_records():
        for row in iter_verified_jsonl(
            manifest_output_path(data_dir, output),
            output["sha256"],
        ):
            record = _record(row, split)
            if record["channel"] in {"direct_user", "untrusted_content"} and any(
                value is not None for value in record["targets"].values()
            ):
                yield record

    selected, crossing = _cap_grouped_record_stream(
        routing_records(),
        maximum,
        fold_name=fold_name,
        training=training,
    )
    selected_groups = {record["group"] for record in selected}
    selected_keys = {
        (record["hash"], tuple(record["targets"].items())) for record in selected
    }
    bipia_output = manifest["source_outputs"]["bipia"]
    for row in iter_verified_jsonl(
        manifest_output_path(data_dir, bipia_output),
        bipia_output["sha256"],
    ):
        if (
            row["source_role"] != "auxiliary"
            or lineage_roles.get(row["split_group_id"]) != split
            or row["split_group_id"] not in selected_groups
        ):
            continue
        record = _record(row, split)
        keep, crosses = _fold_record_status(
            record,
            fold_name,
            training=training,
        )
        crossing += crosses
        key = (record["hash"], tuple(record["targets"].items()))
        if keep and key not in selected_keys:
            selected.append(record)
            selected_keys.add(key)
    if include_boundary and training and split == "train":
        boundary_output = manifest["source_outputs"]["agentic_boundary_pairs"]
        for row in iter_verified_jsonl(
            manifest_output_path(data_dir, boundary_output),
            boundary_output["sha256"],
        ):
            if (
                row["source_split"] != "train"
                or row.get("source_pair_family") not in BOUNDARY_INSTRUCTION_FAMILIES
            ):
                continue
            record = _record(row, split)
            key = (record["hash"], tuple(record["targets"].items()))
            if key not in selected_keys:
                selected.append(record)
                selected_keys.add(key)
    return sorted(selected, key=lambda record: record["hash"]), crossing


def selected_rows_sha256(records: list[dict]) -> str:
    digest = hashlib.sha256()
    for record in sorted(records, key=lambda item: (item["hash"], item["id"])):
        digest.update(record["hash"].encode())
        digest.update(
            json.dumps(
                record["targets"], sort_keys=True, separators=(",", ":")
            ).encode()
        )
    return digest.hexdigest()


def label_support_report(data_dir: Path) -> dict:
    manifest_bytes = (data_dir / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    if manifest.get(
        "schema_version"
    ) != 5 or "agentic_boundary_pairs" not in manifest.get("source_outputs", {}):
        raise ValueError("label audit requires rebuilt canonical schema 5 data")
    counts_by_head = {head: Counter() for head in HEADS}
    source_labels_by_head = {head: defaultdict(set) for head in HEADS}

    def count_row(row: dict, split: str) -> None:
        targets = project_targets(row)
        source = row["source"]
        for head, label in targets.items():
            if label is None:
                continue
            counts_by_head[head][f"{split}:{label}"] += 1
            counts_by_head[head][f"{split}:source:{source}:{label}"] += 1
            if split == "train":
                source_labels_by_head[head][source].add(label)

    lineage_roles = _lineage_roles(data_dir, manifest)
    for split in ("train", "validation", "dev_test"):
        output = manifest["routing_views"][split]
        for row in iter_verified_jsonl(
            manifest_output_path(data_dir, output),
            output["sha256"],
        ):
            count_row(row, split)
    bipia_output = manifest["source_outputs"]["bipia"]
    for row in iter_verified_jsonl(
        manifest_output_path(data_dir, bipia_output),
        bipia_output["sha256"],
    ):
        split = lineage_roles.get(row["split_group_id"])
        if row["source_role"] == "auxiliary" and split is not None:
            count_row(row, split)
    boundary_output = manifest["source_outputs"]["agentic_boundary_pairs"]
    for row in iter_verified_jsonl(
        manifest_output_path(data_dir, boundary_output),
        boundary_output["sha256"],
    ):
        if row.get("source_pair_family") in BOUNDARY_INSTRUCTION_FAMILIES:
            split = "dev_test" if row["source_split"] == "test" else row["source_split"]
            count_row(row, split)

    heads = {}
    for head in HEADS:
        counts = counts_by_head[head]
        source_labels = source_labels_by_head[head]
        positive_sources = sorted(
            source for source, labels in source_labels.items() if 1 in labels
        )
        negative_sources = sorted(
            source for source, labels in source_labels.items() if 0 in labels
        )
        matched_sources = sorted(
            source for source, labels in source_labels.items() if labels == {0, 1}
        )
        support = (
            len(positive_sources) >= 2
            and bool(negative_sources)
            and bool(matched_sources)
        )
        heads[head] = {
            "routing_active": support,
            "positive_training_sources": positive_sources,
            "negative_training_sources": negative_sources,
            "same_source_contrasts": matched_sources,
            "counts": dict(sorted(counts.items())),
        }
    return {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "data_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "heads": heads,
        "all_heads_supported": all(
            values["routing_active"] for values in heads.values()
        ),
        "toxicity": {
            "routing_active": False,
            "reason": (
                "deferred until two independent positive source families and "
                "matched negatives exist"
            ),
        },
    }


def _json_write(path: Path, value: dict) -> None:
    atomic_write_text(path, json.dumps(value, indent=2, sort_keys=True) + "\n")


def runtime_metadata(
    model_id: str = MODEL_ID,
    model_revision: str = MODEL_REVISION,
) -> dict:
    import importlib.metadata

    packages = {}
    for name in ("kernels", "safetensors", "torch", "transformers"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    git_commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    return {
        "python": platform.python_version(),
        "packages": packages,
        "git_commit": git_commit,
        "runner_sha256": file_sha256(Path(__file__)),
        "model_id": model_id,
        "model_revision": model_revision,
        "flash_repository": FLASH_REPOSITORY,
        "flash_revision": FLASH_REVISION,
        "flash_binary_sha256": FLASH_BINARY_SHA256,
    }


def _new_head(
    hidden_size: int,
    seed: int,
    *,
    independent_projections: bool = False,
):
    import torch
    from torch import nn

    torch.manual_seed(seed)

    if independent_projections:

        class IndependentMultipoolHead(nn.Module):
            def __init__(self, hidden_size: int):
                super().__init__()
                self.towers = nn.ModuleList(
                    nn.Sequential(
                        nn.LayerNorm(hidden_size * 3),
                        nn.Linear(hidden_size * 3, 384),
                        nn.GELU(),
                        nn.Dropout(0.1),
                        nn.Linear(384, 1),
                    )
                    for _ in HEADS
                )

            def forward(self, pooled):
                return torch.cat([tower(pooled) for tower in self.towers], dim=-1)

        return IndependentMultipoolHead(hidden_size)

    class MultipoolHead(nn.Module):
        def __init__(self, hidden_size: int):
            super().__init__()
            self.norm = nn.LayerNorm(hidden_size * 3)
            self.projection = nn.Linear(hidden_size * 3, 384)
            self.activation = nn.GELU()
            self.dropout = nn.Dropout(0.1)
            self.outputs = nn.Linear(384, len(HEADS))

        def forward(self, pooled):
            return self.outputs(
                self.dropout(self.activation(self.projection(self.norm(pooled))))
            )

    return MultipoolHead(hidden_size)


def _model_components(
    *,
    attention_implementation: str,
    seed: int,
    model_id: str = MODEL_ID,
    model_revision: str = MODEL_REVISION,
):
    import torch
    from transformers import AutoModel

    torch.manual_seed(seed)
    encoder = AutoModel.from_pretrained(
        model_id,
        revision=model_revision,
        attn_implementation=attention_implementation,
        dtype=torch.bfloat16,
    )
    encoder.gradient_checkpointing_disable()
    for parameter in encoder.parameters():
        parameter.requires_grad = False
    head = _new_head(encoder.config.hidden_size, seed)
    return encoder, head


def _pool_hidden(hidden, attention_mask):
    import torch

    mask = attention_mask.bool()
    expanded = mask.unsqueeze(-1)
    cls = hidden[:, 0] * expanded[:, 0]
    mean = (hidden * expanded).sum(dim=1) / expanded.sum(dim=1).clamp_min(1)
    maximum = hidden.masked_fill(~expanded, torch.finfo(hidden.dtype).min).amax(dim=1)
    return torch.cat((cls, mean, maximum), dim=-1)


def _add_special_tokens(tokenizer, token_ids) -> np.ndarray:
    if (
        tokenizer.num_special_tokens_to_add(pair=False) != 2
        or tokenizer.cls_token_id is None
        or tokenizer.sep_token_id is None
    ):
        raise ValueError("pinned tokenizer must use one CLS and one SEP token")
    values = np.empty(len(token_ids) + 2, dtype=np.int32)
    values[0] = tokenizer.cls_token_id
    values[1:-1] = token_ids
    values[-1] = tokenizer.sep_token_id
    return values


def _encode_records(
    tokenizer,
    records: list[dict],
    *,
    training: bool,
    untrusted_max_tokens: int = UNTRUSTED_MAX_TOKENS,
    untrusted_overlap: int = UNTRUSTED_OVERLAP,
    document_bag_sources: frozenset[str] = frozenset(),
    document_bag_negatives: bool = False,
) -> dict:
    examples = []
    excluded_long_positive = []
    document_bag_ids = []
    special_tokens = tokenizer.num_special_tokens_to_add(pair=False)
    if (
        untrusted_max_tokens <= special_tokens
        or untrusted_overlap < 0
        or untrusted_overlap >= untrusted_max_tokens - special_tokens
    ):
        raise ValueError("invalid untrusted context or overlap")
    for record_index, record in enumerate(records):
        document_bag = False
        encoding = tokenizer._tokenizer.encode(  # noqa: SLF001
            record["text"],
            add_special_tokens=False,
        )
        token_ids = np.asarray(encoding.ids, dtype=np.int32)
        if record["channel"] == "direct_user":
            content_limit = DIRECT_MAX_TOKENS - special_tokens
            chunk_specs = [(0, token_ids[:content_limit])]
            truncated = len(token_ids) > content_limit
        else:
            content_limit = untrusted_max_tokens - special_tokens
            step = content_limit - untrusted_overlap
            chunk_specs = [
                (start, token_ids[start : start + content_limit])
                for start in range(0, len(token_ids), step)
                if len(token_ids[start : start + content_limit])
            ]
            truncated = False
            unknown_span_long_positive = (
                training
                and len(chunk_specs) > 1
                and any(value == 1 for value in record["targets"].values())
                and record.get("payload_char_span") is None
            )
            indirect_target = record["targets"]["indirect_instruction_subversion"]
            document_bag = (
                training
                and len(chunk_specs) > 1
                and record.get("payload_char_span") is None
                and record["source"] in document_bag_sources
                and (
                    indirect_target == 1
                    or (document_bag_negatives and indirect_target == 0)
                )
            )
            if unknown_span_long_positive and not document_bag:
                excluded_long_positive.append(record["id"])
                continue
            if document_bag:
                document_bag_ids.append(record["id"])
        window_count = len(chunk_specs)
        payload_span = record.get("payload_char_span")
        if payload_span is not None:
            payload_start, payload_end = payload_span
            payload_tokens = [
                token_index
                for token_index, (start, end) in enumerate(encoding.offsets)
                if end > payload_start and start < payload_end
            ]
            if not payload_tokens:
                raise ValueError(
                    f"known payload span did not overlap tokens: {record['id']}"
                )
            first_payload_token = min(payload_tokens)
            final_payload_token = max(payload_tokens) + 1
            chunk_specs = [
                (start, chunk)
                for start, chunk in chunk_specs
                if start < final_payload_token
                and start + len(chunk) > first_payload_token
            ]
            if not chunk_specs:
                raise ValueError(
                    f"known payload span did not overlap a window: {record['id']}"
                )
        record["token_length"] = len(token_ids)
        record["window_count"] = window_count
        record["truncated"] = truncated
        for window_index, (_, chunk) in enumerate(chunk_specs):
            input_ids = _add_special_tokens(tokenizer, chunk)
            examples.append(
                {
                    "input_ids": input_ids,
                    "record_index": record_index,
                    "window_index": window_index,
                    "window_count": window_count,
                    "sample_weight": 1.0 / len(chunk_specs),
                    "truncated": truncated,
                    "targets": [
                        record["targets"][head]
                        if record["targets"][head] is not None
                        else 0
                        for head in HEADS
                    ],
                    "target_mask": [
                        record["targets"][head] is not None
                        and not (
                            document_bag and head == "indirect_instruction_subversion"
                        )
                        for head in HEADS
                    ],
                    "bag_id": record["id"] if document_bag else None,
                    "bag_head": (
                        HEADS.index("indirect_instruction_subversion")
                        if document_bag
                        else None
                    ),
                    "bag_label": indirect_target if document_bag else None,
                    "pair_id": record["pair_id"],
                    "pair_head": record["pair_head"],
                    "pair_label": record["pair_label"],
                }
            )
    return {
        "records": records,
        "examples": examples,
        "excluded_long_positive_ids": excluded_long_positive,
        "document_bag_ids": document_bag_ids,
    }


def _example_batches(
    examples: list[dict],
    *,
    token_budget: int,
    seed: int | None,
):
    if seed is None:
        units = [[index] for index in range(len(examples))]
        units.sort(key=lambda unit: len(examples[unit[0]]["input_ids"]))
    else:
        grouped_units = defaultdict(list)
        units = []
        for index, example in enumerate(examples):
            group_id = example.get("bag_id") or example["pair_id"]
            if group_id is None:
                units.append([index])
            else:
                grouped_units[group_id].append(index)
        units.extend(grouped_units.values())
        random.Random(seed).shuffle(units)
    batch = []
    maximum_length = 0
    for unit in units:
        unit_length = max(len(examples[index]["input_ids"]) for index in unit)
        candidate_length = max(maximum_length, unit_length)
        if batch and candidate_length * (len(batch) + len(unit)) > token_budget:
            yield batch
            batch = []
            maximum_length = 0
        batch.extend(unit)
        maximum_length = max(maximum_length, unit_length)
    if batch:
        yield batch


def _collate(examples: list[dict], indices: list[int], pad_token_id: int, device):
    import torch

    maximum = max(len(examples[index]["input_ids"]) for index in indices)
    input_ids = torch.full(
        (len(indices), maximum),
        pad_token_id,
        dtype=torch.long,
        device=device,
    )
    attention_mask = torch.zeros(
        (len(indices), maximum),
        dtype=torch.long,
        device=device,
    )
    for batch_index, example_index in enumerate(indices):
        values = examples[example_index]["input_ids"]
        input_ids[batch_index, : len(values)] = torch.tensor(
            values, dtype=torch.long, device=device
        )
        attention_mask[batch_index, : len(values)] = 1
    return input_ids, attention_mask


def _extract_features(
    encoder,
    tokenizer,
    encoded: dict,
    *,
    token_budget: int = PADDED_TOKEN_BUDGET,
) -> dict:
    import torch

    device = torch.device("cuda")
    encoder.to(device)
    encoder.eval()
    examples = encoded["examples"]
    features = torch.empty(
        (len(examples), encoder.config.hidden_size * 3),
        dtype=torch.bfloat16,
        device="cpu",
    )
    torch.cuda.reset_peak_memory_stats(device)
    with torch.no_grad():
        for indices in _example_batches(
            examples,
            token_budget=token_budget,
            seed=None,
        ):
            input_ids, attention_mask = _collate(
                examples,
                indices,
                tokenizer.pad_token_id,
                device,
            )
            with torch.autocast("cuda", dtype=torch.bfloat16):
                hidden = encoder(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                ).last_hidden_state
                pooled = _pool_hidden(hidden, attention_mask)
            features[indices] = pooled.detach().to(device="cpu", dtype=torch.bfloat16)
    encoded["features"] = features
    encoded["peak_reserved_bytes"] = torch.cuda.max_memory_reserved(device)
    encoded["padded_token_budget"] = token_budget
    return encoded


def _extract_with_vram_budget(encoder, tokenizer, encoded: dict) -> dict:
    import torch

    result = _extract_features(encoder, tokenizer, encoded)
    if result["peak_reserved_bytes"] <= MAX_RESERVED_BYTES:
        return result
    del result["features"]
    torch.cuda.empty_cache()
    return _extract_features(
        encoder,
        tokenizer,
        encoded,
        token_budget=PADDED_TOKEN_BUDGET // 2,
    )


def _aggregate_logits(encoded: dict, logits: np.ndarray) -> np.ndarray:
    row_logits = np.full(
        (len(encoded["records"]), len(HEADS)),
        -np.inf,
        dtype=np.float32,
    )
    for example, values in zip(encoded["examples"], logits):
        row_index = example["record_index"]
        row_logits[row_index] = np.maximum(row_logits[row_index], values)
    return row_logits


def _predict_head(head, encoded: dict, *, batch_size: int = 512) -> np.ndarray:
    import torch

    head.eval()
    device = next(head.parameters()).device
    logits = []
    with torch.no_grad():
        for start in range(0, len(encoded["examples"]), batch_size):
            examples = encoded["examples"][start : start + batch_size]
            if all("feature_index" not in example for example in examples):
                features = encoded["features"][start : start + batch_size].to(device)
            else:
                feature_indices = [
                    example.get("feature_index", start + offset)
                    for offset, example in enumerate(examples)
                ]
                features = encoded["features"][feature_indices].to(device)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                values = head(features)
            logits.append(values.float().cpu().numpy())
    return _aggregate_logits(encoded, np.concatenate(logits))


def _binary_metrics(
    labels: np.ndarray,
    scores: np.ndarray,
    *,
    threshold: float = 0.5,
    weights: np.ndarray | None = None,
) -> dict:
    labels = labels.astype(np.int8)
    scores = scores.astype(np.float64)
    predictions = scores >= threshold
    positives = labels == 1
    negatives = labels == 0
    weights = (
        np.ones(len(labels), dtype=np.float64)
        if weights is None
        else weights.astype(np.float64)
    )
    true_positive = float(weights[predictions & positives].sum())
    false_positive = float(weights[predictions & negatives].sum())
    positive_weight = float(weights[positives].sum())
    negative_weight = float(weights[negatives].sum())
    predicted_weight = true_positive + false_positive
    both_classes = positives.any() and negatives.any()
    return {
        "rows": len(labels),
        "positive": int(positives.sum()),
        "negative": int(negatives.sum()),
        "recall": true_positive / positive_weight if positive_weight else None,
        "fpr": false_positive / negative_weight if negative_weight else None,
        "precision": true_positive / predicted_weight if predicted_weight else 0.0,
        "pr_auc": (
            float(average_precision_score(labels, scores, sample_weight=weights))
            if both_classes
            else None
        ),
        "roc_auc": (
            float(roc_auc_score(labels, scores, sample_weight=weights))
            if both_classes
            else None
        ),
    }


def _threshold_profile(labels: np.ndarray, scores: np.ndarray) -> dict:
    negatives = np.sort(scores[labels == 0])
    profiles = {}
    for target in (0.001, 0.005, 0.01):
        if not len(negatives):
            profiles[f"{target:.3%}"] = None
            continue
        allowed = math.floor(target * len(negatives))
        threshold = (
            float(np.nextafter(negatives[-1], math.inf))
            if allowed == 0
            else float(negatives[-allowed])
        )
        profiles[f"{target:.3%}"] = {
            "threshold": threshold,
            **_binary_metrics(labels, scores, threshold=threshold),
        }
    return profiles


def _pair_summary(pairs: dict) -> dict:
    ordering = 0
    both_correct = 0
    margins = []
    complete = 0
    for values in pairs.values():
        if set(values) != {0, 1}:
            continue
        complete += 1
        margin = values[1] - values[0]
        margins.append(margin)
        ordering += margin > 0
        both_correct += values[1] >= 0.5 and values[0] < 0.5
    return {
        "pairs": complete,
        "ordering_rate": ordering / complete if complete else None,
        "both_correct_rate": both_correct / complete if complete else None,
        "mean_margin": float(np.mean(margins)) if margins else None,
        "median_margin": float(np.median(margins)) if margins else None,
    }


def _pair_metrics(records: list[dict], scores: np.ndarray) -> dict:
    pairs = defaultdict(dict)
    families = {}
    for index, record in enumerate(records):
        pair_id = record["pair_id"]
        head_index = record["pair_head"]
        label = record["pair_label"]
        if pair_id is not None and head_index is not None and label in {0, 1}:
            key = (pair_id, head_index)
            pairs[key][label] = float(scores[index, head_index])
            families[key] = record["pair_family"]
    result = _pair_summary(pairs)
    result["by_family"] = {
        family: _pair_summary(
            {key: values for key, values in pairs.items() if families[key] == family}
        )
        for family in sorted(set(families.values()))
    }
    return result


def _length_bucket(record: dict) -> str:
    length = record.get("token_length")
    if length is None:
        return "unknown"
    for limit in (64, 128, 256, 512):
        if length <= limit:
            return f"up_to_{limit}"
    return "over_512"


def _window_count_bucket(record: dict) -> str:
    count = record.get("window_count")
    if count is None:
        return "unknown"
    if count == 1:
        return "1"
    if count <= 4:
        return "2_to_4"
    if count <= 8:
        return "5_to_8"
    return "9_plus"


def _metric_slices(
    records: list[dict],
    labels: np.ndarray,
    scores: np.ndarray,
    *,
    threshold: float,
) -> dict:
    dimensions = {
        "by_source": lambda record: record["source"],
        "by_channel": lambda record: record["channel"],
        "by_label_strength": lambda record: record["label_strength"],
        "by_length": _length_bucket,
        "by_window_count": _window_count_bucket,
    }
    result = {}
    for name, key_function in dimensions.items():
        keys = [key_function(record) for record in records]
        result[name] = {}
        for key in sorted(set(keys)):
            selected = np.asarray([value == key for value in keys])
            result[name][key] = _binary_metrics(
                labels[selected],
                scores[selected],
                threshold=threshold,
            )
    return result


def evaluate_scores(records: list[dict], logits: np.ndarray) -> dict:
    scores = 1.0 / (1.0 + np.exp(-logits))
    result = {"heads": {}, "pairs": _pair_metrics(records, scores)}
    group_sizes = Counter(record["group"] for record in records)
    for head_index, head in enumerate(HEADS):
        selected = np.asarray(
            [record["targets"][head] is not None for record in records]
        )
        if not selected.any():
            result["heads"][head] = {"known_rows": 0}
            continue
        labels = np.asarray(
            [record["targets"][head] or 0 for record in records],
            dtype=np.int8,
        )[selected]
        head_scores = scores[selected, head_index]
        selected_records = [record for record, keep in zip(records, selected) if keep]
        group_weights = np.asarray(
            [1.0 / group_sizes[record["group"]] for record in selected_records]
        )
        slices = _metric_slices(
            selected_records,
            labels,
            head_scores,
            threshold=0.5,
        )
        source_pr_auc = []
        for metrics in slices["by_source"].values():
            if metrics["pr_auc"] is not None:
                source_pr_auc.append(metrics["pr_auc"])
        result["heads"][head] = {
            "known_rows": int(selected.sum()),
            "all": _binary_metrics(labels, head_scores),
            "group_weighted": _binary_metrics(
                labels,
                head_scores,
                weights=group_weights,
            ),
            "source_macro_pr_auc": (
                float(np.mean(source_pr_auc)) if source_pr_auc else None
            ),
            **slices,
            "threshold_profiles": _threshold_profile(labels, head_scores),
            "finance": _binary_metrics(
                labels[np.asarray([record["finance"] for record in selected_records])],
                head_scores[
                    np.asarray([record["finance"] for record in selected_records])
                ],
            )
            if any(record["finance"] for record in selected_records)
            else None,
        }
    return result


def evaluate_threshold_profiles(
    records: list[dict],
    logits: np.ndarray,
    validation_evaluation: dict,
) -> dict:
    scores = 1.0 / (1.0 + np.exp(-logits))
    result = {}
    for head_index, head in enumerate(HEADS):
        selected = np.asarray(
            [record["targets"][head] is not None for record in records]
        )
        labels = np.asarray(
            [record["targets"][head] or 0 for record in records],
            dtype=np.int8,
        )[selected]
        head_scores = scores[selected, head_index]
        selected_records = [record for record, keep in zip(records, selected) if keep]
        profiles = {}
        validation_profiles = validation_evaluation["heads"][head].get(
            "threshold_profiles", {}
        )
        for name, profile in validation_profiles.items():
            if profile is None:
                profiles[name] = None
                continue
            threshold = profile["threshold"]
            slices = _metric_slices(
                selected_records,
                labels,
                head_scores,
                threshold=threshold,
            )
            fprs = [
                metrics["fpr"]
                for metrics in slices["by_source"].values()
                if metrics["fpr"] is not None
            ]
            profiles[name] = {
                "threshold": threshold,
                "all": _binary_metrics(
                    labels,
                    head_scores,
                    threshold=threshold,
                ),
                **slices,
                "worst_source_fpr": max(fprs) if fprs else None,
            }
        result[head] = profiles
    return result


def evaluate_combined_route_profiles(
    records: list[dict],
    logits: np.ndarray,
    validation_evaluation: dict,
) -> dict:
    scores = 1.0 / (1.0 + np.exp(-logits))
    selected_records = []
    labels = []
    for record in records:
        security_label = record["security_label"]
        if security_label in {"benign", "harmful_non_injection"}:
            label = 0
        elif security_label in COMBINED_ROUTE_POSITIVE_LABELS:
            label = 1
        else:
            continue
        selected_records.append(record)
        labels.append(label)
    if not selected_records:
        return {}
    selected = np.asarray(
        [
            index
            for index, record in enumerate(records)
            if record["security_label"] in {"benign", "harmful_non_injection"}
            or record["security_label"] in COMBINED_ROUTE_POSITIVE_LABELS
        ]
    )
    labels_array = np.asarray(labels, dtype=np.int8)
    profiles = {}
    for profile_name in ("0.100%", "0.500%", "1.000%"):
        thresholds = {}
        for head in HEADS:
            profile = (
                validation_evaluation["heads"][head]
                .get("threshold_profiles", {})
                .get(profile_name)
            )
            if profile is not None:
                thresholds[head] = profile["threshold"]
        margins = []
        for record_index, record in zip(selected, selected_records, strict=True):
            applicable = [
                head
                for head in COMBINED_ROUTE_HEADS[record["channel"]]
                if head in thresholds
            ]
            margins.append(
                max(
                    (
                        scores[record_index, HEADS.index(head)] - thresholds[head]
                        for head in applicable
                    ),
                    default=-1e9,
                )
            )
        margins_array = np.asarray(margins, dtype=np.float64)
        slices = _metric_slices(
            selected_records,
            labels_array,
            margins_array,
            threshold=0.0,
        )
        source_fprs = [
            metrics["fpr"]
            for metrics in slices["by_source"].values()
            if metrics["fpr"] is not None
        ]
        finance_mask = np.asarray([record["finance"] for record in selected_records])
        profiles[profile_name] = {
            "thresholds": thresholds,
            "all": _binary_metrics(
                labels_array,
                margins_array,
                threshold=0.0,
            ),
            **slices,
            "finance": (
                _binary_metrics(
                    labels_array[finance_mask],
                    margins_array[finance_mask],
                    threshold=0.0,
                )
                if finance_mask.any()
                else None
            ),
            "worst_source_fpr": max(source_fprs) if source_fprs else None,
        }
    return profiles


def evaluate_direct_research_slices(
    records: list[dict],
    logits: np.ndarray,
    validation_evaluation: dict,
    *,
    profile_name: str = CONSOLIDATED_DEFAULT_PROFILE,
) -> dict:
    scores = 1.0 / (1.0 + np.exp(-logits))
    thresholds = {}
    for head in COMBINED_ROUTE_HEADS["direct_user"]:
        profile = (
            validation_evaluation["heads"][head]
            .get("threshold_profiles", {})
            .get(profile_name)
        )
        if profile is not None:
            thresholds[head] = profile["threshold"]
    if not thresholds:
        raise ValueError("direct research evaluation has no calibrated route heads")

    selected_records = []
    labels = []
    margins = []
    for index, record in enumerate(records):
        if record["channel"] != "direct_user":
            continue
        if record["security_label"] in {"benign", "harmful_non_injection"}:
            label = 0
        elif record["security_label"] in COMBINED_ROUTE_POSITIVE_LABELS:
            label = 1
        else:
            continue
        selected_records.append(record)
        labels.append(label)
        margins.append(
            max(
                scores[index, HEADS.index(head)] - threshold
                for head, threshold in thresholds.items()
            )
        )

    labels_array = np.asarray(labels, dtype=np.int8)
    margins_array = np.asarray(margins, dtype=np.float64)

    def by_field(field: str) -> dict:
        keys = [record.get(field, "unknown") for record in selected_records]
        return {
            str(key): _binary_metrics(
                labels_array[np.asarray([value == key for value in keys])],
                margins_array[np.asarray([value == key for value in keys])],
                threshold=0.0,
            )
            for key in sorted(set(keys), key=str)
        }

    return {
        "profile": profile_name,
        "thresholds": thresholds,
        "all": _binary_metrics(labels_array, margins_array, threshold=0.0),
        "by_source": by_field("source"),
        "by_security_label": by_field("security_label"),
        "by_research_family": by_field("research_family"),
        "by_research_technique": by_field("research_technique"),
    }


def evaluate_direct_route_fusions(
    validation_records: list[dict],
    validation_logits: np.ndarray,
    evaluation_records: list[dict],
    evaluation_logits: np.ndarray,
) -> dict:
    def route_arrays(records: list[dict], logits: np.ndarray):
        selected = []
        labels = []
        for index, record in enumerate(records):
            if record["channel"] != "direct_user":
                continue
            if record["security_label"] in {"benign", "harmful_non_injection"}:
                label = 0
            elif record["security_label"] in COMBINED_ROUTE_POSITIVE_LABELS:
                label = 1
            else:
                continue
            selected.append(index)
            labels.append(label)
        selected_array = np.asarray(selected)
        probabilities = 1.0 / (1.0 + np.exp(-logits[selected_array]))
        direct = probabilities[:, HEADS.index("direct_instruction_subversion")]
        jailbreak = probabilities[:, HEADS.index("jailbreak")]
        signals = {
            "direct_only": direct,
            "jailbreak_only": jailbreak,
            "maximum_probability": np.maximum(direct, jailbreak),
            "mean_logit": (
                logits[selected_array, HEADS.index("direct_instruction_subversion")]
                + logits[selected_array, HEADS.index("jailbreak")]
            )
            / 2,
        }
        return (
            [records[index] for index in selected],
            np.asarray(labels, dtype=np.int8),
            signals,
        )

    _, validation_labels, validation_signals = route_arrays(
        validation_records,
        validation_logits,
    )
    selected_records, labels, signals = route_arrays(
        evaluation_records,
        evaluation_logits,
    )
    result = {}
    for name, signal in signals.items():
        profiles = {}
        for profile_name, calibration in _threshold_profile(
            validation_labels,
            validation_signals[name],
        ).items():
            if calibration is None:
                profiles[profile_name] = None
                continue
            threshold = calibration["threshold"]
            slices = _metric_slices(
                selected_records,
                labels,
                signal,
                threshold=threshold,
            )
            profiles[profile_name] = {
                "threshold": threshold,
                "validation": calibration,
                "all": _binary_metrics(labels, signal, threshold=threshold),
                **slices,
            }
        result[name] = profiles
    return result


def _selection_score(evaluation: dict, relevant_heads: set[str]) -> float:
    values = [
        evaluation["heads"][head].get("source_macro_pr_auc")
        for head in relevant_heads
        if evaluation["heads"][head].get("source_macro_pr_auc") is not None
    ]
    return float(np.mean(values)) if values else -math.inf


def _head_state(head) -> dict:
    return {
        key: value.detach().contiguous().cpu()
        for key, value in head.state_dict().items()
    }


def _save_head(head, path: Path) -> None:
    from safetensors.torch import save_file

    path.parent.mkdir(parents=True, exist_ok=True)
    save_file(_head_state(head), path)


def _load_head(head, path: Path) -> None:
    from safetensors.torch import load_file

    head.load_state_dict(load_file(path))


def verify_head_roundtrip(head, features, path: Path) -> float:
    import torch

    head.eval()
    device = next(head.parameters()).device

    def predict():
        with (
            torch.no_grad(),
            torch.autocast(
                device_type=device.type,
                dtype=torch.bfloat16,
                enabled=device.type == "cuda",
            ),
        ):
            return head(features.to(device)).float().cpu()

    before = predict()
    _save_head(head, path)
    original = _head_state(head)
    for parameter in head.parameters():
        parameter.data.zero_()
    _load_head(head, path)
    after = predict()
    head.load_state_dict(original)
    return float((before - after).abs().max())


def _learning_rate_factor(step: int, total_steps: int) -> float:
    warmup = max(1, math.ceil(total_steps * 0.05))
    if step < warmup:
        return (step + 1) / warmup
    progress = (step - warmup) / max(total_steps - warmup, 1)
    return 0.5 * (1.0 + math.cos(math.pi * min(progress, 1.0)))


def _frozen_head_train(
    head,
    train_encoded: dict,
    validation_encoded: dict,
    boundary_validation_encoded: dict,
    *,
    relevant_heads: set[str],
    ranking_weight: float,
    seed: int,
    run_dir: Path,
) -> dict:
    import torch

    device = torch.device("cuda")
    head.to(device)
    examples = train_encoded["examples"]
    epoch_batches = [
        list(
            _example_batches(
                examples,
                token_budget=PADDED_TOKEN_BUDGET,
                seed=seed + epoch,
            )
        )
        for epoch in range(6)
    ]
    total_steps = sum(len(batches) for batches in epoch_batches)
    optimizer = torch.optim.AdamW(
        head.parameters(),
        lr=3e-4,
        weight_decay=0.01,
    )
    scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer,
        lambda step: _learning_rate_factor(step, total_steps),
    )
    curve = []
    best = None
    global_step = 0
    losses_since_checkpoint = []

    def checkpoint(epoch_value: float) -> None:
        nonlocal best
        validation_logits = _predict_head(head, validation_encoded)
        evaluation = evaluate_scores(
            validation_encoded["records"],
            validation_logits,
        )
        boundary_logits = _predict_head(head, boundary_validation_encoded)
        pair_metrics = _pair_metrics(
            boundary_validation_encoded["records"],
            1.0 / (1.0 + np.exp(-boundary_logits)),
        )
        primary = _selection_score(evaluation, relevant_heads)
        tie_breaker = pair_metrics["both_correct_rate"]
        tie_breaker = -math.inf if tie_breaker is None else tie_breaker
        checkpoint_path = run_dir / f"head_epoch_{epoch_value:g}.safetensors"
        _save_head(head, checkpoint_path)
        entry = {
            "epoch": epoch_value,
            "step": global_step,
            "mean_training_loss": (
                float(np.mean(losses_since_checkpoint))
                if losses_since_checkpoint
                else None
            ),
            "learning_rate": optimizer.param_groups[0]["lr"],
            "selection_source_macro_pr_auc": primary,
            "boundary_both_correct_rate": (
                None if tie_breaker == -math.inf else tie_breaker
            ),
            "validation": evaluation,
            "boundary_pairs": pair_metrics,
            "checkpoint": checkpoint_path.name,
        }
        curve.append(entry)
        candidate = (primary, tie_breaker, -epoch_value)
        if best is None or candidate > best["key"]:
            best = {
                "key": candidate,
                "path": checkpoint_path,
                "epoch": epoch_value,
            }
        losses_since_checkpoint.clear()

    for epoch, batches in enumerate(epoch_batches):
        halfway = math.ceil(len(batches) / 2)
        for batch_index, indices in enumerate(batches, start=1):
            head.train()
            feature_indices = [
                examples[index].get("feature_index", index) for index in indices
            ]
            features = train_encoded["features"][feature_indices].to(device)
            targets = torch.tensor(
                [examples[index]["targets"] for index in indices],
                device=device,
                dtype=torch.float32,
            )
            target_mask = torch.tensor(
                [examples[index]["target_mask"] for index in indices],
                device=device,
                dtype=torch.bool,
            )
            sample_weights = torch.tensor(
                [examples[index]["sample_weight"] for index in indices],
                device=device,
                dtype=torch.float32,
            )
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                logits = head(features)
                losses = []
                if target_mask.any():
                    losses.append(
                        masked_bce_loss(
                            logits,
                            targets,
                            target_mask,
                            sample_weights,
                        )
                    )
                bag_loss = document_bag_bce_loss(
                    logits,
                    [examples[index].get("bag_id") for index in indices],
                    [examples[index].get("bag_head") for index in indices],
                    [examples[index].get("bag_label") for index in indices],
                )
                if bag_loss is not None:
                    losses.append(bag_loss)
                if not losses:
                    raise ValueError("training batch has no supervised objective")
                loss = torch.stack(losses).mean()
                if ranking_weight:
                    pair_loss = aligned_pair_ranking_loss(
                        logits,
                        [examples[index]["pair_id"] for index in indices],
                        [examples[index]["pair_head"] for index in indices],
                        torch.tensor(
                            [
                                examples[index]["pair_label"]
                                if examples[index]["pair_label"] is not None
                                else -1
                                for index in indices
                            ],
                            device=device,
                        ),
                    )
                    loss = loss + ranking_weight * pair_loss
            if not torch.isfinite(loss):
                raise RuntimeError("non-finite training loss")
            loss.backward()
            optimizer.step()
            scheduler.step()
            global_step += 1
            losses_since_checkpoint.append(float(loss.detach().cpu()))
            if epoch == 0 and batch_index == halfway:
                checkpoint(0.5)
        checkpoint(float(epoch + 1))
    if best is None:
        raise RuntimeError("training produced no selectable checkpoint")
    _load_head(head, best["path"])
    return {
        "selected_epoch": best["epoch"],
        "selected_checkpoint": best["path"].name,
        "learning_curve": curve,
        "updates": global_step,
    }


def _control_logits(
    train_records: list[dict],
    validation_records: list[dict],
) -> dict:
    controls = {
        "word_1_2_gram": np.full(
            (len(validation_records), len(HEADS)), -math.inf, dtype=np.float32
        ),
        "source_only": np.full(
            (len(validation_records), len(HEADS)), -math.inf, dtype=np.float32
        ),
        "length_only": np.full(
            (len(validation_records), len(HEADS)), -math.inf, dtype=np.float32
        ),
    }
    word_vectorizer = HashingVectorizer(
        analyzer="word",
        ngram_range=(1, 2),
        n_features=2**20,
        alternate_sign=False,
        norm="l2",
        dtype=np.float32,
    )
    source_vectorizer = DictVectorizer(sparse=True)
    source_train = source_vectorizer.fit_transform(
        [{"source": record["source"]} for record in train_records]
    )
    source_validation = source_vectorizer.transform(
        [{"source": record["source"]} for record in validation_records]
    )
    length_train = np.asarray(
        [
            [math.log1p(len(record["text"])), math.log1p(len(record["text"].split()))]
            for record in train_records
        ]
    )
    length_validation = np.asarray(
        [
            [math.log1p(len(record["text"])), math.log1p(len(record["text"].split()))]
            for record in validation_records
        ]
    )
    length_mean = length_train.mean(axis=0)
    length_scale = length_train.std(axis=0)
    length_scale[length_scale == 0] = 1
    length_train = (length_train - length_mean) / length_scale
    length_validation = (length_validation - length_mean) / length_scale
    validation_text = [normalize_text(record["text"]) for record in validation_records]
    for head_index, head in enumerate(HEADS):
        train_indices = [
            index
            for index, record in enumerate(train_records)
            if record["targets"][head] is not None
        ]
        validation_indices = [
            index
            for index, record in enumerate(validation_records)
            if record["targets"][head] is not None
        ]
        labels = np.asarray(
            [train_records[index]["targets"][head] for index in train_indices]
        )
        if len(set(labels)) != 2 or not validation_indices:
            continue
        word = SGDClassifier(
            loss="log_loss",
            penalty="l2",
            alpha=1e-5,
            average=True,
            random_state=42,
        )
        word.fit(
            word_vectorizer.transform(
                [
                    normalize_text(train_records[index]["text"])
                    for index in train_indices
                ]
            ),
            labels,
        )
        controls["word_1_2_gram"][validation_indices, head_index] = word.predict_proba(
            word_vectorizer.transform(
                [validation_text[index] for index in validation_indices]
            )
        )[:, 1]
        source = LogisticRegression(max_iter=1_000, random_state=42)
        source.fit(source_train[train_indices], labels)
        controls["source_only"][validation_indices, head_index] = source.predict_proba(
            source_validation[validation_indices]
        )[:, 1]
        length = LogisticRegression(max_iter=1_000, random_state=42)
        length.fit(length_train[train_indices], labels)
        controls["length_only"][validation_indices, head_index] = length.predict_proba(
            length_validation[validation_indices]
        )[:, 1]
    return {
        name: np.log(
            np.clip(scores, 1e-7, 1 - 1e-7) / (1 - np.clip(scores, 1e-7, 1 - 1e-7))
        )
        for name, scores in controls.items()
    }


def _runtime_probe(attention_implementation: str, sequence_length: int) -> dict:
    import gc

    import torch
    from transformers import AutoTokenizer

    device = torch.device("cuda")
    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID,
        revision=MODEL_REVISION,
    )
    encoder, head = _model_components(
        attention_implementation=attention_implementation,
        seed=42,
    )
    encoder.to(device).eval()
    head.to(device).eval()
    text = "ordinary account statement line item and routine agent task "
    batch_size = PADDED_TOKEN_BUDGET // sequence_length
    inputs = tokenizer(
        [text * sequence_length] * batch_size,
        padding="max_length",
        truncation=True,
        max_length=sequence_length,
        return_tensors="pt",
    ).to(device)
    targets = torch.zeros((batch_size, len(HEADS)), device=device)
    target_mask = torch.ones_like(targets, dtype=torch.bool)
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(device)
    head.zero_grad(set_to_none=True)
    with torch.autocast("cuda", dtype=torch.bfloat16):
        hidden = encoder(**inputs).last_hidden_state
        logits = head(_pool_hidden(hidden, inputs["attention_mask"]))
        loss = masked_bce_loss(logits, targets, target_mask)
    loss.backward()
    gradient = torch.cat(
        [
            parameter.grad.detach().float().flatten().cpu()
            for parameter in head.parameters()
            if parameter.grad is not None
        ]
    )
    result = {
        "logits": logits.detach().float().cpu(),
        "gradient": gradient,
        "loss": float(loss.detach().cpu()),
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(device),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(device),
        "batch_size": batch_size,
    }
    del encoder, head, inputs, hidden, logits, loss, gradient
    gc.collect()
    torch.cuda.empty_cache()
    return result


def run_runtime_gate(output_path: Path) -> dict:
    import torch
    from huggingface_hub.constants import HF_HUB_CACHE

    if not torch.cuda.is_available():
        raise RuntimeError("runtime gate requires a CUDA GPU")
    raw = {}
    for implementation in ("sdpa", FLASH_IMPLEMENTATION):
        raw[implementation] = {
            length: _runtime_probe(implementation, length)
            for length in (DIRECT_MAX_TOKENS, UNTRUSTED_MAX_TOKENS)
        }
    comparisons = {}
    for length in (DIRECT_MAX_TOKENS, UNTRUSTED_MAX_TOKENS):
        sdpa = raw["sdpa"][length]
        flash = raw[FLASH_IMPLEMENTATION][length]
        denominator = sdpa["gradient"].norm() * flash["gradient"].norm()
        cosine = (
            torch.dot(sdpa["gradient"], flash["gradient"]) / denominator
            if denominator
            else torch.tensor(float("nan"))
        )
        comparisons[str(length)] = {
            "finite": bool(
                torch.isfinite(sdpa["logits"]).all()
                and torch.isfinite(flash["logits"]).all()
                and math.isfinite(sdpa["loss"])
                and math.isfinite(flash["loss"])
                and torch.isfinite(cosine)
            ),
            "predictions_match": bool(
                torch.equal(sdpa["logits"] >= 0, flash["logits"] >= 0)
            ),
            "max_bf16_logit_difference": float(
                (sdpa["logits"] - flash["logits"]).abs().max()
            ),
            "gradient_cosine": float(cosine),
            "losses": {
                "sdpa": sdpa["loss"],
                "flash_attention_2": flash["loss"],
            },
            "peak_reserved_bytes": {
                "sdpa": sdpa["peak_reserved_bytes"],
                "flash_attention_2": flash["peak_reserved_bytes"],
            },
            "batch_size": sdpa["batch_size"],
        }
    kernel_root = (
        Path(HF_HUB_CACHE)
        / "kernels--kernels-community--flash-attn2"
        / "snapshots"
        / FLASH_REVISION
    )
    binaries = sorted(kernel_root.rglob("*.so"))
    matching_binaries = [
        str(path.relative_to(kernel_root))
        for path in binaries
        if file_sha256(path) == FLASH_BINARY_SHA256
    ]
    result = {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "runtime": runtime_metadata(),
        "gpu": {
            "name": torch.cuda.get_device_name(0),
            "total_memory_bytes": torch.cuda.get_device_properties(0).total_memory,
            "bf16_supported": torch.cuda.is_bf16_supported(),
        },
        "kernel_binary_digest_verified": bool(matching_binaries),
        "kernel_binary_paths": matching_binaries,
        "comparisons": comparisons,
    }
    result["passed"] = result["kernel_binary_digest_verified"] and flash_gate_passes(
        result
    )
    _json_write(output_path, result)
    return result


def _records_summary(records: list[dict]) -> dict:
    counts = Counter()
    for record in records:
        counts[f"source:{record['source']}"] += 1
        counts[f"channel:{record['channel']}"] += 1
        for head, label in record["targets"].items():
            if label is not None:
                counts[f"head:{head}:{label}"] += 1
    return {
        "rows": len(records),
        "by_source": {
            key.removeprefix("source:"): value
            for key, value in sorted(counts.items())
            if key.startswith("source:")
        },
        "by_channel": {
            key.removeprefix("channel:"): value
            for key, value in sorted(counts.items())
            if key.startswith("channel:")
        },
        "by_head_label": {
            key.removeprefix("head:"): value
            for key, value in sorted(counts.items())
            if key.startswith("head:")
        },
    }


def _split_boundary_records(records: list[dict]) -> list[dict]:
    return [
        record for record in records if record["source"] == "agentic_boundary_pairs"
    ]


def _boundary_records(
    data_dir: Path,
    manifest: dict,
    source_split: str,
) -> list[dict]:
    output = manifest["source_outputs"]["agentic_boundary_pairs"]
    records = []
    data_role = "dev_test" if source_split == "test" else source_split
    for row in iter_verified_jsonl(
        manifest_output_path(data_dir, output),
        output["sha256"],
    ):
        if (
            row["source_split"] == source_split
            and row.get("source_pair_family") in BOUNDARY_INSTRUCTION_FAMILIES
        ):
            records.append(_record(row, data_role))
    return records


def _locked_evaluation_hashes(data_dir: Path, manifest: dict) -> set[str]:
    hashes = set()
    for split in ("validation", "dev_test"):
        output = manifest["routing_views"][split]
        for row in iter_verified_jsonl(
            manifest_output_path(data_dir, output),
            output["sha256"],
        ):
            hashes.add(row["normalized_text_sha256"])
    for source_split in ("validation", "test"):
        hashes.update(
            record["hash"]
            for record in _boundary_records(data_dir, manifest, source_split)
        )
    return hashes


def run_frozen_fold(
    data_dir: Path,
    run_dir: Path,
    *,
    fold_name: str,
    recipe_name: str,
    seed: int,
    attention_implementation: str,
    maximum_per_stratum: int | None,
    evaluate_dev_test: bool,
) -> dict:
    import gc

    import torch
    from transformers import AutoTokenizer

    if fold_name not in FOLDS or recipe_name not in RECIPES:
        raise ValueError("unknown fold or recipe")
    manifest_bytes = (data_dir / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    recipe = RECIPES[recipe_name]
    if maximum_per_stratum is not None:
        lineage_roles = _lineage_roles(data_dir, manifest)
        train_records, train_crossing = load_capped_fold_records(
            data_dir,
            manifest,
            "train",
            fold_name=fold_name,
            training=True,
            include_boundary=recipe["boundary"],
            maximum=maximum_per_stratum,
            lineage_roles=lineage_roles,
        )
        selection_records, selection_crossing = load_capped_fold_records(
            data_dir,
            manifest,
            "validation",
            fold_name=fold_name,
            training=True,
            include_boundary=False,
            maximum=maximum_per_stratum,
            lineage_roles=lineage_roles,
        )
        heldout_records, heldout_crossing = load_capped_fold_records(
            data_dir,
            manifest,
            "validation",
            fold_name=fold_name,
            training=False,
            include_boundary=False,
            maximum=maximum_per_stratum,
            lineage_roles=lineage_roles,
        )
        boundary_validation = _boundary_records(
            data_dir,
            manifest,
            "validation",
        )
    else:
        core_train = load_records(
            data_dir,
            manifest,
            "train",
            include_boundary=False,
        )
        augmented_train = (
            load_records(
                data_dir,
                manifest,
                "train",
                include_boundary=True,
            )
            if recipe["boundary"]
            else core_train
        )
        validation_all = load_records(
            data_dir,
            manifest,
            "validation",
            include_boundary=True,
        )
        core_validation = [
            record
            for record in validation_all
            if record["source"] != "agentic_boundary_pairs"
        ]
        boundary_validation = _split_boundary_records(validation_all)
        train_records, train_crossing = apply_fold(
            augmented_train,
            fold_name,
            training=True,
        )
        selection_records, selection_crossing = apply_fold(
            core_validation,
            fold_name,
            training=True,
        )
        heldout_records, heldout_crossing = apply_fold(
            core_validation,
            fold_name,
            training=False,
        )
    locked_hashes = _locked_evaluation_hashes(data_dir, manifest)
    leaked_training_rows = sum(
        record["hash"] in locked_hashes for record in train_records
    )
    train_records = [
        record for record in train_records if record["hash"] not in locked_hashes
    ]
    if not train_records or not selection_records or not heldout_records:
        raise ValueError(f"{fold_name} has an empty experiment partition")

    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID,
        revision=MODEL_REVISION,
    )
    encoder, head = _model_components(
        attention_implementation=attention_implementation,
        seed=seed,
    )
    train_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, train_records, training=True),
    )
    train_encoded, trainable_heads = _activate_trainable_heads(train_encoded)
    relevant_heads = FOLDS[fold_name]["heads"] & trainable_heads
    if not relevant_heads:
        raise ValueError(f"{fold_name} has no trainable relevant heads")
    selection_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, selection_records, training=False),
    )
    heldout_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, heldout_records, training=False),
    )
    boundary_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, boundary_validation, training=False),
    )
    peak_reserved = max(
        encoded["peak_reserved_bytes"]
        for encoded in (
            train_encoded,
            selection_encoded,
            heldout_encoded,
            boundary_encoded,
        )
    )
    budgets = sorted(
        {
            encoded["padded_token_budget"]
            for encoded in (
                train_encoded,
                selection_encoded,
                heldout_encoded,
                boundary_encoded,
            )
        }
    )
    del encoder
    gc.collect()
    torch.cuda.empty_cache()

    training = _frozen_head_train(
        head,
        train_encoded,
        selection_encoded,
        boundary_encoded,
        relevant_heads=relevant_heads,
        ranking_weight=recipe["ranking_weight"],
        seed=seed,
        run_dir=run_dir,
    )
    selection_logits = _predict_head(head, selection_encoded)
    selection_evaluation = evaluate_scores(
        selection_encoded["records"],
        selection_logits,
    )
    heldout_logits = _predict_head(head, heldout_encoded)
    heldout_evaluation = evaluate_scores(heldout_encoded["records"], heldout_logits)
    heldout_operating_points = evaluate_threshold_profiles(
        heldout_encoded["records"],
        heldout_logits,
        selection_evaluation,
    )
    combined_route_operating_points = evaluate_combined_route_profiles(
        heldout_encoded["records"],
        heldout_logits,
        selection_evaluation,
    )
    control_selection_logits = _control_logits(
        train_encoded["records"],
        selection_encoded["records"],
    )
    control_heldout_logits = _control_logits(
        train_encoded["records"],
        heldout_encoded["records"],
    )
    controls = {}
    for name in control_selection_logits:
        control_selection = evaluate_scores(
            selection_encoded["records"],
            control_selection_logits[name],
        )
        controls[name] = {
            "selection_validation": control_selection,
            "source_heldout_validation": evaluate_scores(
                heldout_encoded["records"],
                control_heldout_logits[name],
            ),
            "source_heldout_operating_points": evaluate_threshold_profiles(
                heldout_encoded["records"],
                control_heldout_logits[name],
                control_selection,
            ),
            "combined_route_operating_points": evaluate_combined_route_profiles(
                heldout_encoded["records"],
                control_heldout_logits[name],
                control_selection,
            ),
        }
    roundtrip_difference = verify_head_roundtrip(
        head,
        train_encoded["features"][:2],
        run_dir / "roundtrip_head.safetensors",
    )
    dev_test_result = None
    if evaluate_dev_test:
        dev_records = load_records(
            data_dir,
            manifest,
            "dev_test",
            include_boundary=False,
        )
        dev_records, dev_crossing = apply_fold(
            dev_records,
            fold_name,
            training=False,
        )
        dev_encoded = _extract_with_vram_budget(
            _model_components(
                attention_implementation=attention_implementation,
                seed=seed,
            )[0],
            tokenizer,
            _encode_records(tokenizer, dev_records, training=False),
        )
        dev_logits = _predict_head(head, dev_encoded)
        dev_test_result = {
            "cross_boundary_rows_excluded": dev_crossing,
            "selection": _records_summary(dev_records),
            "evaluation": evaluate_scores(dev_records, dev_logits),
            "operating_points": evaluate_threshold_profiles(
                dev_records,
                dev_logits,
                selection_evaluation,
            ),
            "combined_route_operating_points": evaluate_combined_route_profiles(
                dev_records,
                dev_logits,
                selection_evaluation,
            ),
        }
    result = {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "fold": fold_name,
        "recipe": recipe_name,
        "seed": seed,
        "runtime": runtime_metadata(),
        "attention_implementation": attention_implementation,
        "trainable_heads": sorted(trainable_heads),
        "relevant_trainable_heads": sorted(relevant_heads),
        "data_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "selected_rows_sha256": selected_rows_sha256(train_encoded["records"]),
        "selection": {
            "train": _records_summary(train_encoded["records"]),
            "checkpoint_validation": _records_summary(selection_encoded["records"]),
            "source_heldout_validation": _records_summary(heldout_encoded["records"]),
            "boundary_validation": _records_summary(boundary_validation),
            "maximum_per_source_security_label": maximum_per_stratum,
            "cross_fold_rows_excluded": {
                "train": train_crossing,
                "checkpoint_validation": selection_crossing,
                "source_heldout_validation": heldout_crossing,
            },
            "exact_locked_hashes_excluded_from_training": leaked_training_rows,
            "long_positive_documents_excluded_from_training": len(
                train_encoded["excluded_long_positive_ids"]
            ),
        },
        "training": training,
        "checkpoint_validation": selection_evaluation,
        "source_heldout_validation": heldout_evaluation,
        "source_heldout_operating_points": heldout_operating_points,
        "combined_route_operating_points": combined_route_operating_points,
        "controls": controls,
        "dev_test": dev_test_result,
        "gpu": {
            "peak_reserved_bytes": peak_reserved,
            "padded_token_budgets": budgets,
            "within_5_2_gib_limit": peak_reserved <= MAX_RESERVED_BYTES,
        },
        "artifact_roundtrip_max_logit_difference": roundtrip_difference,
        "advisory_only": True,
    }
    _json_write(run_dir / "result.json", result)
    return result


def score_historical_binary(
    data_dir: Path,
    artifact_dir: Path,
    *,
    attention_implementation: str,
) -> dict:
    import gc

    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    manifest = json.loads((data_dir / "manifest.json").read_bytes())
    records = _boundary_records(data_dir, manifest, "validation")
    tokenizer = AutoTokenizer.from_pretrained(artifact_dir)
    model = AutoModelForSequenceClassification.from_pretrained(
        artifact_dir,
        attn_implementation=attention_implementation,
        dtype=torch.bfloat16,
    ).to("cuda")
    model.eval()
    scores = []
    with torch.no_grad():
        for start in range(0, len(records), 16):
            inputs = tokenizer(
                [record["text"] for record in records[start : start + 16]],
                padding=True,
                truncation=True,
                max_length=DIRECT_MAX_TOKENS,
                return_tensors="pt",
            ).to("cuda")
            with torch.autocast("cuda", dtype=torch.bfloat16):
                logits = model(**inputs).logits
            if logits.shape[1] == 1:
                values = torch.sigmoid(logits[:, 0])
            else:
                values = torch.softmax(logits, dim=-1)[:, 1]
            scores.extend(values.float().cpu().tolist())
    by_slice = {}
    for slice_name, predicate in {
        "all": lambda record: True,
        "direct": lambda record: record["pair_family"] in BOUNDARY_DIRECT_FAMILIES,
        "indirect": lambda record: (
            record["pair_family"] not in BOUNDARY_DIRECT_FAMILIES
        ),
    }.items():
        pairs = defaultdict(dict)
        for record, score in zip(records, scores):
            if predicate(record):
                pairs[record["pair_id"]][record["pair_label"]] = score
        margins = [pair[1] - pair[0] for pair in pairs.values() if set(pair) == {0, 1}]
        both_correct = [
            pair[1] >= 0.5 and pair[0] < 0.5
            for pair in pairs.values()
            if set(pair) == {0, 1}
        ]
        by_slice[slice_name] = {
            "pairs": len(margins),
            "ordering_rate": (
                sum(margin > 0 for margin in margins) / len(margins)
                if margins
                else None
            ),
            "both_correct_rate": (
                sum(both_correct) / len(both_correct) if both_correct else None
            ),
            "mean_margin": float(np.mean(margins)) if margins else None,
        }
    experiment = json.loads((artifact_dir / "experiment.json").read_bytes())
    result = {
        "artifact": str(artifact_dir),
        "artifact_manifest_sha256": experiment.get("data_manifest_sha256"),
        "current_manifest_sha256": hashlib.sha256(
            (data_dir / "manifest.json").read_bytes()
        ).hexdigest(),
        "manifest_matches": experiment.get("data_manifest_sha256")
        == hashlib.sha256((data_dir / "manifest.json").read_bytes()).hexdigest(),
        "boundary_validation": by_slice,
        "historical_control_only": True,
    }
    del model
    gc.collect()
    torch.cuda.empty_cache()
    return result


def _subset_encoded(encoded: dict, keep_record) -> dict:
    flags = [keep_record(record) for record in encoded["records"]]
    kept_record_count = sum(flags)
    if flags != [True] * kept_record_count + [False] * (len(flags) - kept_record_count):
        raise ValueError("zero-copy encoded subset must be a record prefix")
    kept_example_count = sum(
        example["record_index"] < kept_record_count for example in encoded["examples"]
    )
    if any(
        example["record_index"] >= kept_record_count
        for example in encoded["examples"][:kept_example_count]
    ) or any(
        example["record_index"] < kept_record_count
        for example in encoded["examples"][kept_example_count:]
    ):
        raise ValueError("zero-copy encoded subset must be an example prefix")
    records = encoded["records"][:kept_record_count]
    kept_ids = {record["id"] for record in records}
    return {
        "records": records,
        "examples": encoded["examples"][:kept_example_count],
        "features": encoded["features"][:kept_example_count],
        "excluded_long_positive_ids": [
            row_id
            for row_id in encoded["excluded_long_positive_ids"]
            if row_id in kept_ids
        ],
        "document_bag_ids": [
            row_id
            for row_id in encoded.get("document_bag_ids", [])
            if row_id in kept_ids
        ],
        "peak_reserved_bytes": encoded["peak_reserved_bytes"],
        "padded_token_budget": encoded["padded_token_budget"],
    }


def _activate_trainable_heads(encoded: dict) -> tuple[dict, set[str]]:
    labels = {head: set() for head in HEADS}
    for example in encoded["examples"]:
        for head_index, head in enumerate(HEADS):
            if example["target_mask"][head_index]:
                labels[head].add(example["targets"][head_index])
        if example.get("bag_head") is not None:
            labels[HEADS[example["bag_head"]]].add(example["bag_label"])
    trainable_heads = {head for head, values in labels.items() if values == {0, 1}}
    kept_example_indices = []
    for index, example in enumerate(encoded["examples"]):
        if any(
            example["target_mask"][head_index] and head in trainable_heads
            for head_index, head in enumerate(HEADS)
        ) or (
            example.get("bag_head") is not None
            and HEADS[example["bag_head"]] in trainable_heads
        ):
            kept_example_indices.append(index)
    kept_record_indices = sorted(
        {encoded["examples"][index]["record_index"] for index in kept_example_indices}
    )
    record_mapping = {
        old_index: new_index for new_index, old_index in enumerate(kept_record_indices)
    }
    examples = []
    for index in kept_example_indices:
        example = dict(encoded["examples"][index])
        example["feature_index"] = index
        example["record_index"] = record_mapping[example["record_index"]]
        example["target_mask"] = [
            value and head in trainable_heads
            for head, value in zip(HEADS, example["target_mask"], strict=True)
        ]
        if (
            example["pair_head"] is not None
            and HEADS[example["pair_head"]] not in trainable_heads
        ):
            example["pair_head"] = None
            example["pair_id"] = None
            example["pair_label"] = None
        if (
            example.get("bag_head") is not None
            and HEADS[example["bag_head"]] not in trainable_heads
        ):
            example["bag_id"] = None
            example["bag_head"] = None
            example["bag_label"] = None
        examples.append(example)
    return (
        {
            "records": [encoded["records"][index] for index in kept_record_indices],
            "examples": examples,
            "features": encoded["features"],
            "excluded_long_positive_ids": encoded["excluded_long_positive_ids"],
            "document_bag_ids": encoded.get("document_bag_ids", []),
            "peak_reserved_bytes": encoded["peak_reserved_bytes"],
            "padded_token_budget": encoded["padded_token_budget"],
        },
        trainable_heads,
    )


def _quick_fold_records(
    data_dir: Path,
    manifest: dict,
    fold_name: str,
    lineage_roles: dict[str, str],
    locked_hashes: set[str],
) -> dict:
    core_train, train_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "train",
        fold_name=fold_name,
        training=True,
        include_boundary=False,
        maximum=2_000,
        lineage_roles=lineage_roles,
    )
    selection, selection_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "validation",
        fold_name=fold_name,
        training=True,
        include_boundary=False,
        maximum=2_000,
        lineage_roles=lineage_roles,
    )
    heldout, heldout_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "validation",
        fold_name=fold_name,
        training=False,
        include_boundary=False,
        maximum=2_000,
        lineage_roles=lineage_roles,
    )
    leaked = sum(record["hash"] in locked_hashes for record in core_train)
    core_train = [
        record for record in core_train if record["hash"] not in locked_hashes
    ]
    seen = {(record["hash"], tuple(record["targets"].items())) for record in core_train}
    boundary_train = []
    for record in _boundary_records(data_dir, manifest, "train"):
        key = (record["hash"], tuple(record["targets"].items()))
        if record["hash"] not in locked_hashes and key not in seen:
            boundary_train.append(record)
            seen.add(key)
    return {
        "core_train": core_train,
        "augmented_train": core_train
        + sorted(boundary_train, key=lambda record: record["hash"]),
        "selection": selection,
        "heldout": heldout,
        "boundary_validation": _boundary_records(
            data_dir,
            manifest,
            "validation",
        ),
        "crossing": {
            "train": train_crossing,
            "checkpoint_validation": selection_crossing,
            "source_heldout_validation": heldout_crossing,
        },
        "locked_hashes_excluded": leaked,
    }


def _quick_recipe_result(
    *,
    data_dir: Path,
    manifest_bytes: bytes,
    fold_name: str,
    recipe_name: str,
    attention_implementation: str,
    train_encoded: dict,
    selection_encoded: dict,
    heldout_encoded: dict,
    boundary_encoded: dict,
    selection_metadata: dict,
    trainable_heads: set[str],
    run_dir: Path,
) -> dict:
    recipe = RECIPES[recipe_name]
    relevant_heads = FOLDS[fold_name]["heads"] & trainable_heads
    if not relevant_heads:
        raise ValueError(f"{fold_name} has no trainable relevant heads")
    head = _new_head(train_encoded["features"].shape[1] // 3, 42)
    training = _frozen_head_train(
        head,
        train_encoded,
        selection_encoded,
        boundary_encoded,
        relevant_heads=relevant_heads,
        ranking_weight=recipe["ranking_weight"],
        seed=42,
        run_dir=run_dir,
    )
    selection_logits = _predict_head(head, selection_encoded)
    selection_evaluation = evaluate_scores(
        selection_encoded["records"],
        selection_logits,
    )
    heldout_logits = _predict_head(head, heldout_encoded)
    heldout_evaluation = evaluate_scores(
        heldout_encoded["records"],
        heldout_logits,
    )
    heldout_operating_points = evaluate_threshold_profiles(
        heldout_encoded["records"],
        heldout_logits,
        selection_evaluation,
    )
    combined_route_operating_points = evaluate_combined_route_profiles(
        heldout_encoded["records"],
        heldout_logits,
        selection_evaluation,
    )
    control_selection_logits = _control_logits(
        train_encoded["records"],
        selection_encoded["records"],
    )
    control_heldout_logits = _control_logits(
        train_encoded["records"],
        heldout_encoded["records"],
    )
    controls = {}
    for name in control_selection_logits:
        control_selection = evaluate_scores(
            selection_encoded["records"],
            control_selection_logits[name],
        )
        controls[name] = {
            "selection_validation": control_selection,
            "source_heldout_validation": evaluate_scores(
                heldout_encoded["records"],
                control_heldout_logits[name],
            ),
            "source_heldout_operating_points": evaluate_threshold_profiles(
                heldout_encoded["records"],
                control_heldout_logits[name],
                control_selection,
            ),
            "combined_route_operating_points": evaluate_combined_route_profiles(
                heldout_encoded["records"],
                control_heldout_logits[name],
                control_selection,
            ),
        }
    roundtrip_difference = verify_head_roundtrip(
        head,
        train_encoded["features"][:2],
        run_dir / "roundtrip_head.safetensors",
    )
    result = {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "fold": fold_name,
        "recipe": recipe_name,
        "seed": 42,
        "runtime": runtime_metadata(),
        "attention_implementation": attention_implementation,
        "trainable_heads": sorted(trainable_heads),
        "relevant_trainable_heads": sorted(relevant_heads),
        "data_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "selected_rows_sha256": selected_rows_sha256(train_encoded["records"]),
        "selection": {
            "train": _records_summary(train_encoded["records"]),
            "checkpoint_validation": _records_summary(selection_encoded["records"]),
            "source_heldout_validation": _records_summary(heldout_encoded["records"]),
            "boundary_validation": _records_summary(boundary_encoded["records"]),
            "maximum_per_source_security_label": 2_000,
            "cross_fold_rows_excluded": selection_metadata["crossing"],
            "exact_locked_hashes_excluded_from_training": (
                selection_metadata["locked_hashes_excluded"]
            ),
            "long_positive_documents_excluded_from_training": len(
                train_encoded["excluded_long_positive_ids"]
            ),
        },
        "training": training,
        "checkpoint_validation": selection_evaluation,
        "source_heldout_validation": heldout_evaluation,
        "source_heldout_operating_points": heldout_operating_points,
        "combined_route_operating_points": combined_route_operating_points,
        "controls": controls,
        "dev_test": None,
        "gpu": {
            "peak_reserved_bytes": train_encoded["peak_reserved_bytes"],
            "padded_token_budgets": [train_encoded["padded_token_budget"]],
            "within_5_2_gib_limit": (
                train_encoded["peak_reserved_bytes"] <= MAX_RESERVED_BYTES
            ),
        },
        "artifact_roundtrip_max_logit_difference": roundtrip_difference,
        "advisory_only": True,
    }
    _json_write(run_dir / "result.json", result)
    return result


def run_quick_fold(
    data_dir: Path,
    artifacts_dir: Path,
    *,
    fold_name: str,
    attention_implementation: str,
    manifest: dict,
    manifest_bytes: bytes,
    lineage_roles: dict[str, str],
    locked_hashes: set[str],
) -> dict[str, dict]:
    import gc

    import torch
    from transformers import AutoTokenizer

    selected = _quick_fold_records(
        data_dir,
        manifest,
        fold_name,
        lineage_roles,
        locked_hashes,
    )
    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID,
        revision=MODEL_REVISION,
    )
    encoder, _ = _model_components(
        attention_implementation=attention_implementation,
        seed=42,
    )
    augmented_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(
            tokenizer,
            selected["augmented_train"],
            training=True,
        ),
    )
    core_encoded = _subset_encoded(
        augmented_encoded,
        lambda record: record["source"] != "agentic_boundary_pairs",
    )
    selection_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, selected["selection"], training=False),
    )
    heldout_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, selected["heldout"], training=False),
    )
    boundary_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(
            tokenizer,
            selected["boundary_validation"],
            training=False,
        ),
    )
    del encoder
    gc.collect()
    torch.cuda.empty_cache()
    results = {}
    for recipe_name in RECIPES:
        encoded = core_encoded if recipe_name == "core_bce" else augmented_encoded
        train_encoded, trainable_heads = _activate_trainable_heads(encoded)
        run_dir = (
            artifacts_dir
            / "routing_encoder_runs"
            / "quick"
            / recipe_name
            / fold_name
            / "seed_42"
        )
        results[recipe_name] = _quick_recipe_result(
            data_dir=data_dir,
            manifest_bytes=manifest_bytes,
            fold_name=fold_name,
            recipe_name=recipe_name,
            attention_implementation=attention_implementation,
            train_encoded=train_encoded,
            selection_encoded=selection_encoded,
            heldout_encoded=heldout_encoded,
            boundary_encoded=boundary_encoded,
            selection_metadata=selected,
            trainable_heads=trainable_heads,
            run_dir=run_dir,
        )
    return results


def _mean_fold_metric(results: list[dict], control: str | None = None) -> float:
    values = []
    for result in results:
        evaluation = (
            result["source_heldout_validation"]
            if control is None
            else result["controls"][control]["source_heldout_validation"]
        )
        for head in FOLDS[result["fold"]]["heads"] & set(result["trainable_heads"]):
            value = evaluation["heads"][head].get("source_macro_pr_auc")
            if value is not None:
                values.append(value)
    return float(np.mean(values)) if values else -math.inf


def _mean_pair_both_correct(results: list[dict]) -> float:
    values = []
    for result in results:
        selected_epoch = result["training"]["selected_epoch"]
        entry = next(
            item
            for item in result["training"]["learning_curve"]
            if item["epoch"] == selected_epoch
        )
        value = entry["boundary_pairs"]["both_correct_rate"]
        if value is not None:
            values.append(value)
    return float(np.mean(values)) if values else -math.inf


def _mean_recall_at_one_percent(
    results: list[dict], control: str | None = None
) -> float:
    values = []
    for result in results:
        profiles = (
            result["source_heldout_operating_points"]
            if control is None
            else result["controls"][control]["source_heldout_operating_points"]
        )
        for head in FOLDS[result["fold"]]["heads"] & set(result["trainable_heads"]):
            profile = profiles[head].get("1.000%")
            if profile is not None and profile["all"]["recall"] is not None:
                values.append(profile["all"]["recall"])
    return float(np.mean(values)) if values else -math.inf


def _worst_source_fpr(results: list[dict]) -> float:
    values = [
        result["combined_route_operating_points"]["1.000%"]["worst_source_fpr"]
        for result in results
        if result["combined_route_operating_points"]["1.000%"]["worst_source_fpr"]
        is not None
    ]
    return max(values) if values else math.inf


def _finance_fpr(results: list[dict], control: str | None = None) -> float | None:
    result = next(
        (item for item in results if item["fold"] == "short_finance_agent"),
        None,
    )
    if result is None:
        return None
    profiles = (
        result["combined_route_operating_points"]
        if control is None
        else result["controls"][control]["combined_route_operating_points"]
    )
    finance = profiles["1.000%"]["finance"]
    return finance["fpr"] if finance is not None else None


def run_quick_suite(
    data_dir: Path,
    artifacts_dir: Path,
    reports_dir: Path,
    *,
    attention_implementation: str,
) -> dict:
    runtime_gate_path = artifacts_dir / "routing_encoder_runs" / "runtime_gate.json"
    runtime_gate = (
        json.loads(runtime_gate_path.read_bytes())
        if runtime_gate_path.is_file()
        else None
    )
    attention = {
        "implementation": attention_implementation,
        "runtime_gate_passed": (
            runtime_gate.get("passed") if runtime_gate is not None else None
        ),
        "runtime_gate_override": bool(
            attention_implementation == FLASH_IMPLEMENTATION
            and runtime_gate is not None
            and not runtime_gate.get("passed")
        ),
    }
    support = label_support_report(data_dir)
    if not support["all_heads_supported"]:
        result = {
            "schema_version": 1,
            "stopped": True,
            "stop_reasons": ["one or more heads failed the label-support gate"],
            "label_support": support,
            "attention": attention,
        }
        _json_write(reports_dir / "modernbert-multitask-quick.json", result)
        return result
    manifest_bytes = (data_dir / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    lineage_roles = _lineage_roles(data_dir, manifest)
    locked_hashes = _locked_evaluation_hashes(data_dir, manifest)
    results_by_recipe = {name: [] for name in RECIPES}
    for fold_name in QUICK_FOLDS:
        fold_results = run_quick_fold(
            data_dir,
            artifacts_dir,
            fold_name=fold_name,
            attention_implementation=attention_implementation,
            manifest=manifest,
            manifest_bytes=manifest_bytes,
            lineage_roles=lineage_roles,
            locked_hashes=locked_hashes,
        )
        for recipe_name, result in fold_results.items():
            results_by_recipe[recipe_name].append(result)
    recipe_metrics = {
        name: {
            "source_heldout_source_macro_pr_auc": _mean_fold_metric(results),
            "boundary_both_correct_rate": _mean_pair_both_correct(results),
            "word_source_macro_pr_auc": _mean_fold_metric(
                results,
                "word_1_2_gram",
            ),
            "source_only_source_macro_pr_auc": _mean_fold_metric(
                results,
                "source_only",
            ),
            "length_only_source_macro_pr_auc": _mean_fold_metric(
                results,
                "length_only",
            ),
        }
        for name, results in results_by_recipe.items()
    }
    bce = recipe_metrics["boundary_bce"]
    ranking = recipe_metrics["boundary_ranking"]
    ranking_wins = (
        ranking["boundary_both_correct_rate"] - bce["boundary_both_correct_rate"]
        >= 0.05
        and ranking["source_heldout_source_macro_pr_auc"]
        >= bce["source_heldout_source_macro_pr_auc"] - 0.01
    )
    eligible = ["core_bce", "boundary_bce"]
    if ranking_wins:
        eligible.append("boundary_ranking")
    winner = max(
        eligible,
        key=lambda name: (
            recipe_metrics[name]["source_heldout_source_macro_pr_auc"],
            recipe_metrics[name]["boundary_both_correct_rate"],
        ),
    )
    winning_results = results_by_recipe[winner]
    neural_pr = recipe_metrics[winner]["source_heldout_source_macro_pr_auc"]
    word_pr = recipe_metrics[winner]["word_source_macro_pr_auc"]
    neural_recall = _mean_recall_at_one_percent(winning_results)
    word_recall = _mean_recall_at_one_percent(
        winning_results,
        "word_1_2_gram",
    )
    finance_neural = _finance_fpr(winning_results)
    finance_word = _finance_fpr(winning_results, "word_1_2_gram")
    improvement_gate = neural_pr - word_pr >= 0.01 or (
        neural_recall - word_recall >= 0.05
    )
    finance_gate = (
        finance_neural is None or finance_word is None or finance_neural <= finance_word
    )
    worst_source_gate = _worst_source_fpr(winning_results) <= 0.10
    shortcut_reasons = []
    for control in ("source_only", "length_only"):
        control_pr = recipe_metrics[winner][f"{control}_source_macro_pr_auc"]
        if neural_pr - control_pr <= 0.01:
            shortcut_reasons.append(f"{control} is within 0.01 source-macro PR-AUC")
    stop_reasons = shortcut_reasons.copy()
    if not improvement_gate:
        stop_reasons.append("neural recipe did not beat the word control")
    if not finance_gate:
        stop_reasons.append("combined-route finance false positives worsened")
    if not worst_source_gate:
        stop_reasons.append("combined-route worst-source FPR exceeded 10%")
    historical_path = artifacts_dir / "modernbert_direct_source_supported_v1"
    historical = (
        score_historical_binary(
            data_dir,
            historical_path,
            attention_implementation=attention_implementation,
        )
        if historical_path.is_dir()
        else {"available": False}
    )
    result = {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "label_support": support,
        "attention": attention,
        "recipe_metrics": recipe_metrics,
        "pair_ranking_gate_passed": ranking_wins,
        "winning_recipe": winner,
        "promotion": {
            "passed": not stop_reasons,
            "neural_minus_word_source_macro_pr_auc": neural_pr - word_pr,
            "neural_minus_word_recall_at_one_percent_fpr": (
                neural_recall - word_recall
            ),
            "finance_neural_fpr": finance_neural,
            "finance_word_fpr": finance_word,
            "worst_combined_route_source_fpr": _worst_source_fpr(winning_results),
            "stop_reasons": stop_reasons,
        },
        "historical_binary_boundary_control": historical,
        "runs": {
            name: [
                str(
                    artifacts_dir
                    / "routing_encoder_runs"
                    / "quick"
                    / name
                    / fold
                    / "seed_42"
                    / "result.json"
                )
                for fold in QUICK_FOLDS
            ]
            for name in RECIPES
        },
    }
    reports_dir.mkdir(parents=True, exist_ok=True)
    _json_write(reports_dir / "modernbert-multitask-quick.json", result)
    return result


def _expected_review_metrics(metrics: dict, attack_prevalence: float) -> dict:
    recall = metrics["recall"]
    fpr = metrics["fpr"]
    if recall is None or fpr is None:
        return {
            "attack_prevalence": attack_prevalence,
            "review_rate": None,
            "precision": None,
        }
    true_positive_rate = attack_prevalence * recall
    false_positive_rate = (1.0 - attack_prevalence) * fpr
    review_rate = true_positive_rate + false_positive_rate
    return {
        "attack_prevalence": attack_prevalence,
        "review_rate": review_rate,
        "precision": true_positive_rate / review_rate if review_rate else None,
    }


def build_known_span_long_context_pairs(
    records: list[dict],
    *,
    locked_hashes: set[str],
) -> tuple[list[dict], dict]:
    clean_documents = sorted(
        (
            record
            for record in records
            if record["source"] == "browsesafe"
            and record["targets"]["indirect_instruction_subversion"] == 0
            and len(record["text"]) > LONG_CONTEXT_CHARACTERS
        ),
        key=lambda record: record["hash"],
    )
    payloads = sorted(
        (
            record
            for record in records
            if record["source"] == "agentic_boundary_pairs"
            and record["targets"]["indirect_instruction_subversion"] == 1
        ),
        key=lambda record: record["hash"],
    )
    required_documents = len(payloads) * len(LONG_CONTEXT_POSITIONS)
    if not payloads or len(clean_documents) < required_documents:
        raise ValueError(
            "known-span augmentation requires one distinct long clean document "
            "per payload and insertion position"
        )

    seen_hashes = {record["hash"] for record in records} | locked_hashes
    augmented = []
    counts = Counter()
    for payload_index, payload in enumerate(payloads):
        for position_index, position in enumerate(LONG_CONTEXT_POSITIONS):
            clean = clean_documents[
                payload_index * len(LONG_CONTEXT_POSITIONS) + position_index
            ]
            maximum_start = len(clean["text"]) - LONG_CONTEXT_CHARACTERS
            excerpt_start = int(clean["hash"][:16], 16) % (maximum_start + 1)
            context = clean["text"][
                excerpt_start : excerpt_start + LONG_CONTEXT_CHARACTERS
            ]
            insertion_at = {
                "prefix": 0,
                "middle": len(context) // 2,
                "suffix": len(context),
            }[position]
            prefix = context[:insertion_at] + "\n\n"
            suffix = "\n\n" + context[insertion_at:]
            attacked_text = prefix + payload["text"] + suffix
            payload_span = (len(prefix), len(prefix) + len(payload["text"]))
            pair_digest = hashlib.sha256(
                (
                    payload["hash"]
                    + clean["hash"]
                    + position
                    + str(LONG_CONTEXT_CHARACTERS)
                ).encode()
            ).hexdigest()
            pair_id = f"known-span-long:{pair_digest}"
            group = f"known-span-long-group:{pair_digest}"

            for label, text, span in (
                (0, context, None),
                (1, attacked_text, payload_span),
            ):
                normalized_hash = hashlib.sha256(
                    normalize_text(text).encode()
                ).hexdigest()
                if normalized_hash in seen_hashes:
                    raise ValueError(
                        "known-span augmentation produced an exact train or "
                        "evaluation collision"
                    )
                seen_hashes.add(normalized_hash)
                targets = dict.fromkeys(HEADS)
                targets["indirect_instruction_subversion"] = label
                augmented.append(
                    {
                        "id": f"{pair_id}:{label}",
                        "text": text,
                        "hash": normalized_hash,
                        "source": "known_span_long_context",
                        "sources": sorted(
                            set(clean["sources"]) | set(payload["sources"])
                        ),
                        "group": group,
                        "channel": "untrusted_content",
                        "security_label": (
                            "indirect_prompt_injection" if label else "benign"
                        ),
                        "targets": targets,
                        "data_role": "train",
                        "label_strength": "synthetic_recipe",
                        "finance": clean["finance"] or payload["finance"],
                        "known_payload_span": span is not None,
                        "payload_char_span": span,
                        "pair_id": pair_id,
                        "pair_family": "known_span_long_context",
                        "pair_head": HEADS.index("indirect_instruction_subversion"),
                        "pair_label": label,
                    }
                )
                counts[f"label:{label}"] += 1
            counts[f"position:{position}"] += 1
    return (
        sorted(augmented, key=lambda record: record["hash"]),
        {
            "pairs": len(augmented) // 2,
            "rows": len(augmented),
            "context_characters": LONG_CONTEXT_CHARACTERS,
            "positions": list(LONG_CONTEXT_POSITIONS),
            "counts": dict(sorted(counts.items())),
            "payload_source": "agentic_boundary_pairs",
            "clean_document_source": "browsesafe",
            "training_only": True,
        },
    )


def build_bipia_matched_context_pairs(
    rows: list[dict],
    *,
    lineage_roles: dict[str, str],
    locked_hashes: set[str],
    existing_records: list[dict],
) -> tuple[list[dict], dict]:
    payloads = sorted(
        (
            row
            for row in rows
            if row["source_split"] == "train_payload"
            and lineage_roles.get(row["split_group_id"]) == "train"
        ),
        key=lambda row: row["normalized_text_sha256"],
    )
    contexts = defaultdict(list)
    for row in rows:
        if (
            row["source_split"] != "train_clean_context"
            or lineage_roles.get(row["split_group_id"]) in {"validation", "dev_test"}
            or row["normalized_text_sha256"] in locked_hashes
        ):
            continue
        contexts[row["category"]].append(row)
    for values in contexts.values():
        values.sort(
            key=lambda row: (
                lineage_roles.get(row["split_group_id"]) is not None,
                row["normalized_text_sha256"],
            )
        )
    if not payloads or any(not contexts[task] for task in ("code", "email", "table")):
        raise ValueError(
            "BIPIA matched-context augmentation requires training payloads and "
            "code, email, and table contexts"
        )

    existing_hashes = {record["hash"] for record in existing_records}
    seen_attack_hashes = existing_hashes | locked_hashes
    context_positions = Counter()
    context_uses = Counter()
    all_context_hashes = set()
    augmented = []
    counts = Counter()
    for payload_index, payload in enumerate(payloads):
        kind = payload["category"].split("/", 1)[0]
        tasks = ("code",) if kind == "code" else ("email", "table")
        payload_context_hashes = set()
        for position_index, position in enumerate(BIPIA_MATCHED_POSITIONS):
            task = tasks[(payload_index + position_index) % len(tasks)]
            candidates = contexts[task]
            for _ in range(len(candidates)):
                context = candidates[context_positions[task] % len(candidates)]
                context_positions[task] += 1
                context_hash = context["normalized_text_sha256"]
                if (
                    context["split_group_id"] != payload["split_group_id"]
                    and context_hash not in payload_context_hashes
                ):
                    break
            else:
                raise ValueError(
                    f"BIPIA has too few distinct {task} contexts for "
                    f"{payload['source_id']}"
                )
            payload_context_hashes.add(context_hash)
            all_context_hashes.add(context_hash)
            context_uses[context["source_id"]] += 1

            insertion_at = {
                "prefix": 0,
                "middle": len(context["text"]) // 2,
                "suffix": len(context["text"]),
            }[position]
            prefix = context["text"][:insertion_at] + "\n\n"
            suffix = "\n\n" + context["text"][insertion_at:]
            attacked_text = prefix + payload["text"] + suffix
            attacked_hash = hashlib.sha256(
                normalize_text(attacked_text).encode()
            ).hexdigest()
            if attacked_hash in seen_attack_hashes:
                raise ValueError(
                    "BIPIA matched-context augmentation produced an exact "
                    "training or evaluation collision"
                )
            seen_attack_hashes.add(attacked_hash)
            payload_span = (len(prefix), len(prefix) + len(payload["text"]))
            attack_targets = dict.fromkeys(HEADS)
            attack_targets["indirect_instruction_subversion"] = 1
            clean_targets = dict.fromkeys(HEADS)
            clean_targets["indirect_instruction_subversion"] = 0
            pair_digest = hashlib.sha256(
                (payload["normalized_text_sha256"] + context_hash + position).encode()
            ).hexdigest()
            pair_id = f"bipia-matched-pair:{pair_digest}"
            augmented.extend(
                [
                    {
                        "id": f"bipia-matched-clean:{pair_digest}",
                        "text": context["text"],
                        "hash": context_hash,
                        "source": "bipia_matched_context",
                        "sources": ["bipia"],
                        "group": pair_id,
                        "channel": "untrusted_content",
                        "security_label": "benign",
                        "targets": clean_targets,
                        "data_role": "train",
                        "label_strength": "synthetic_recipe",
                        "finance": False,
                        "known_payload_span": False,
                        "payload_char_span": None,
                        "pair_id": pair_id,
                        "pair_family": "bipia_matched_context",
                        "pair_head": HEADS.index("indirect_instruction_subversion"),
                        "pair_label": 0,
                    },
                    {
                        "id": f"bipia-matched-attack:{pair_digest}",
                        "text": attacked_text,
                        "hash": attacked_hash,
                        "source": "bipia_matched_context",
                        "sources": ["bipia"],
                        "group": pair_id,
                        "channel": "untrusted_content",
                        "security_label": "indirect_prompt_injection",
                        "targets": attack_targets,
                        "data_role": "train",
                        "label_strength": "synthetic_recipe",
                        "finance": False,
                        "known_payload_span": True,
                        "payload_char_span": payload_span,
                        "pair_id": pair_id,
                        "pair_family": "bipia_matched_context",
                        "pair_head": HEADS.index("indirect_instruction_subversion"),
                        "pair_label": 1,
                    },
                ]
            )
            counts[f"position:{position}"] += 1
            counts[f"task:{task}"] += 1

    counts["label:1"] = len(payloads) * len(BIPIA_MATCHED_POSITIONS)
    counts["label:0"] = counts["label:1"]
    return (
        sorted(augmented, key=lambda record: (record["hash"], record["id"])),
        {
            "payloads": len(payloads),
            "attacked_rows": counts["label:1"],
            "paired_clean_rows": counts["label:0"],
            "unique_clean_contexts": len(all_context_hashes),
            "rows": len(augmented),
            "positions": list(BIPIA_MATCHED_POSITIONS),
            "counts": dict(sorted(counts.items())),
            "maximum_context_reuse": max(context_uses.values()),
            "unique_clean_contexts_already_in_training": len(
                all_context_hashes & existing_hashes
            ),
            "pair_balance": "one_clean_training_copy_per_attacked_row",
            "payload_source": "bipia",
            "clean_context_source": "bipia",
            "training_only": True,
        },
    )


def _multi_turn_research_role(goal_sha256: str) -> str:
    bucket = int(goal_sha256[:16], 16) % 10
    if bucket < 7:
        return "train"
    if bucket == 7:
        return "validation"
    return "dev_test"


def _multi_turn_repair_records(
    data_dir: Path,
    manifest: dict,
    *,
    maximum_training_rows_per_label: int,
) -> dict:
    output = manifest["source_outputs"]["multi_turn"]
    splits = {role: [] for role in ("train", "validation", "dev_test")}
    goals = {role: set() for role in splits}
    skipped = Counter()
    for row in iter_verified_jsonl(
        manifest_output_path(data_dir, output),
        output["sha256"],
    ):
        family = row.get("source_split")
        goal_sha256 = row.get("source_goal_sha256")
        if family not in {"harmful", "benign", "semi_benign"} or not goal_sha256:
            skipped[family or "unknown"] += 1
            continue
        role = _multi_turn_research_role(goal_sha256)
        record = _record(row, f"research_{role}")
        record["group"] = f"multi_turn:research:{goal_sha256}"
        record["research_family"] = family
        record["research_technique"] = row.get("category") or "none"
        splits[role].append(record)
        goals[role].add(goal_sha256)

    splits["train"] = cap_records(
        splits["train"],
        maximum_training_rows_per_label,
    )
    for left, right in (
        ("train", "validation"),
        ("train", "dev_test"),
        ("validation", "dev_test"),
    ):
        if goals[left] & goals[right]:
            raise ValueError(f"multi-turn goal leakage between {left} and {right}")
        left_hashes = {record["hash"] for record in splits[left]}
        right_hashes = {record["hash"] for record in splits[right]}
        if left_hashes & right_hashes:
            raise ValueError(f"multi-turn text leakage between {left} and {right}")

    return {
        **splits,
        "metadata": {
            "split_rule": "first_64_sha256_bits_modulo_10_as_70_10_20",
            "training_cap_per_source_security_label": (maximum_training_rows_per_label),
            "canonical_dev_test_rows_repurposed_for_research_training": len(
                splits["train"]
            ),
            "rows": {
                role: _records_summary(records) for role, records in splits.items()
            },
            "goals": {role: len(values) for role, values in goals.items()},
            "selected_rows_sha256": {
                role: selected_rows_sha256(records) for role, records in splits.items()
            },
            "skipped_rows": dict(sorted(skipped.items())),
            "same_benchmark_templates_across_splits": True,
            "prospective_final_test": False,
        },
    }


def _direct_non_subversion_record(
    row: dict,
    *,
    data_role: str,
    label_strength: str,
) -> dict:
    record = _record(row, data_role)
    record["targets"] = {
        **record["targets"],
        "direct_instruction_subversion": 0,
        "jailbreak": 0,
    }
    record["label_strength"] = label_strength
    record["research_family"] = row.get("source_split") or "unknown"
    record["research_technique"] = row.get("category") or "none"
    return record


def _assert_disjoint_research_roles(splits: dict[str, list[dict]], name: str) -> None:
    for left, right in (
        ("train", "validation"),
        ("train", "dev_test"),
        ("validation", "dev_test"),
    ):
        left_groups = {record["group"] for record in splits[left]}
        right_groups = {record["group"] for record in splits[right]}
        if left_groups & right_groups:
            raise ValueError(f"{name} group leakage between {left} and {right}")
        left_hashes = {record["hash"] for record in splits[left]}
        right_hashes = {record["hash"] for record in splits[right]}
        if left_hashes & right_hashes:
            raise ValueError(f"{name} text leakage between {left} and {right}")


def _quarantine_cross_role_exact_groups(
    splits: dict[str, list[dict]],
) -> dict:
    roles_by_hash = defaultdict(set)
    for role, records in splits.items():
        for record in records:
            roles_by_hash[record["hash"]].add(role)
    conflicting_hashes = {
        digest for digest, roles in roles_by_hash.items() if len(roles) > 1
    }
    conflicting_groups = {
        record["group"]
        for records in splits.values()
        for record in records
        if record["hash"] in conflicting_hashes
    }
    removed = {}
    for role, records in splits.items():
        retained = [
            record for record in records if record["group"] not in conflicting_groups
        ]
        removed[role] = len(records) - len(retained)
        splits[role] = retained
    return {
        "conflicting_exact_hashes": len(conflicting_hashes),
        "lineage_groups_removed": len(conflicting_groups),
        "rows_removed": removed,
    }


def _open_failure_repair_records(data_dir: Path, manifest: dict) -> dict:
    splits = {role: [] for role in ("train", "validation", "dev_test")}
    for source in ("do_not_answer", "harmbench", "notinject"):
        output = manifest["source_outputs"][source]
        for row in iter_verified_jsonl(
            manifest_output_path(data_dir, output),
            output["sha256"],
        ):
            role = _multi_turn_research_role(
                hashlib.sha256(row["split_group_id"].encode()).hexdigest()
            )
            splits[role].append(
                _direct_non_subversion_record(
                    row,
                    data_role=f"research_failure_{role}",
                    label_strength="supported_open_development",
                )
            )
    quarantine = _quarantine_cross_role_exact_groups(splits)
    _assert_disjoint_research_roles(splits, "open failure repair")
    return {
        **splits,
        "metadata": {
            "sources": ["do_not_answer", "harmbench", "notinject"],
            "split_rule": "split_group_sha256_first_64_bits_modulo_10_as_70_10_20",
            "rows": {
                role: _records_summary(records) for role, records in splits.items()
            },
            "selected_rows_sha256": {
                role: selected_rows_sha256(records) for role, records in splits.items()
            },
            "cross_role_exact_quarantine": quarantine,
            "canonical_dev_test_repurposed": True,
            "prospective_final_test": False,
        },
    }


def _wildguard_vanilla_repair_records(
    data_dir: Path,
    manifest: dict,
    *,
    maximum_training_rows_per_label: int,
    maximum_validation_rows_per_label: int,
    locked_hashes: set[str],
    existing_training_hashes: set[str],
) -> dict:
    output = manifest["source_outputs"]["wildguardmix"]
    splits = {role: [] for role in ("train", "validation", "dev_test")}
    excluded_locked = 0
    excluded_existing = 0
    for row in iter_verified_jsonl(
        manifest_output_path(data_dir, output),
        output["sha256"],
    ):
        if (
            row["source_role"] != "auxiliary"
            or row["source_split"] != "train"
            or row.get("source_adversarial") is not False
            or row["security_label"] not in {"benign", "harmful_non_injection"}
        ):
            continue
        if row["normalized_text_sha256"] in locked_hashes:
            excluded_locked += 1
            continue
        if row["normalized_text_sha256"] in existing_training_hashes:
            excluded_existing += 1
            continue
        role = _multi_turn_research_role(
            hashlib.sha256(row["split_group_id"].encode()).hexdigest()
        )
        splits[role].append(
            _direct_non_subversion_record(
                row,
                data_role=f"research_wildguard_{role}",
                label_strength="weak_source_model_harmfulness",
            )
        )
    splits["train"] = cap_records(
        splits["train"],
        maximum_training_rows_per_label,
    )
    splits["validation"] = cap_records(
        splits["validation"],
        maximum_validation_rows_per_label,
    )
    _assert_disjoint_research_roles(splits, "WildGuard vanilla repair")
    return {
        **splits,
        "metadata": {
            "selection": (
                "non-adversarial train prompts with weak benign or harmful labels"
            ),
            "training_cap_per_source_security_label": (maximum_training_rows_per_label),
            "validation_cap_per_source_security_label": (
                maximum_validation_rows_per_label
            ),
            "exact_locked_hashes_excluded": excluded_locked,
            "exact_existing_training_hashes_excluded": excluded_existing,
            "rows": {
                role: _records_summary(records) for role, records in splits.items()
            },
            "selected_rows_sha256": {
                role: selected_rows_sha256(records) for role, records in splits.items()
            },
            "weak_supervision": True,
        },
    }


def _consolidated_records(
    data_dir: Path,
    manifest: dict,
    *,
    maximum_per_stratum: int,
    bipia_matched_contexts: bool,
) -> dict:
    lineage_roles = _lineage_roles(data_dir, manifest)
    locked_hashes = _locked_evaluation_hashes(data_dir, manifest)
    train_records, train_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "train",
        fold_name=None,
        training=True,
        include_boundary=True,
        maximum=maximum_per_stratum,
        lineage_roles=lineage_roles,
    )
    validation_records, validation_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "validation",
        fold_name=None,
        training=True,
        include_boundary=False,
        maximum=maximum_per_stratum,
        lineage_roles=lineage_roles,
    )
    leaked = sum(record["hash"] in locked_hashes for record in train_records)
    train_records = [
        record for record in train_records if record["hash"] not in locked_hashes
    ]
    known_span_records, known_span_metadata = build_known_span_long_context_pairs(
        train_records,
        locked_hashes=locked_hashes,
    )
    train_records.extend(known_span_records)
    bipia_metadata = None
    if bipia_matched_contexts:
        bipia_output = manifest["source_outputs"]["bipia"]
        bipia_records, bipia_metadata = build_bipia_matched_context_pairs(
            list(
                iter_verified_jsonl(
                    manifest_output_path(data_dir, bipia_output),
                    bipia_output["sha256"],
                )
            ),
            lineage_roles=lineage_roles,
            locked_hashes=locked_hashes,
            existing_records=train_records,
        )
        train_records.extend(bipia_records)
    return {
        "train": sorted(train_records, key=lambda record: record["hash"]),
        "validation": validation_records,
        "boundary_validation": _boundary_records(
            data_dir,
            manifest,
            "validation",
        ),
        "crossing": {
            "train": train_crossing,
            "validation": validation_crossing,
        },
        "locked_hashes_excluded": leaked,
        "known_span_augmentation": known_span_metadata,
        "bipia_matched_context_augmentation": bipia_metadata,
    }


def _consolidated_thresholds(validation_evaluation: dict) -> dict:
    thresholds = {}
    for profile_name in ("0.100%", "0.500%", "1.000%"):
        profile = {}
        for head in HEADS:
            values = (
                validation_evaluation["heads"][head]
                .get("threshold_profiles", {})
                .get(profile_name)
            )
            if values is not None:
                profile[head] = values["threshold"]
        thresholds[profile_name] = profile
    return thresholds


def evaluate_long_untrusted_profiles(
    records: list[dict],
    logits: np.ndarray,
) -> dict:
    head = "indirect_instruction_subversion"
    head_index = HEADS.index(head)
    selected = np.asarray(
        [
            record["channel"] == "untrusted_content"
            and record.get("token_length", 0) > UNTRUSTED_MAX_TOKENS
            and record["targets"][head] is not None
            for record in records
        ]
    )
    if not selected.any():
        return {}
    selected_records = [
        record for record, keep in zip(records, selected, strict=True) if keep
    ]
    labels = np.asarray(
        [record["targets"][head] for record in selected_records],
        dtype=np.int8,
    )
    scores = 1.0 / (1.0 + np.exp(-logits[selected, head_index]))
    result = {}
    for profile_name, profile in _threshold_profile(labels, scores).items():
        if profile is None:
            result[profile_name] = None
            continue
        threshold = profile["threshold"]
        slices = _metric_slices(
            selected_records,
            labels,
            scores,
            threshold=threshold,
        )
        source_fprs = [
            metrics["fpr"]
            for metrics in slices["by_source"].values()
            if metrics["fpr"] is not None
        ]
        result[profile_name] = {
            "threshold": threshold,
            "all": _binary_metrics(labels, scores, threshold=threshold),
            **slices,
            "worst_source_fpr": max(source_fprs) if source_fprs else None,
        }
    return result


def evaluate_contextual_route(
    records: list[dict],
    logits: np.ndarray,
    *,
    validation_evaluation: dict,
    long_untrusted_profiles: dict,
) -> dict:
    scores = 1.0 / (1.0 + np.exp(-logits))
    standard_thresholds = _consolidated_thresholds(validation_evaluation)[
        CONSOLIDATED_DEFAULT_PROFILE
    ]
    long_threshold = long_untrusted_profiles[CONSOLIDATED_LONG_PROFILE]["threshold"]
    selected_records = []
    labels = []
    margins = []
    for record_index, record in enumerate(records):
        security_label = record["security_label"]
        if security_label in {"benign", "harmful_non_injection"}:
            label = 0
        elif security_label in COMBINED_ROUTE_POSITIVE_LABELS:
            label = 1
        else:
            continue
        if record["channel"] == "direct_user":
            applicable = COMBINED_ROUTE_HEADS["direct_user"]
            record_margins = [
                scores[record_index, HEADS.index(head)] - standard_thresholds[head]
                for head in applicable
            ]
        elif record.get("token_length", 0) > UNTRUSTED_MAX_TOKENS:
            record_margins = [
                scores[
                    record_index,
                    HEADS.index("indirect_instruction_subversion"),
                ]
                - long_threshold
            ]
        else:
            record_margins = [
                scores[
                    record_index,
                    HEADS.index("indirect_instruction_subversion"),
                ]
                - standard_thresholds["indirect_instruction_subversion"]
            ]
        selected_records.append(record)
        labels.append(label)
        margins.append(max(record_margins))

    labels_array = np.asarray(labels, dtype=np.int8)
    margins_array = np.asarray(margins, dtype=np.float64)
    slices = _metric_slices(
        selected_records,
        labels_array,
        margins_array,
        threshold=0.0,
    )
    source_fprs = [
        metrics["fpr"]
        for metrics in slices["by_source"].values()
        if metrics["fpr"] is not None
    ]
    finance_mask = np.asarray([record["finance"] for record in selected_records])
    return {
        "all": _binary_metrics(
            labels_array,
            margins_array,
            threshold=0.0,
        ),
        **slices,
        "finance": (
            _binary_metrics(
                labels_array[finance_mask],
                margins_array[finance_mask],
                threshold=0.0,
            )
            if finance_mask.any()
            else None
        ),
        "worst_source_fpr": max(source_fprs) if source_fprs else None,
        "thresholds": {
            "standard_profile": CONSOLIDATED_DEFAULT_PROFILE,
            "standard": standard_thresholds,
            "long_untrusted_profile": CONSOLIDATED_LONG_PROFILE,
            "long_untrusted_indirect": long_threshold,
        },
    }


def run_consolidated(
    data_dir: Path,
    artifacts_dir: Path,
    reports_dir: Path,
    *,
    attention_implementation: str,
    maximum_per_stratum: int = CONSOLIDATED_MAX_PER_STRATUM,
    untrusted_max_tokens: int = UNTRUSTED_MAX_TOKENS,
    untrusted_overlap: int = UNTRUSTED_OVERLAP,
    browsesafe_document_bags: bool = False,
    browsesafe_symmetric_document_bags: bool = False,
    bipia_matched_contexts: bool = False,
    model_id: str = MODEL_ID,
    model_revision: str = MODEL_REVISION,
) -> dict:
    import gc

    import torch
    from transformers import AutoTokenizer

    support = label_support_report(data_dir)
    unsupported = PRODUCT_ROUTE_HEADS - {
        head for head, values in support["heads"].items() if values["routing_active"]
    }
    if unsupported:
        raise ValueError(
            f"product route heads failed the label-support gate: {sorted(unsupported)}"
        )

    manifest_bytes = (data_dir / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    selected = _consolidated_records(
        data_dir,
        manifest,
        maximum_per_stratum=maximum_per_stratum,
        bipia_matched_contexts=bipia_matched_contexts,
    )
    if not selected["train"] or not selected["validation"]:
        raise ValueError(
            "consolidated experiment has an empty train or validation role"
        )

    tokenizer = AutoTokenizer.from_pretrained(
        model_id,
        revision=model_revision,
    )
    encoder, head = _model_components(
        attention_implementation=attention_implementation,
        seed=42,
        model_id=model_id,
        model_revision=model_revision,
    )
    train_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(
            tokenizer,
            selected["train"],
            training=True,
            untrusted_max_tokens=untrusted_max_tokens,
            untrusted_overlap=untrusted_overlap,
            document_bag_sources=(
                frozenset({"browsesafe"}) if browsesafe_document_bags else frozenset()
            ),
            document_bag_negatives=browsesafe_symmetric_document_bags,
        ),
    )
    train_encoded, trainable_heads = _activate_trainable_heads(train_encoded)
    missing_trainable = PRODUCT_ROUTE_HEADS - trainable_heads
    if missing_trainable:
        raise ValueError(
            f"consolidated training lacks both labels for: {sorted(missing_trainable)}"
        )
    validation_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(
            tokenizer,
            selected["validation"],
            training=False,
            untrusted_max_tokens=untrusted_max_tokens,
            untrusted_overlap=untrusted_overlap,
        ),
    )
    boundary_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(
            tokenizer,
            selected["boundary_validation"],
            training=False,
            untrusted_max_tokens=untrusted_max_tokens,
            untrusted_overlap=untrusted_overlap,
        ),
    )
    peak_reserved = max(
        encoded["peak_reserved_bytes"]
        for encoded in (train_encoded, validation_encoded, boundary_encoded)
    )
    padded_token_budgets = sorted(
        {
            encoded["padded_token_budget"]
            for encoded in (train_encoded, validation_encoded, boundary_encoded)
        }
    )
    del encoder
    gc.collect()
    torch.cuda.empty_cache()

    policy_suffix = (
        ""
        if (untrusted_max_tokens, untrusted_overlap)
        == (UNTRUSTED_MAX_TOKENS, UNTRUSTED_OVERLAP)
        else f"_{untrusted_max_tokens}_{untrusted_overlap}"
    )
    recipe_suffix = "_browsesafe_bags" if browsesafe_document_bags else ""
    if browsesafe_symmetric_document_bags:
        if not browsesafe_document_bags:
            raise ValueError("symmetric document bags require BrowseSafe bags")
        recipe_suffix += "_symmetric"
    if bipia_matched_contexts:
        recipe_suffix += "_bipia_pair_balanced"
    if model_id != MODEL_ID or model_revision != MODEL_REVISION:
        recipe_suffix += f"_{model_id.rsplit('/', 1)[-1].lower()}"
    run_dir = (
        artifacts_dir
        / "routing_encoder_runs"
        / f"consolidated_known_span{policy_suffix}{recipe_suffix}"
        / "seed_42"
    )
    training = _frozen_head_train(
        head,
        train_encoded,
        validation_encoded,
        boundary_encoded,
        relevant_heads=set(PRODUCT_ROUTE_HEADS),
        ranking_weight=0.0,
        seed=42,
        run_dir=run_dir,
    )
    validation_logits = _predict_head(head, validation_encoded)
    validation_evaluation = evaluate_scores(
        validation_encoded["records"],
        validation_logits,
    )
    operating_points = evaluate_threshold_profiles(
        validation_encoded["records"],
        validation_logits,
        validation_evaluation,
    )
    combined_route = evaluate_combined_route_profiles(
        validation_encoded["records"],
        validation_logits,
        validation_evaluation,
    )
    long_untrusted_profiles = evaluate_long_untrusted_profiles(
        validation_encoded["records"],
        validation_logits,
    )
    contextual_route = evaluate_contextual_route(
        validation_encoded["records"],
        validation_logits,
        validation_evaluation=validation_evaluation,
        long_untrusted_profiles=long_untrusted_profiles,
    )
    boundary_logits = _predict_head(head, boundary_encoded)
    boundary_metrics = _pair_metrics(
        boundary_encoded["records"],
        1.0 / (1.0 + np.exp(-boundary_logits)),
    )
    roundtrip_difference = verify_head_roundtrip(
        head,
        train_encoded["features"][:2],
        run_dir / "roundtrip_head.safetensors",
    )
    _save_head(head, run_dir / "head.safetensors")

    thresholds = _consolidated_thresholds(validation_evaluation)
    default_route = contextual_route
    finance = default_route["finance"]
    browsesafe = default_route["by_source"].get("browsesafe")
    long_untrusted = long_untrusted_profiles[CONSOLIDATED_LONG_PROFILE]
    gates = {
        "combined_recall_at_least_50_percent": (
            default_route["all"]["recall"] is not None
            and default_route["all"]["recall"] >= 0.50
        ),
        "finance_fpr_at_most_5_percent": (
            finance is not None
            and finance["fpr"] is not None
            and finance["fpr"] <= 0.05
        ),
        "browsesafe_fpr_at_most_10_percent": (
            browsesafe is not None
            and browsesafe["fpr"] is not None
            and browsesafe["fpr"] <= 0.10
        ),
        "browsesafe_recall_at_least_25_percent": (
            browsesafe is not None
            and browsesafe["recall"] is not None
            and browsesafe["recall"] >= 0.25
        ),
        "browsesafe_pr_auc_at_least_65_percent": (
            browsesafe is not None
            and browsesafe["pr_auc"] is not None
            and browsesafe["pr_auc"] >= 0.65
        ),
        "long_untrusted_recall_at_least_25_percent": (
            long_untrusted["all"]["recall"] is not None
            and long_untrusted["all"]["recall"] >= 0.25
        ),
        "worst_source_fpr_at_most_10_percent": (
            default_route["worst_source_fpr"] is not None
            and default_route["worst_source_fpr"] <= 0.10
        ),
        "boundary_both_correct_at_least_70_percent": (
            boundary_metrics["both_correct_rate"] is not None
            and boundary_metrics["both_correct_rate"] >= 0.70
        ),
    }
    manifest_sha256 = hashlib.sha256(manifest_bytes).hexdigest()
    bundle = {
        "schema_version": 1,
        "model_id": model_id,
        "model_revision": model_revision,
        "data_manifest_sha256": manifest_sha256,
        "runner_sha256": file_sha256(Path(__file__)),
        "heads": list(HEADS),
        "product_route_heads": {
            channel: list(heads) for channel, heads in COMBINED_ROUTE_HEADS.items()
        },
        "metadata_only_heads": ["harmful_intent"],
        "default_threshold_profile": CONSOLIDATED_DEFAULT_PROFILE,
        "threshold_profiles": thresholds,
        "long_untrusted_threshold_profile": CONSOLIDATED_LONG_PROFILE,
        "long_untrusted_threshold_profiles": {
            name: values["threshold"] if values is not None else None
            for name, values in long_untrusted_profiles.items()
        },
        "input_policy": {
            "direct_max_tokens": DIRECT_MAX_TOKENS,
            "untrusted_max_tokens": untrusted_max_tokens,
            "untrusted_overlap": untrusted_overlap,
            "document_aggregation": "maximum_window_score_per_head",
            "long_untrusted_threshold_is_separately_calibrated": True,
        },
        "architecture": {
            "pooling": ["masked_cls", "masked_mean", "masked_max"],
            "projection_width": 384,
            "activation": "gelu",
            "dropout": 0.1,
            "encoder_frozen": True,
            "training_objective": (
                "masked_bce_with_known_payload_span_window_localization"
                + (
                    (
                        "_and_browsesafe_symmetric_document_max_bce"
                        if browsesafe_symmetric_document_bags
                        else "_and_browsesafe_positive_document_max_bce"
                    )
                    if browsesafe_document_bags
                    else ""
                )
                + (
                    "_and_bipia_pair_balanced_matched_contexts"
                    if bipia_matched_contexts
                    else ""
                )
            ),
        },
        "evaluation_status": {
            "dev_test_opened": False,
            "shadow_candidate_gate_passed": all(gates.values()),
            "failed_checks": sorted(
                name for name, passed in gates.items() if not passed
            ),
        },
        "intended_use": {
            "direct_user": "research_shadow_candidate",
            f"untrusted_content_up_to_{untrusted_max_tokens}_tokens": (
                "research_shadow_candidate"
            ),
            f"untrusted_content_over_{untrusted_max_tokens}_tokens": (
                "external_long_document_companion_required"
            ),
            "authorization": "never",
        },
        "advisory_only": True,
        "decision": "allow",
    }
    _json_write(run_dir / "model_config.json", bundle)

    result = {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "runtime": runtime_metadata(model_id, model_revision),
        "attention_implementation": attention_implementation,
        "data_manifest_sha256": manifest_sha256,
        "selected_rows_sha256": selected_rows_sha256(train_encoded["records"]),
        "recipe": (
            "boundary_bce_consolidated_known_span"
            + ("_browsesafe_document_bags" if browsesafe_document_bags else "")
            + ("_symmetric" if browsesafe_symmetric_document_bags else "")
            + (
                "_bipia_pair_balanced_matched_contexts"
                if bipia_matched_contexts
                else ""
            )
        ),
        "seed": 42,
        "trainable_heads": sorted(trainable_heads),
        "product_route_heads": sorted(PRODUCT_ROUTE_HEADS),
        "metadata_only_heads": ["harmful_intent"],
        "selection": {
            "train": _records_summary(train_encoded["records"]),
            "validation": _records_summary(validation_encoded["records"]),
            "boundary_validation": _records_summary(boundary_encoded["records"]),
            "maximum_per_source_security_label": maximum_per_stratum,
            "cross_fold_rows_excluded": selected["crossing"],
            "exact_locked_hashes_excluded_from_training": (
                selected["locked_hashes_excluded"]
            ),
            "long_positive_documents_excluded_from_training": len(
                train_encoded["excluded_long_positive_ids"]
            ),
            "browsesafe_document_bags": len(train_encoded["document_bag_ids"]),
            "browsesafe_symmetric_document_bags": (browsesafe_symmetric_document_bags),
            "known_span_augmentation": selected["known_span_augmentation"],
            "bipia_matched_context_augmentation": selected[
                "bipia_matched_context_augmentation"
            ],
        },
        "training": training,
        "validation": validation_evaluation,
        "validation_operating_points": operating_points,
        "combined_route_operating_points": combined_route,
        "long_untrusted_operating_points": long_untrusted_profiles,
        "contextual_default_route": contextual_route,
        "boundary_pairs": boundary_metrics,
        "default_profile": CONSOLIDATED_DEFAULT_PROFILE,
        "realistic_prevalence": {
            "1_percent_attack_prevalence": _expected_review_metrics(
                default_route["all"],
                0.01,
            ),
            "0_1_percent_attack_prevalence": _expected_review_metrics(
                default_route["all"],
                0.001,
            ),
        },
        "shadow_candidate_gate": {
            "passed": all(gates.values()),
            "checks": gates,
            "not_a_blocking_approval": True,
        },
        "gpu": {
            "peak_reserved_bytes": peak_reserved,
            "padded_token_budgets": padded_token_budgets,
            "within_5_2_gib_limit": peak_reserved <= MAX_RESERVED_BYTES,
        },
        "artifact": {
            "head": str(run_dir / "head.safetensors"),
            "config": str(run_dir / "model_config.json"),
            "validation_scores": str(run_dir / "validation_scores.json"),
            "roundtrip_max_logit_difference": roundtrip_difference,
        },
        "dev_test": None,
        "advisory_only": True,
    }
    validation_scores = 1.0 / (1.0 + np.exp(-validation_logits))
    _json_write(
        run_dir / "validation_scores.json",
        {
            "schema_version": 1,
            "data_manifest_sha256": manifest_sha256,
            "selected_rows_sha256": selected_rows_sha256(validation_encoded["records"]),
            "heads": list(HEADS),
            "values": {
                f"{record['hash']}:{record['channel']}": {
                    "scores": {
                        head_name: float(validation_scores[index, head_index])
                        for head_index, head_name in enumerate(HEADS)
                    },
                    "source": record["source"],
                    "security_label": record["security_label"],
                    "token_length": record["token_length"],
                    "window_count": record["window_count"],
                }
                for index, record in enumerate(validation_encoded["records"])
            },
            "contains_raw_text": False,
        },
    )
    _json_write(run_dir / "result.json", result)
    reports_dir.mkdir(parents=True, exist_ok=True)
    _json_write(
        reports_dir
        / (f"modernbert-multitask-consolidated{policy_suffix}{recipe_suffix}.json"),
        result,
    )
    return result


def run_multi_turn_repair(
    data_dir: Path,
    artifacts_dir: Path,
    reports_dir: Path,
    *,
    attention_implementation: str,
    maximum_per_stratum: int = CONSOLIDATED_MAX_PER_STRATUM,
    reference_artifact_dir: Path | None = None,
) -> dict:
    import gc

    import torch
    from transformers import AutoTokenizer

    manifest_bytes = (data_dir / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    lineage_roles = _lineage_roles(data_dir, manifest)
    locked_hashes = _locked_evaluation_hashes(data_dir, manifest)
    base_train, train_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "train",
        fold_name=None,
        training=True,
        include_boundary=True,
        maximum=maximum_per_stratum,
        lineage_roles=lineage_roles,
    )
    base_validation, validation_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "validation",
        fold_name=None,
        training=True,
        include_boundary=False,
        maximum=maximum_per_stratum,
        lineage_roles=lineage_roles,
    )
    direct_suite, dev_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "dev_test",
        fold_name=None,
        training=False,
        include_boundary=False,
        maximum=maximum_per_stratum,
        lineage_roles=lineage_roles,
    )
    base_train = [
        record
        for record in base_train
        if record["channel"] == "direct_user" and record["hash"] not in locked_hashes
    ]
    base_validation = [
        record for record in base_validation if record["channel"] == "direct_user"
    ]
    direct_suite = [
        record
        for record in direct_suite
        if record["channel"] == "direct_user" and "multi_turn" not in record["sources"]
    ]
    boundary_validation = [
        record
        for record in _boundary_records(data_dir, manifest, "validation")
        if record["channel"] == "direct_user"
    ]
    multi_turn = _multi_turn_repair_records(
        data_dir,
        manifest,
        maximum_training_rows_per_label=maximum_per_stratum,
    )

    experimental_training_hashes = {record["hash"] for record in multi_turn["train"]}
    protected_hashes = {
        record["hash"]
        for records in (
            base_validation,
            direct_suite,
            multi_turn["validation"],
            multi_turn["dev_test"],
        )
        for record in records
    }
    if experimental_training_hashes & protected_hashes:
        raise ValueError("multi-turn repair training overlaps an evaluation role")

    train_records = [*base_train, *multi_turn["train"]]
    validation_records = [*base_validation, *multi_turn["validation"]]
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REVISION)
    encoder, unused_head = _model_components(
        attention_implementation=attention_implementation,
        seed=42,
    )
    train_all_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, train_records, training=True),
    )
    train_control_encoded = _subset_encoded(
        train_all_encoded,
        lambda record: record["data_role"] != "research_train",
    )
    train_control_encoded, control_heads = _activate_trainable_heads(
        train_control_encoded
    )
    train_repair_encoded, repair_heads = _activate_trainable_heads(train_all_encoded)
    relevant_heads = set(COMBINED_ROUTE_HEADS["direct_user"])
    for name, heads in (("control", control_heads), ("repair", repair_heads)):
        missing = relevant_heads - heads
        if missing:
            raise ValueError(f"{name} training lacks both labels for {sorted(missing)}")

    validation_all_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, validation_records, training=False),
    )
    validation_control_encoded = _subset_encoded(
        validation_all_encoded,
        lambda record: record["data_role"] != "research_validation",
    )
    direct_suite_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, direct_suite, training=False),
    )
    multi_turn_holdout_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, multi_turn["dev_test"], training=False),
    )
    boundary_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, boundary_validation, training=False),
    )
    peak_reserved = max(
        encoded["peak_reserved_bytes"]
        for encoded in (
            train_all_encoded,
            validation_all_encoded,
            direct_suite_encoded,
            multi_turn_holdout_encoded,
            boundary_encoded,
        )
    )
    hidden_size = encoder.config.hidden_size
    del encoder, unused_head
    gc.collect()
    torch.cuda.empty_cache()

    candidates = {}
    for architecture, independent_projections in (
        ("shared_projection", False),
        ("independent_projections", True),
    ):
        for recipe, repaired in (
            ("direct_control", False),
            ("multi_turn_style_repair", True),
        ):
            name = f"{architecture}_{recipe}"
            run_dir = artifacts_dir / "multi_turn_repair" / name / "seed_42"
            head = _new_head(
                hidden_size,
                seed=42,
                independent_projections=independent_projections,
            )
            train_encoded = train_repair_encoded if repaired else train_control_encoded
            validation_encoded = (
                validation_all_encoded if repaired else validation_control_encoded
            )
            training = _frozen_head_train(
                head,
                train_encoded,
                validation_encoded,
                boundary_encoded,
                relevant_heads=relevant_heads,
                ranking_weight=0.0,
                seed=42,
                run_dir=run_dir,
            )
            validation_logits = _predict_head(head, validation_encoded)
            validation_evaluation = evaluate_scores(
                validation_encoded["records"],
                validation_logits,
            )
            direct_logits = _predict_head(head, direct_suite_encoded)
            holdout_logits = _predict_head(head, multi_turn_holdout_encoded)
            boundary_logits = _predict_head(head, boundary_encoded)
            roundtrip_difference = verify_head_roundtrip(
                head,
                train_encoded["features"][:2],
                run_dir / "roundtrip_head.safetensors",
            )
            _save_head(head, run_dir / "head.safetensors")
            candidate = {
                "architecture": architecture,
                "recipe": recipe,
                "parameter_count": sum(
                    parameter.numel() for parameter in head.parameters()
                ),
                "trainable_heads": sorted(repair_heads if repaired else control_heads),
                "training": training,
                "validation": validation_evaluation,
                "direct_suite_operating_points": evaluate_combined_route_profiles(
                    direct_suite_encoded["records"],
                    direct_logits,
                    validation_evaluation,
                ),
                "direct_suite_default": evaluate_direct_research_slices(
                    direct_suite_encoded["records"],
                    direct_logits,
                    validation_evaluation,
                ),
                "multi_turn_holdout_operating_points": (
                    evaluate_combined_route_profiles(
                        multi_turn_holdout_encoded["records"],
                        holdout_logits,
                        validation_evaluation,
                    )
                ),
                "multi_turn_holdout_default": evaluate_direct_research_slices(
                    multi_turn_holdout_encoded["records"],
                    holdout_logits,
                    validation_evaluation,
                ),
                "boundary_pairs": _pair_metrics(
                    boundary_encoded["records"],
                    1.0 / (1.0 + np.exp(-boundary_logits)),
                ),
                "artifact": {
                    "head": str(run_dir / "head.safetensors"),
                    "head_sha256": file_sha256(run_dir / "head.safetensors"),
                    "roundtrip_max_logit_difference": roundtrip_difference,
                },
                "advisory_only": True,
            }
            _json_write(run_dir / "result.json", candidate)
            candidates[name] = candidate
            del head
            gc.collect()
            torch.cuda.empty_cache()

    reference = None
    if reference_artifact_dir is not None:
        reference_config = json.loads(
            (reference_artifact_dir / "model_config.json").read_bytes()
        )
        reference_result = json.loads(
            (reference_artifact_dir / "result.json").read_bytes()
        )
        if (
            reference_config["model_id"] != MODEL_ID
            or reference_config["model_revision"] != MODEL_REVISION
        ):
            raise ValueError("reference artifact uses a different encoder")
        reference_head = _new_head(hidden_size, seed=42)
        _load_head(reference_head, reference_artifact_dir / "head.safetensors")
        reference_head.to("cuda")
        direct_logits = _predict_head(reference_head, direct_suite_encoded)
        holdout_logits = _predict_head(reference_head, multi_turn_holdout_encoded)
        boundary_logits = _predict_head(reference_head, boundary_encoded)
        reference = {
            "artifact": {
                "directory": str(reference_artifact_dir),
                "head_sha256": file_sha256(reference_artifact_dir / "head.safetensors"),
            },
            "direct_suite_default": evaluate_direct_research_slices(
                direct_suite_encoded["records"],
                direct_logits,
                reference_result["validation"],
            ),
            "multi_turn_holdout_default": evaluate_direct_research_slices(
                multi_turn_holdout_encoded["records"],
                holdout_logits,
                reference_result["validation"],
            ),
            "boundary_pairs": _pair_metrics(
                boundary_encoded["records"],
                1.0 / (1.0 + np.exp(-boundary_logits)),
            ),
        }
        del reference_head
        gc.collect()
        torch.cuda.empty_cache()

    result = {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "runtime": runtime_metadata(),
        "attention_implementation": attention_implementation,
        "data_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "experiment": (
            "factorial shared versus independent projections and "
            "multi-turn style-matched data repair"
        ),
        "selection": {
            "base_train": _records_summary(base_train),
            "base_validation": _records_summary(base_validation),
            "direct_suite_without_multi_turn": _records_summary(direct_suite),
            "boundary_validation": _records_summary(boundary_validation),
            "multi_turn": multi_turn["metadata"],
            "maximum_per_source_security_label": maximum_per_stratum,
            "cross_fold_rows_excluded": {
                "train": train_crossing,
                "validation": validation_crossing,
                "dev_test": dev_crossing,
            },
        },
        "input_policy": {"direct_max_tokens": DIRECT_MAX_TOKENS},
        "candidates": candidates,
        "reference": reference,
        "gpu": {
            "peak_reserved_bytes": peak_reserved,
            "within_5_2_gib_limit": peak_reserved <= MAX_RESERVED_BYTES,
        },
        "limitations": [
            "The source is already-open development data, not a prospective final test.",
            "Goal hashes are held out, but benchmark templates and techniques repeat across roles.",
            "The experiment changes only the frozen classification head and its training data.",
        ],
        "advisory_only": True,
    }
    output = reports_dir / "modernbert-multi-turn-repair.json"
    _json_write(output, result)
    return result


def run_direct_failure_repair(
    data_dir: Path,
    artifacts_dir: Path,
    reports_dir: Path,
    *,
    attention_implementation: str,
    maximum_per_stratum: int = CONSOLIDATED_MAX_PER_STRATUM,
    model_id: str = MODEL_ID,
    model_revision: str = MODEL_REVISION,
) -> dict:
    import gc

    import torch
    from transformers import AutoTokenizer

    manifest_bytes = (data_dir / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    lineage_roles = _lineage_roles(data_dir, manifest)
    locked_hashes = _locked_evaluation_hashes(data_dir, manifest)
    base_train, train_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "train",
        fold_name=None,
        training=True,
        include_boundary=True,
        maximum=maximum_per_stratum,
        lineage_roles=lineage_roles,
    )
    base_validation, validation_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "validation",
        fold_name=None,
        training=True,
        include_boundary=False,
        maximum=maximum_per_stratum,
        lineage_roles=lineage_roles,
    )
    direct_suite, dev_crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "dev_test",
        fold_name=None,
        training=False,
        include_boundary=False,
        maximum=maximum_per_stratum,
        lineage_roles=lineage_roles,
    )
    base_train = [
        record
        for record in base_train
        if record["channel"] == "direct_user" and record["hash"] not in locked_hashes
    ]
    base_validation = [
        record for record in base_validation if record["channel"] == "direct_user"
    ]
    direct_suite = [
        record
        for record in direct_suite
        if record["channel"] == "direct_user" and "multi_turn" not in record["sources"]
    ]
    repaired_sources = {"do_not_answer", "harmbench", "notinject"}
    unaffected_suite = [
        record
        for record in direct_suite
        if not (set(record["sources"]) & repaired_sources)
    ]
    boundary_validation = [
        record
        for record in _boundary_records(data_dir, manifest, "validation")
        if record["channel"] == "direct_user"
    ]
    multi_turn = _multi_turn_repair_records(
        data_dir,
        manifest,
        maximum_training_rows_per_label=maximum_per_stratum,
    )
    wildguard = _wildguard_vanilla_repair_records(
        data_dir,
        manifest,
        maximum_training_rows_per_label=maximum_per_stratum,
        maximum_validation_rows_per_label=max(1, maximum_per_stratum // 4),
        locked_hashes=locked_hashes,
        existing_training_hashes={record["hash"] for record in base_train},
    )
    failure_repair = _open_failure_repair_records(data_dir, manifest)

    weak_train_records = [
        *base_train,
        *multi_turn["train"],
        *wildguard["train"],
    ]
    upper_train_records = [*weak_train_records, *failure_repair["train"]]
    weak_validation_records = [
        *base_validation,
        *multi_turn["validation"],
        *wildguard["validation"],
    ]
    upper_validation_records = [
        *weak_validation_records,
        *failure_repair["validation"],
    ]
    weak_training_hashes = {record["hash"] for record in weak_train_records}
    weak_evaluation_hashes = {
        record["hash"]
        for records in (
            weak_validation_records,
            direct_suite,
            multi_turn["dev_test"],
        )
        for record in records
    }
    if weak_training_hashes & weak_evaluation_hashes:
        raise ValueError("weak repair training overlaps an evaluation role")
    upper_training_hashes = {record["hash"] for record in upper_train_records}
    upper_evaluation_hashes = {
        record["hash"]
        for records in (
            upper_validation_records,
            unaffected_suite,
            failure_repair["dev_test"],
            multi_turn["dev_test"],
        )
        for record in records
    }
    if upper_training_hashes & upper_evaluation_hashes:
        raise ValueError("upper-bound repair training overlaps an evaluation role")

    tokenizer = AutoTokenizer.from_pretrained(
        model_id,
        revision=model_revision,
    )
    encoder, unused_head = _model_components(
        attention_implementation=attention_implementation,
        seed=42,
        model_id=model_id,
        model_revision=model_revision,
    )
    train_all_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, upper_train_records, training=True),
    )
    train_weak_encoded = _subset_encoded(
        train_all_encoded,
        lambda record: record["data_role"] != "research_failure_train",
    )
    train_weak_encoded, weak_heads = _activate_trainable_heads(train_weak_encoded)
    train_upper_encoded, upper_heads = _activate_trainable_heads(train_all_encoded)
    relevant_heads = set(COMBINED_ROUTE_HEADS["direct_user"])
    for name, heads in (("weak", weak_heads), ("upper", upper_heads)):
        missing = relevant_heads - heads
        if missing:
            raise ValueError(f"{name} training lacks both labels for {sorted(missing)}")

    validation_all_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, upper_validation_records, training=False),
    )
    validation_weak_encoded = _subset_encoded(
        validation_all_encoded,
        lambda record: record["data_role"] != "research_failure_validation",
    )
    direct_suite_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, direct_suite, training=False),
    )
    unaffected_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, unaffected_suite, training=False),
    )
    failure_holdout_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, failure_repair["dev_test"], training=False),
    )
    multi_turn_holdout_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, multi_turn["dev_test"], training=False),
    )
    boundary_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(tokenizer, boundary_validation, training=False),
    )
    peak_reserved = max(
        encoded["peak_reserved_bytes"]
        for encoded in (
            train_all_encoded,
            validation_all_encoded,
            direct_suite_encoded,
            unaffected_encoded,
            failure_holdout_encoded,
            multi_turn_holdout_encoded,
            boundary_encoded,
        )
    )
    hidden_size = encoder.config.hidden_size
    del encoder, unused_head
    gc.collect()
    torch.cuda.empty_cache()

    def evaluation_bundle(
        head,
        validation_encoded: dict,
        evaluation_encoded: dict,
    ) -> dict:
        validation_logits = _predict_head(head, validation_encoded)
        validation_evaluation = evaluate_scores(
            validation_encoded["records"],
            validation_logits,
        )
        evaluation_logits = _predict_head(head, evaluation_encoded)
        return {
            "per_head_or": evaluate_direct_research_slices(
                evaluation_encoded["records"],
                evaluation_logits,
                validation_evaluation,
            ),
            "route_fusions": evaluate_direct_route_fusions(
                validation_encoded["records"],
                validation_logits,
                evaluation_encoded["records"],
                evaluation_logits,
            ),
        }

    candidates = {}
    model_slug = model_id.rsplit("/", 1)[-1].lower()
    for recipe, upper_bound in (
        ("wildguard_weak_transfer", False),
        ("open_failure_upper_bound", True),
    ):
        run_dir = (
            artifacts_dir / "direct_failure_repair" / model_slug / recipe / "seed_42"
        )
        train_encoded = train_upper_encoded if upper_bound else train_weak_encoded
        validation_encoded = (
            validation_all_encoded if upper_bound else validation_weak_encoded
        )
        head = _new_head(hidden_size, seed=42)
        training = _frozen_head_train(
            head,
            train_encoded,
            validation_encoded,
            boundary_encoded,
            relevant_heads=relevant_heads,
            ranking_weight=0.0,
            seed=42,
            run_dir=run_dir,
        )
        validation_logits = _predict_head(head, validation_encoded)
        validation_evaluation = evaluate_scores(
            validation_encoded["records"],
            validation_logits,
        )
        boundary_logits = _predict_head(head, boundary_encoded)
        candidate = {
            "recipe": recipe,
            "trainable_heads": sorted(upper_heads if upper_bound else weak_heads),
            "training": training,
            "validation": validation_evaluation,
            "full_direct_suite": (
                None
                if upper_bound
                else evaluation_bundle(
                    head,
                    validation_encoded,
                    direct_suite_encoded,
                )
            ),
            "unaffected_suite": evaluation_bundle(
                head,
                validation_encoded,
                unaffected_encoded,
            ),
            "failure_holdout": evaluation_bundle(
                head,
                validation_encoded,
                failure_holdout_encoded,
            ),
            "multi_turn_holdout": evaluation_bundle(
                head,
                validation_encoded,
                multi_turn_holdout_encoded,
            ),
            "boundary_pairs": _pair_metrics(
                boundary_encoded["records"],
                1.0 / (1.0 + np.exp(-boundary_logits)),
            ),
            "artifact": {
                "head": str(run_dir / "head.safetensors"),
                "roundtrip_max_logit_difference": verify_head_roundtrip(
                    head,
                    train_encoded["features"][:2],
                    run_dir / "roundtrip_head.safetensors",
                ),
            },
            "advisory_only": True,
        }
        _save_head(head, run_dir / "head.safetensors")
        candidate["artifact"]["head_sha256"] = file_sha256(run_dir / "head.safetensors")
        _json_write(run_dir / "result.json", candidate)
        candidates[recipe] = candidate
        del head
        gc.collect()
        torch.cuda.empty_cache()

    result = {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "runtime": runtime_metadata(model_id, model_revision),
        "attention_implementation": attention_implementation,
        "data_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "selection": {
            "base_train": _records_summary(base_train),
            "base_validation": _records_summary(base_validation),
            "full_direct_suite": _records_summary(direct_suite),
            "unaffected_suite": _records_summary(unaffected_suite),
            "multi_turn": multi_turn["metadata"],
            "wildguard_vanilla": wildguard["metadata"],
            "open_failure_repair": failure_repair["metadata"],
            "maximum_per_source_security_label": maximum_per_stratum,
            "cross_fold_rows_excluded": {
                "train": train_crossing,
                "validation": validation_crossing,
                "dev_test": dev_crossing,
            },
        },
        "candidates": candidates,
        "gpu": {
            "peak_reserved_bytes": peak_reserved,
            "within_5_2_gib_limit": peak_reserved <= MAX_RESERVED_BYTES,
        },
        "limitations": [
            "WildGuard train harmfulness labels are source-model weak supervision.",
            "The upper bound repurposes already-open development sources for fitting.",
            "Group-held-out repair rows share source construction with fitted rows.",
            "No result is a prospective final-test or blocking approval.",
        ],
        "advisory_only": True,
    }
    output = reports_dir / f"modernbert-direct-failure-repair-{model_slug}.json"
    _json_write(output, result)
    return result


def run_consolidated_context_audit(
    data_dir: Path,
    artifact_dir: Path,
    reports_dir: Path,
    *,
    attention_implementation: str,
    untrusted_max_tokens: int = 2_048,
    untrusted_overlap: int = 512,
) -> dict:
    import gc

    import torch
    from transformers import AutoTokenizer

    config = json.loads((artifact_dir / "model_config.json").read_bytes())
    manifest_bytes = (data_dir / "manifest.json").read_bytes()
    manifest_sha256 = hashlib.sha256(manifest_bytes).hexdigest()
    if config["data_manifest_sha256"] != manifest_sha256:
        raise ValueError("consolidated artifact and data manifest do not match")
    manifest = json.loads(manifest_bytes)
    validation_records, crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "validation",
        fold_name=None,
        training=True,
        include_boundary=False,
        maximum=CONSOLIDATED_MAX_PER_STRATUM,
        lineage_roles=_lineage_roles(data_dir, manifest),
    )

    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID,
        revision=MODEL_REVISION,
    )
    encoder, head = _model_components(
        attention_implementation=attention_implementation,
        seed=42,
    )
    _load_head(head, artifact_dir / "head.safetensors")
    validation_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(
            tokenizer,
            validation_records,
            training=False,
            untrusted_max_tokens=untrusted_max_tokens,
            untrusted_overlap=untrusted_overlap,
        ),
    )
    del encoder
    gc.collect()
    torch.cuda.empty_cache()

    head.to("cuda")
    logits = _predict_head(head, validation_encoded)
    evaluation = evaluate_scores(validation_encoded["records"], logits)
    long_profiles = evaluate_long_untrusted_profiles(
        validation_encoded["records"],
        logits,
    )
    contextual_route = evaluate_contextual_route(
        validation_encoded["records"],
        logits,
        validation_evaluation=evaluation,
        long_untrusted_profiles=long_profiles,
    )
    scores = 1.0 / (1.0 + np.exp(-logits))
    output_dir = artifact_dir / f"context_{untrusted_max_tokens}"
    score_path = output_dir / "validation_scores.json"
    _json_write(
        score_path,
        {
            "schema_version": 1,
            "data_manifest_sha256": manifest_sha256,
            "heads": list(HEADS),
            "evaluation_policy": {
                "direct_max_tokens": DIRECT_MAX_TOKENS,
                "untrusted_max_tokens": untrusted_max_tokens,
                "untrusted_overlap": untrusted_overlap,
                "document_aggregation": "maximum_window_score_per_head",
            },
            "values": {
                f"{record['hash']}:{record['channel']}": {
                    "scores": {
                        head_name: float(scores[index, head_index])
                        for head_index, head_name in enumerate(HEADS)
                    },
                    "source": record["source"],
                    "security_label": record["security_label"],
                    "token_length": record["token_length"],
                    "window_count": record["window_count"],
                }
                for index, record in enumerate(validation_encoded["records"])
            },
            "contains_raw_text": False,
        },
    )
    result = {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "runtime": runtime_metadata(),
        "attention_implementation": attention_implementation,
        "data_manifest_sha256": manifest_sha256,
        "artifact": {
            "directory": str(artifact_dir),
            "head_sha256": file_sha256(artifact_dir / "head.safetensors"),
            "config_sha256": file_sha256(artifact_dir / "model_config.json"),
            "validation_scores": str(score_path),
        },
        "trained_input_policy": config["input_policy"],
        "evaluated_input_policy": {
            "direct_max_tokens": DIRECT_MAX_TOKENS,
            "untrusted_max_tokens": untrusted_max_tokens,
            "untrusted_overlap": untrusted_overlap,
            "document_aggregation": "maximum_window_score_per_head",
        },
        "selection": {
            "validation": _records_summary(validation_encoded["records"]),
            "maximum_per_source_security_label": CONSOLIDATED_MAX_PER_STRATUM,
            "cross_fold_rows_excluded": crossing,
        },
        "validation": evaluation,
        "long_untrusted_operating_points": long_profiles,
        "contextual_default_route": contextual_route,
        "gpu": {
            "peak_reserved_bytes": validation_encoded["peak_reserved_bytes"],
            "padded_token_budget": validation_encoded["padded_token_budget"],
            "within_5_2_gib_limit": (
                validation_encoded["peak_reserved_bytes"] <= MAX_RESERVED_BYTES
            ),
        },
        "dev_test": None,
        "advisory_only": True,
    }
    _json_write(output_dir / "result.json", result)
    reports_dir.mkdir(parents=True, exist_ok=True)
    _json_write(
        reports_dir / f"modernbert-multitask-context-{untrusted_max_tokens}.json",
        result,
    )
    return result


def run_consolidated_dev_test_comparison(
    data_dir: Path,
    artifact_dirs: dict[str, Path],
    output_path: Path,
    *,
    attention_implementation: str,
) -> dict:
    import gc

    import torch
    from transformers import AutoTokenizer

    if len(artifact_dirs) < 2:
        raise ValueError("dev-test comparison requires at least two artifacts")
    manifest_bytes = (data_dir / "manifest.json").read_bytes()
    manifest_sha256 = hashlib.sha256(manifest_bytes).hexdigest()
    manifest = json.loads(manifest_bytes)
    artifacts = {}
    input_policies = set()
    maxima = set()
    for name, artifact_dir in sorted(artifact_dirs.items()):
        config = json.loads((artifact_dir / "model_config.json").read_bytes())
        training_result = json.loads((artifact_dir / "result.json").read_bytes())
        if (
            config["data_manifest_sha256"] != manifest_sha256
            or training_result["data_manifest_sha256"] != manifest_sha256
        ):
            raise ValueError(f"{name} artifact and data manifest do not match")
        input_policies.add(
            (
                config["input_policy"]["untrusted_max_tokens"],
                config["input_policy"]["untrusted_overlap"],
            )
        )
        maxima.add(training_result["selection"]["maximum_per_source_security_label"])
        artifacts[name] = {
            "directory": artifact_dir,
            "config": config,
            "training_result": training_result,
        }
    if len(input_policies) != 1 or len(maxima) != 1:
        raise ValueError(
            "comparison artifacts use different input or selection policies"
        )
    untrusted_max_tokens, untrusted_overlap = input_policies.pop()
    maximum_per_stratum = maxima.pop()

    dev_records, crossing = load_capped_fold_records(
        data_dir,
        manifest,
        "dev_test",
        fold_name=None,
        training=False,
        include_boundary=False,
        maximum=maximum_per_stratum,
        lineage_roles=_lineage_roles(data_dir, manifest),
    )
    boundary_records = _boundary_records(data_dir, manifest, "test")
    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID,
        revision=MODEL_REVISION,
    )
    encoder, _ = _model_components(
        attention_implementation=attention_implementation,
        seed=42,
    )
    dev_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(
            tokenizer,
            dev_records,
            training=False,
            untrusted_max_tokens=untrusted_max_tokens,
            untrusted_overlap=untrusted_overlap,
        ),
    )
    boundary_encoded = _extract_with_vram_budget(
        encoder,
        tokenizer,
        _encode_records(
            tokenizer,
            boundary_records,
            training=False,
            untrusted_max_tokens=untrusted_max_tokens,
            untrusted_overlap=untrusted_overlap,
        ),
    )
    del encoder
    gc.collect()
    torch.cuda.empty_cache()

    comparisons = {}
    for name, artifact in artifacts.items():
        head = _new_head(dev_encoded["features"].shape[1] // 3, seed=42)
        _load_head(head, artifact["directory"] / "head.safetensors")
        head.to("cuda")
        dev_logits = _predict_head(head, dev_encoded)
        boundary_logits = _predict_head(head, boundary_encoded)
        training_result = artifact["training_result"]
        comparisons[name] = {
            "artifact": {
                "directory": str(artifact["directory"]),
                "head_sha256": file_sha256(artifact["directory"] / "head.safetensors"),
                "config_sha256": file_sha256(
                    artifact["directory"] / "model_config.json"
                ),
            },
            "raw": evaluate_scores(dev_encoded["records"], dev_logits),
            "validation_threshold_profiles": evaluate_threshold_profiles(
                dev_encoded["records"],
                dev_logits,
                training_result["validation"],
            ),
            "combined_route_operating_points": evaluate_combined_route_profiles(
                dev_encoded["records"],
                dev_logits,
                training_result["validation"],
            ),
            "contextual_default_route": evaluate_contextual_route(
                dev_encoded["records"],
                dev_logits,
                validation_evaluation=training_result["validation"],
                long_untrusted_profiles=training_result[
                    "long_untrusted_operating_points"
                ],
            ),
            "boundary_pairs": _pair_metrics(
                boundary_encoded["records"],
                1.0 / (1.0 + np.exp(-boundary_logits)),
            ),
        }
        del head
        torch.cuda.empty_cache()

    result = {
        "schema_version": 1,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "runtime": runtime_metadata(),
        "attention_implementation": attention_implementation,
        "data_manifest_sha256": manifest_sha256,
        "selection": {
            "dev_test": _records_summary(dev_encoded["records"]),
            "boundary_test": _records_summary(boundary_encoded["records"]),
            "maximum_per_source_security_label": maximum_per_stratum,
            "cross_fold_rows_excluded": crossing,
            "selected_rows_sha256": selected_rows_sha256(dev_encoded["records"]),
        },
        "input_policy": {
            "untrusted_max_tokens": untrusted_max_tokens,
            "untrusted_overlap": untrusted_overlap,
        },
        "comparisons": comparisons,
        "dev_test_opened": True,
        "advisory_only": True,
    }
    _json_write(output_path, result)
    return result


def resolve_attention_implementation(
    artifacts_dir: Path,
    requested: str,
) -> str:
    if requested == "sdpa":
        return "sdpa"
    if requested == "flash_attention_2":
        return FLASH_IMPLEMENTATION
    if requested != "auto":
        raise ValueError(f"unknown attention implementation: {requested}")
    gate_path = artifacts_dir / "routing_encoder_runs" / "runtime_gate.json"
    if gate_path.is_file():
        gate = json.loads(gate_path.read_bytes())
    else:
        gate = run_runtime_gate(gate_path)
    return FLASH_IMPLEMENTATION if gate.get("passed") else "sdpa"
